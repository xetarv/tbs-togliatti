const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{pathToFileURL}=require('node:url');
const dir=__dirname,root=path.resolve(dir,'../..'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
let engine=fs.readFileSync(path.join(root,'assets/three.min.js'),'utf8');const original=engine,patches=[];
function replace(before,after){if(engine.split(before).length!==2)throw Error('Nonunique engine anchor: '+before.slice(0,80));engine=engine.replace(before,after);patches.push({before,after});}
// r160 principle: link immediately, defer diagnostics and reflection until first use.
const start=engine.indexOf('if(a.attachShader(x,S)'),end=engine.indexOf('this.destroy=function()',start);
if(start<0||end<0)throw Error('Program anchors missing');
const old=engine.slice(start,end),checkStart=old.indexOf('t.debug.checkShaderErrors){'),tail=old.indexOf('let T,A;return');
const submit=old.slice(3,checkStart-1),checks='if('+old.slice(checkStart,tail);
const attrStart=old.indexOf('A=function(t,e)'),attrEnd=old.indexOf(',A},this.destroy');
const getAttr=old.slice(attrStart,old.lastIndexOf(',A},'));
if(!getAttr.endsWith('(a,x))'))throw Error('Attribute expression not recognized');
const attrExpression=getAttr.slice(2,-1);
replace(old,submit+';let T,A;const tbsSelf=this,tbsExtension=a.getExtension("KHR_parallel_shader_compile");let tbsReady=!tbsExtension;function tbsFirstUse(){if(T!==undefined)return;'+checks.replace('this.diagnostics=','tbsSelf.diagnostics=')+'a.deleteShader(S);a.deleteShader(w);T=new rs(a,x);A='+attrExpression+';}this.isReady=function(){if(!tbsReady)tbsReady=a.getProgramParameter(x,tbsExtension.COMPLETION_STATUS_KHR);return tbsReady;};return this.getUniforms=function(){tbsFirstUse();return T;},this.getAttributes=function(){tbsFirstUse();return A;},');
// r160 principle: registering a material does not force uniform reflection.
replace('const d=h.getUniforms(),m=rs.seqWithValue(d.seq,u);return n.currentProgram=h,n.uniformsList=m,h','return n.currentProgram=h,n.uniformsList=null,h');
replace('const L=b.getUniforms(),R=_.uniforms;','const L=b.getUniforms(),R=_.uniforms;if(_.uniformsList===null)_.uniformsList=rs.seqWithValue(L.seq,R);');
replace('this.destroy=function(){n.releaseStatesOfProgram(this),a.deleteProgram(x),this.program=void 0}', 'this.destroy=function(){if(T===undefined){a.deleteShader(S);a.deleteShader(w);}n.releaseStatesOfProgram(this),a.deleteProgram(x),this.program=void 0}');
// Keep the stock r149 traversal/cache/acquisition. Wait only after all pass submissions.
replace('f.pop(),p=null};let Et=null;',`f.pop(),p=null};
this.compileAsyncPasses=async function(passes,options={}){
 const signal=options.signal,start=performance.now(),stats={start,passes:passes.map(p=>p.name),submitted:0,polls:0,pollMs:0};
 this.__asyncStats=stats;
 const target=this.getRenderTarget(),face=this.getActiveCubeFace(),mip=this.getActiveMipmapLevel(),tone=this.toneMapping;
 const initial=new Set(this.info.programs);
 try{
  for(const pass of passes){if(signal?.aborted)throw signal.reason||new Error('Preparation aborted');this.toneMapping=pass.toneMapping;this.setRenderTarget(pass.target);this.compile(pass.scene,pass.camera);}
 }finally{this.toneMapping=tone;this.setRenderTarget(target,face,mip);}
 const programs=this.info.programs.filter(p=>!initial.has(p));stats.submitted=programs.length;stats.ids=programs.map(p=>p.id);stats.submitEnd=performance.now();
 let pending=programs.slice();
 while(pending.length){
  if(signal?.aborted)throw signal.reason||new Error('Preparation aborted');
  if(performance.now()-start>120000||this.getContext().isContextLost())throw new Error('Preparation timeout/context lost');
  const at=performance.now();pending=pending.filter(p=>!p.isReady());stats.pollMs+=performance.now()-at;stats.polls++;
  if(pending.length)await new Promise(resolve=>setTimeout(resolve,10));
 }
 stats.ready=performance.now();
 for(const program of programs){program.getUniforms();program.getAttributes();if(program.diagnostics?.runnable===false)throw new Error('Shader preparation failed: '+program.id);}
 stats.reflected=performance.now();return stats;
};let Et=null;`);
fs.writeFileSync(path.join(dir,'three-r149-async.min.js'),engine);
fs.writeFileSync(path.join(dir,'engine-patch.json'),JSON.stringify({originalSHA256:hash(original),prototypeSHA256:hash(engine),patches},null,2));
// Expose real pass objects without rendering, advancing clocks, filling reflection targets,
// assigning environment maps, or touching cubeReady/waterReady/quarterDue.
let graphics=fs.readFileSync(path.join(root,'dist/adapters/rendering/graphics.js'),'utf8');
const at='    function render(dt, daylight) {';
if(graphics.split(at).length!==2)throw Error('Graphics anchor');
const expose=`    renderer.__startupPasses=()=>[
      {name:'main-linear',scene,camera,target:sceneTarget,toneMapping:renderer.toneMapping},
      {name:'reflection-cube-linear',scene:reflectionScene,camera:cubeCamera.children[0],target:cubeTarget,toneMapping:T.NoToneMapping},
      {name:'water-reflection-linear',scene:reflectionScene,camera:mirrorCamera,target:waterTarget,toneMapping:T.NoToneMapping},
      {name:'post-output',scene:postScene,camera:postCamera,target:null,toneMapping:renderer.toneMapping}
    ];
`;
graphics=graphics.replace(at,expose+at);fs.writeFileSync(path.join(dir,'graphics-experimental.js'),graphics);
let app=fs.readFileSync(path.join(root,'dist/app.js'),'utf8');
if(!app.includes('        runtime.start();'))throw Error('App anchor');
app=app.replace('(() => {','(async () => {').replace('        runtime.start();',`        const startupAbort=new AbortController();
        const cancel=()=>startupAbort.abort(new Error('Page left during preparation'));
        addEventListener('pagehide',cancel,{once:true});
        try {await world.renderer.compileAsyncPasses(world.renderer.__startupPasses(),{signal:startupAbort.signal});}
        catch(error){runtime.stop(); world.renderer.dispose(); throw error;}
        finally {removeEventListener('pagehide',cancel);}
        runtime.start();`);
fs.writeFileSync(path.join(dir,'app-experimental.js'),app);
for(const mode of ['A','B']){
 let html=fs.readFileSync(path.join(root,'index.html'),'utf8').replace('<head>','<head>\n<base href="'+pathToFileURL(root+path.sep).href+'">');
 if(mode==='B')for(const [old,name]of [['assets/three.min.js','three-r149-async.min.js'],['dist/adapters/rendering/graphics.js','graphics-experimental.js'],['dist/app.js','app-experimental.js']])html=html.replace('src="'+old+'"','src="'+pathToFileURL(path.join(dir,name)).href+'"');
 fs.writeFileSync(path.join(dir,'index-'+mode+'.html'),html);
}
const sources=fs.readdirSync(path.join(dir,'official')).map(name=>({name,sha256:hash(fs.readFileSync(path.join(dir,'official',name)))}));
fs.writeFileSync(path.join(dir,'provenance.json'),JSON.stringify({base:'89613bbf312bbb053de05471b98ee1f8747f5739',head:'efffd0b268e63e98bfe0571f30a00ec420c0c986',sourceBase:'https://raw.githubusercontent.com/mrdoob/three.js/',sources,programDiscovery:'Current renderer.compile traversals, live main/reflection/post scenes; no fixed corpus or hidden trial render',knownCoverageLimit:'Stock compile traversal does not prepare shadow depth materials, PMREM updates or environment-map variants assigned later by the first real render. These remain measured late compilation, not declared prepared.'},null,2));
console.log(JSON.stringify({enginePatches:patches.length,engineBytes:engine.length,originalBytes:original.length}));
