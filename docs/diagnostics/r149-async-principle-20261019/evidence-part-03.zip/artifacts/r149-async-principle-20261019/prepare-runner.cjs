const fs=require('node:fs'),path=require('node:path');const dir=__dirname,prior=path.join(dir,'../menu-windowed-laptop-20261019');
for(const f of ['probe.js','menu-probe-final.js','png.cjs'])fs.copyFileSync(path.join(prior,f),path.join(dir,f));
let s=fs.readFileSync(path.join(prior,'run-final.cjs'),'utf8');
function replace(a,b){if(!s.includes(a))throw Error('Runner anchor '+a.slice(0,90));s=s.replace(a,b);}
replace("save('conditions-final.json'","save('conditions-ab.json'");
replace("order:'1-fresh 1-warm 2-fresh 2-warm 3-fresh 3-warm'","order:'pair1 A/B; pair2 B/A; pair3 A/B; fresh then restart same own profile per arm'");
replace('async function run(pair,warm){','async function run(pair,warm,mode,prefix="ab"){');
replace("const name=`final-${pair}-${warm?'warm':'fresh'}`","const name=`${prefix}-${pair}-${mode}-${warm?'warm':'fresh'}`");
replace("'final-'+pair","prefix+'-'+pair+'-'+mode");
replace("await page.addInitScript({path:path.join(dir,'menu-probe-final.js')});","await page.addInitScript({path:path.join(dir,'menu-probe-final.js')});await page.addInitScript({path:path.join(dir,'program-observer.js')});");
replace("await page.goto(pathToFileURL(path.join(root,'index.html')).href","await page.goto(pathToFileURL(path.join(dir,'index-'+mode+'.html')).href");
replace("timestamp:Date.now()/1000});\n  const data=await page.evaluate", "timestamp:Date.now()/1000});await page.waitForTimeout(8000);\n  const data=await page.evaluate");
replace('return{timeOrigin:performance.timeOrigin,','return{programObservation:window.__programDiag.snapshot(r),timeOrigin:performance.timeOrigin,');
replace('name,pair,warm,before,','name,pair,warm,mode,before,');
replace('errors:errors.length,debug:data.debug,focus:data.window.focus','errors:errors.length,debug:data.debug,focus:data.window.focus,programs:data.programObservation.created.length,prepared:data.programObservation.prepared?.submitted,used:data.programObservation.used.length');
replace("(async()=>{for(let p=1;p<=3;p++){await run(p,false);await run(p,true);}})","(async()=>{if(process.argv.includes('--pilot')){await run(0,false,'B','pilot');return;}for(let p=1;p<=3;p++)for(const mode of (p===2?['B','A']:['A','B'])){await run(p,false,mode);await run(p,true,mode);}})");
fs.writeFileSync(path.join(dir,'run-ab.cjs'),s);
console.log('Prepared one runner; no browser launched.');
