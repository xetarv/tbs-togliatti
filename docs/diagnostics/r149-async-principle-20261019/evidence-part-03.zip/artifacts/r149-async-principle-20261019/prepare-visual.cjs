const fs=require('node:fs'),path=require('node:path'),dir=__dirname;
let s=fs.readFileSync(path.join(dir,'../shader-integration-laptop-20261019/visual-deferred.cjs'),'utf8');
function replace(a,b){if(!s.includes(a))throw Error('Visual anchor '+a.slice(0,70));s=s.replace(a,b);}
replace('headless:true,\n  viewport:{width:1024,height:768},deviceScaleFactor:1,','headless:false,\n  viewport:null,');
const start=s.indexOf("  await page.addInitScript({content:'window.__warmCorpus='");const end=s.indexOf('  await page.addInitScript(()=>{',start);if(start<0||end<0)throw Error('Legacy preparation anchor');s=s.slice(0,start)+s.slice(end);
replace("window.__batchPrototype.onRenderer(r);",'');
replace("url.search='?dynamicTraffic=0&shaderChecks=0&batchPrototype='+(mode==='B'?'1':'0');","url.search='';");
replace("const url=pathToFileURL(path.join(dir,'index-'+mode+'.html'));",`const browser=await context.browser().newBrowserCDPSession(),target=await context.newCDPSession(page),{targetInfo}=await target.send('Target.getTargetInfo');
  const bounds=await browser.send('Browser.getWindowForTarget',{targetId:targetInfo.targetId});await browser.send('Browser.setWindowBounds',{windowId:bounds.windowId,bounds:{windowState:'maximized'}});await page.bringToFront();
  const url=pathToFileURL(path.join(dir,'index-'+mode+'.html'));`);
replace('warm:window.__batchPrototype.snapshot()','prepared:r.__asyncStats||null,window:{innerWidth,innerHeight,dpr:devicePixelRatio},renderer:g.getParameter(g.getExtension("WEBGL_debug_renderer_info").UNMASKED_RENDERER_WEBGL)');
replace("const rect=await page.locator('#startBtn').boundingBox();","await page.locator('#startBtn').scrollIntoViewIfNeeded();const rect=await page.locator('#startBtn').boundingBox();");
// New names and profiles: never overwrite earlier evidence.
s=s.replaceAll("'deferred-","'visual-").replaceAll('deferred-A','visual-A').replaceAll('deferred-B','visual-B');
fs.writeFileSync(path.join(dir,'visual.cjs'),s);console.log('Prepared visual check; not launched.');
