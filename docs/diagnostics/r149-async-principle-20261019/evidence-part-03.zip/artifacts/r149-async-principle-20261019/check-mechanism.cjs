const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
(async()=>{
 const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
  const page=await browser.newPage(),consoleErrors=[];page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});
  await page.goto(pathToFileURL(path.join(__dirname,'mechanism.html')).href);
  const results=await page.evaluate(async()=>{
   const T=THREE,results={};
   async function run(kind){
    const r=new T.WebGLRenderer(),gl=r.getContext(),scene=new T.Scene(),camera=new T.PerspectiveCamera(60,1,.1,10);camera.position.z=2;
    const geometry=new T.PlaneGeometry(1,1),material=new T.ShaderMaterial({vertexShader:'void main(){gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:kind==='invalid'?'INVALID GLSL':'void main(){gl_FragColor=vec4(1.,0.,0.,1.);}'});scene.add(new T.Mesh(geometry,material));
    let completion=0,reflection=0,earlyReflection=0;const ext=gl.getExtension('KHR_parallel_shader_compile'),get=gl.getProgramParameter,extension=gl.getExtension;
    const readiness=new WeakSet();
    gl.getProgramParameter=function(p,param){const value=get.call(this,p,param);if(ext&&param===ext.COMPLETION_STATUS_KHR){completion++;if(value)readiness.add(p);}if(param===gl.ACTIVE_UNIFORMS||param===gl.ACTIVE_ATTRIBUTES){reflection++;if(ext&&kind!=='fallback'&&!readiness.has(p))earlyReflection++;}return value;};
    if(kind==='fallback')gl.getExtension=function(name){return name==='KHR_parallel_shader_compile'?null:extension.call(this,name);};
    const abort=new AbortController(),reason=new Error('expected abort');if(kind==='aborted')abort.abort(reason);
    let rejection=null;try{await r.compileAsyncPasses([{name:kind,scene,camera,target:null,toneMapping:r.toneMapping}],{signal:abort.signal});}catch(e){rejection={message:e.message,sameAbortReason:e===reason};}
    const before=r.info.programs.length;if(!rejection)r.render(scene,camera);const after=r.info.programs.length;
    const result={rejection,extension:!!ext,completion,reflection,earlyReflection,programsBefore:before,programsAfter:after,checks:r.debug.checkShaderErrors,diagnostics:r.info.programs.map(p=>p.diagnostics?.runnable??null),glError:gl.getError(),targetRestored:r.getRenderTarget()===null};
    material.dispose();geometry.dispose();r.dispose();r.forceContextLoss();return result;
   }
   for(const kind of ['normal','fallback','aborted','invalid'])results[kind]=await run(kind);
   return results;
  });
  const passed=results.normal.earlyReflection===0&&results.normal.programsBefore===results.normal.programsAfter&&!results.normal.rejection&&results.normal.glError===0&&results.fallback.completion===0&&!results.fallback.rejection&&results.aborted.rejection?.sameAbortReason&&results.invalid.rejection?.message.startsWith('Shader preparation failed:')&&consoleErrors.some(s=>s.includes('THREE.WebGLProgram: Shader Error'));
  fs.writeFileSync(path.join(__dirname,'mechanism-check.json'),JSON.stringify({passed,results,consoleErrors,note:'Isolated unit-sized contexts, excluded from startup A/B. Unsupported-KHR case simulated only here. Invalid shader is intentionally confined to this test.'},null,2));
  if(!passed)throw Error('Mechanism check failed');console.log('Mechanism checks passed: deferred reflection, reuse, fallback, pre-abort and preserved shader diagnostics.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
