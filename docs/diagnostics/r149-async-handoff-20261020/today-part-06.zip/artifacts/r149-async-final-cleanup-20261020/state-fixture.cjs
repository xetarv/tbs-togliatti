const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,write=(n,s)=>{const p=path.join(dir,n);if(fs.existsSync(p)&&fs.readFileSync(p).equals(Buffer.from(s)))return;fs.writeFileSync(p,s,{flag:'wx'});};
write('state-fixture.html','<!doctype html><meta charset="utf-8"><script src="'+pathToFileURL(path.join(dir,'three-stage2.js')).href+'"></script>');
(async()=>{
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles','state-fixture'),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
  const page=context.pages()[0],messages=[];page.on('console',m=>messages.push(m.text()));page.on('pageerror',e=>messages.push(e.stack));await page.goto(pathToFileURL(path.join(dir,'state-fixture.html')).href);
  try{
  const rows=await page.evaluate(async()=>{
   const rows=[],records=[];let active;
   window.__fixture={rows,phase:'begin'};
   const wait=(canvas,event)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Native event timeout: '+event)),5000);canvas.addEventListener(event,e=>{e.preventDefault();clearTimeout(timer);resolve();},{once:true});});
   const proto=WebGL2RenderingContext.prototype,create=proto.createTexture,del=proto.deleteTexture;
   proto.createTexture=function(){const h=Reflect.apply(create,this,arguments);records.push({h,gl:this,owner:active,deletes:0});return h;};
   proto.deleteTexture=function(h){const row=records.find(r=>r.h===h);if(row)row.deletes++;return Reflect.apply(del,this,arguments);};
   try{for(const scenario of ['alive','lost-dispose','lost-restore']){
    active=scenario;window.__fixture.phase=scenario;const canvas=document.createElement('canvas');canvas.width=64;canvas.height=64;document.body.append(canvas);
    const r=new THREE.WebGLRenderer({canvas}),g=r.getContext();
    const own=()=>records.filter(x=>x.owner===scenario),native=()=>own().map(x=>({deletes:x.deletes,valid:!g.isContextLost()&&g.isTexture(x.h)}));
    r.state.bindTexture(g.TEXTURE_2D,null);const fallback2D=g.getParameter(g.TEXTURE_BINDING_2D);
    r.state.bindTexture(g.TEXTURE_CUBE_MAP,null);const fallbackCube=g.getParameter(g.TEXTURE_BINDING_CUBE_MAP);
    const twoOwners=own().length===2&&own().some(x=>x.h===fallback2D)&&own().some(x=>x.h===fallbackCube);
    r.resetState();r.state.bindTexture(g.TEXTURE_2D,null);r.state.bindTexture(g.TEXTURE_CUBE_MAP,null);
    const resetPreserved=own().every(x=>!x.deletes&&g.isTexture(x.h));
    let lostError=0,restored=false;
    if(scenario!=='alive'){
     const ext=g.getExtension('WEBGL_lose_context');if(!ext)throw Error('Loss fixture extension missing');
     window.__fixture.phase=scenario+' waiting-lost';const lost=wait(canvas,'webglcontextlost');ext.loseContext();await lost;
     if(!g.isContextLost())throw Error('Expected native lost context');lostError=g.getError();
     if(scenario==='lost-restore'){
      window.__fixture.phase=scenario+' waiting-restore';const ready=wait(canvas,'webglcontextrestored');ext.restoreContext();await ready;restored=!g.isContextLost();
      if(!restored||own().length!==4)throw Error('Native renderer did not recreate state after restore');
      r.state.bindTexture(g.TEXTURE_2D,null);r.state.bindTexture(g.TEXTURE_CUBE_MAP,null);
     }
    }
    r.dispose();const after=native();r.dispose();const again=native();
    const expectedDeletes=scenario==='lost-dispose'?0:2;
    const passed=twoOwners&&resetPreserved&&after.reduce((n,x)=>n+x.deletes,0)===expectedDeletes&&JSON.stringify(after)===JSON.stringify(again)&&after.every(x=>!x.valid)&&own().every(x=>x.deletes<=1);
    const glError=g.getError();rows.push({scenario,twoOwners,resetPreserved,created:own().length,after,again,lostError,restored,glError,passed});
    canvas.remove();if(!passed||glError)throw Error('Fallback fixture failed '+scenario);
   }}finally{proto.createTexture=create;proto.deleteTexture=del;}
   return rows;
  });
  write('state-fixture.json',JSON.stringify({browser:context.browser().version(),rows,note:'Focused native WebGLState owner/reset/dispose/loss/restore checks only; not full B++ context-loss acceptance.'},null,2));
  console.log(JSON.stringify(rows));
  }catch(error){write('state-fixture-failure.json',JSON.stringify({error:error.stack,progress:await page.evaluate(()=>window.__fixture),messages},null,2));throw error;}
 }finally{await context.close();}
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
