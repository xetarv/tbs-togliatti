const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=__dirname,sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const write=(n,s)=>fs.writeFileSync(path.join(dir,n),s,{flag:'wx'});
const j=JSON.parse(fs.readFileSync(path.join(dir,'facade-1.json'))),s=j.after;
const remaining=s.objects.filter(x=>x.kind==='texture'&&!x.deletes);
if(s.byKind.texture.unrequested!==2||remaining.some(x=>!x.stack.includes('new Fs'))||s.glError||!j.idempotent)throw Error('Stage 1 not accepted');
for(const k of ['program','shader','framebuffer','renderbuffer','buffer'])if(s.byKind[k].unrequested||s.byKind[k].duplicateDeletes)throw Error('Stage 1 '+k);
write('stage1-acceptance.json',JSON.stringify({passed:true,textures:s.byKind.texture,remaining,reason:'Exactly the two WebGLState native fallback allocations remain. All six facade native allocations received their normal delete requests.'},null,2));
const changes=[
 ['function Fs(t,e,n){const r=n.isWebGL2;', 'function Fs(t,e,n){let tbsFallbackDisposed=false;const r=n.isWebGL2;'],
 ['return{buffers:{color:s,depth:a,stencil:o},enable:G,', 'return{dispose:function(){if(tbsFallbackDisposed)return;tbsFallbackDisposed=true;const lost=t.isContextLost();for(const key of Object.keys(k)){const texture=k[key];delete k[key];if(!lost)t.deleteTexture(texture)}N={}},buffers:{color:s,depth:a,stencil:o},enable:G,'],
 ['V&&(V.dispose(),V=null),Pt.stop()},this.renderBufferDirect=', 'V&&(V.dispose(),V=null),Pt.stop(),J.dispose()},this.renderBufferDirect=']
];
for(const suffix of ['', '-probe']){
 const before=fs.readFileSync(path.join(dir,'three-stage1'+suffix+'.js'),'utf8');let after=before;
 for(const [a,b]of changes){if(after.split(a).length!==2)throw Error('Unique state anchor '+a);after=after.replace(a,b);}
 write('three-stage2'+suffix+'.js',after);
 if(!suffix)write('fallback-patch.json',JSON.stringify({beforeSHA256:sha(before),afterSHA256:sha(after),changes,reason:'WebGLState owns two raw native fallback textures; terminal renderer disposal releases only these handles, clears its texture bindings, and is idempotent. A lost context has already invalidated the handles; do not issue GL deletion there. reset/bindTexture remain unchanged.'},null,2));
}
write('index-stage2.html',fs.readFileSync(path.join(dir,'index-stage1.html'),'utf8').replace('three-stage1-probe.js','three-stage2-probe.js'));
console.log('Stage 1 accepted; prepared terminal WebGLState fallback cleanup only.');
