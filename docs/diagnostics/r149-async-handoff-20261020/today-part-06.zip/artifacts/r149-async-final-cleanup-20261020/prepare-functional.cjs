const fs=require('node:fs'),path=require('node:path');
const dir=__dirname,prior=path.resolve(dir,'../r149-async-rng-20261020');
const write=(n,s)=>fs.writeFileSync(path.join(dir,n),s,{flag:'wx'});
const cycles=JSON.parse(fs.readFileSync(path.join(dir,'cycles-summary.json')));
if(cycles.rows.length!==3||cycles.errors.length)throw Error('Resource cycles not accepted');
for(const {after:s,sameContext}of cycles.rows){
 if(!sameContext||s.glError||s.pending||s.pollTimers||s.pagehideActive||s.postDispose.length||!s.checks||s.rendererPrograms.length||s.pmrem.some(x=>x.disposeEvents!==1))throw Error('Cycle failure');
 for(const k of ['program','shader','texture','framebuffer','renderbuffer','buffer','vertexArray'])if(s.byKind[k].unrequested||s.byKind[k].duplicateDeletes)throw Error('Resource gate '+k);
}
write('resource-acceptance.json',JSON.stringify({passed:true,rows:cycles.rows.map(r=>({cycle:r.cycle,sameContext:r.sameContext,byKind:r.after.byKind})),note:'All creation/deletion requests balanced; not a system GPU-memory guarantee.'},null,2));
write('index-baseline.html',fs.readFileSync(path.join(dir,'index-stage1.html'),'utf8').replace('three-stage1-probe.js','three-stage1.js'));
write('index-final.html',fs.readFileSync(path.join(dir,'index-stage2.html'),'utf8').replace('three-stage2-probe.js','three-stage2.js'));
for(const n of ['program-observer.js','png.cjs'])write(n,fs.readFileSync(path.join(prior,n)));
let visual=fs.readFileSync(path.join(prior,'verify-visual.cjs'),'utf8');
visual=visual.replace("[['A1','P'],['B','Q'],['C','B'],['A2','P']]","[['A1','baseline'],['B','final'],['A2','baseline']]");
visual=visual.replace("['A1','B','C','A2']","['A1','B','A2']").replace("['B','C','A2']","['B','A2']").replace('size===4','size===3');
write('verify-visual.cjs',visual);
let cancel=fs.readFileSync(path.resolve(dir,'../r149-async-lifecycle-fix-20261020/run.cjs'),'utf8');
cancel=cancel.replace("path.join(dir,'observe.js')","path.join(dir,'observe-resource.js')");
write('cancel.cjs',cancel);
console.log('Three-cycle resource gate accepted. Prepared existing A1/B/A2 fixed-step visual/RNG and cancel checks.');
