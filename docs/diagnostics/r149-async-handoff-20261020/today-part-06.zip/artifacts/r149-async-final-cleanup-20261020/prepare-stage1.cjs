const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{pathToFileURL}=require('node:url');
const dir=__dirname,root=path.resolve(dir,'../..'),prior=path.resolve(dir,'../r149-async-pmrem-dispose-20261020');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const write=(n,s)=>fs.writeFileSync(path.join(dir,n),s,{flag:'wx'});
const preserved=JSON.parse(fs.readFileSync(path.join(prior,'preserved-before.json')));
for(const [f,h]of Object.entries(preserved))if(sha(fs.readFileSync(path.join(root,f)))!==h)throw Error('Prior file changed '+f);
for(const f of fs.readdirSync(prior)){const p=path.join(prior,f);if(fs.statSync(p).isFile())preserved[path.relative(root,p)]=sha(fs.readFileSync(p));}
write('preserved-before.json',JSON.stringify(preserved,null,2));
for(const n of ['app.js','scene.js','graphics.js','observe.js'])write(n,fs.readFileSync(path.join(prior,n)));
write('three-stage1.js',fs.readFileSync(path.join(prior,'three-fixed.js')));
write('three-stage1-probe.js',fs.readFileSync(path.join(prior,'three-fixed-probe.js')));
const before=fs.readFileSync(path.join(prior,'dispose-environment.js'),'utf8');
const anchor='    for (const instance of instances) attempt(\'instance\', () => instance.dispose());';
if(before.split(anchor).length!==2)throw Error('World texture ownership anchor');
const after=before.replace(anchor,`    // These original maps are world-owned, borrowed by reflection proxies.
    // Runtime/graphics are stopped, and all materials are disposed before maps.
    // The same Set deduplicates any aliases also reachable from scene materials.
    for (const facade of world.facadeMaterials) texture(facade);
${anchor}`);
write('dispose-environment.js',after);
write('facade-patch.json',JSON.stringify({beforeSHA256:sha(before),afterSHA256:sha(after),added:'for (const facade of world.facadeMaterials) texture(facade);',owner:'Dedicated experimental world. Graphics only borrows these maps; materials finish before Texture.dispose.'},null,2));
let html=fs.readFileSync(path.join(prior,'index-fixed.html'),'utf8').split(pathToFileURL(prior).href+'/').join(pathToFileURL(dir).href+'/');
html=html.replace('three-fixed-probe.js','three-stage1-probe.js');
write('index-stage1.html',html);
let run=fs.readFileSync(path.join(prior,'run.cjs'),'utf8');
run=run.replace("if(variant==='fixed')gate(row);","if(variant==='stage1'||variant==='stage2')gate(row);");
run=run.replace("if(!j.idempotent)throw Error('Cleanup was not idempotent');",`if(!j.idempotent)throw Error('Cleanup was not idempotent');
 if(variant==='stage1'&&s.byKind.texture.unrequested!==2)throw Error('Facade cleanup did not leave exactly two native fallback textures');
 if(variant==='stage2'&&(s.byKind.texture.unrequested||s.byKind.texture.duplicateDeletes))throw Error('Texture cleanup gate');`);
// Forward and observe texture binding; never replace native cleanup operations.
let observer=fs.readFileSync(path.join(dir,'observe.js'),'utf8');
observer=observer.replace("'getExtension','getProgramParameter','useProgram'","'bindTexture','getExtension','getProgramParameter','useProgram'");
observer=observer.replace('const value=Reflect.apply(fn,this,a);',`if(name==='bindTexture'&&a[1]){const old=ids.get(a[1]);if(old?.deletes)d.postDispose.push({name:'bind-deleted-texture',id:old.id});}
   const value=Reflect.apply(fn,this,a);`);
write('observe-resource.js',observer);
run=run.replace("path.join(dir,'observe.js')","path.join(dir,'observe-resource.js')");
write('run.cjs',run);
console.log('Stage 1 prepared; source preservation manifest: '+Object.keys(preserved).length+' files.');
