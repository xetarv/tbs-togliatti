// Derived from the existing fixed-step visual gate. No per-pass readbacks or shader-hook interception.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),zlib=require('node:zlib');
const {pathToFileURL}=require('node:url'),{chromium}=require('playwright-core'),{decode}=require('./png.cjs');
const dir=__dirname,round=Number(process.argv[2]||1),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
if(![1,2].includes(round))throw Error('At most two independent visual rounds');
const save=(name,data)=>fs.writeFileSync(path.join(dir,name),data,{flag:'wx'});
async function run(label,mode){
 const name=`visual-${round}-${label}`,nonce=crypto.randomUUID(),profile=path.join(dir,'profiles',name);
 if(fs.existsSync(profile)||fs.existsSync(path.join(dir,name+'.json')))throw Error('Refusing reused profile/output');
 const context=await chromium.launchPersistentContext(profile,{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl','--enable-precise-memory-info'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
  const page=context.pages()[0],errors=[],warnings=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());if(m.type()==='warning')warnings.push(m.text());});
  await page.addInitScript(({nonce})=>{
   window.__captureNonce=nonce;window.__futureStates=[];window.__audioBuffers=[];const create=AudioContext.prototype.createBuffer;AudioContext.prototype.createBuffer=function(...args){const result=Reflect.apply(create,this,args);window.__audioBuffers.push(result);return result;};localStorage.setItem('tbs.graphicsQuality','high');
   const rng=window.__rng={seed:72421,calls:0};let api;
   Math.random=()=>{rng.seed=(Math.imul(rng.seed,1664525)+1013904223)>>>0;rng.calls++;return rng.seed/4294967296;};
   Object.defineProperty(window,'TBS',{get:()=>api,set(value){api=value;
    for(const name of ['buildWorld','buildPresentation','createRuntime']){let fn;Object.defineProperty(api,name,{get:()=>fn,set(original){fn=function(...args){
     const result=Reflect.apply(original,this,args);
     if(name==='buildWorld'){window.__world=result;const r=result.renderer;window.__prepareCalls=0;window.__modifiedRenderer=typeof r.compileAsyncPasses==='function';if(window.__modifiedRenderer){const p=r.compileAsyncPasses;r.compileAsyncPasses=function(...a){window.__prepareCalls++;return Reflect.apply(p,this,a);};}}
     if(name==='buildPresentation'){window.__ports=result;window.__state=args[0].state;window.__traffic=args[0].traffic.traffic;}
     if(name==='createRuntime'){window.__game=args[0].game;return{...result,start(){window.__game.initialize();window.__visualStarted=true;}};}
     return result;
    };}});}
   }});
  },{nonce});
  const browser=await context.browser().newBrowserCDPSession(),cdp=await context.newCDPSession(page),{targetInfo}=await cdp.send('Target.getTargetInfo'),bounds=await browser.send('Browser.getWindowForTarget',{targetId:targetInfo.targetId});
  await browser.send('Browser.setWindowBounds',{windowId:bounds.windowId,bounds:{windowState:'maximized'}});await page.bringToFront();await page.addInitScript({path:path.join(dir,'program-observer.js')});
  await page.goto(pathToFileURL(path.join(dir,'index-'+mode+'.html')).href,{waitUntil:'load',timeout:180000});await page.waitForFunction(()=>window.__visualStarted,null,{timeout:180000});
  let totalSteps=0;
  async function capture(stage,steps){
   totalSteps+=steps;
   const data=await page.evaluate(({steps,stage,totalSteps})=>{
    const w=window.__world,r=w.renderer,g=r.getContext(),passes=[];const original=r.render;
    r.render=function(scene,camera){passes.push({world:scene===w.scene,camera:camera.type,target:!!r.getRenderTarget()});return Reflect.apply(original,this,arguments);};
    try{for(let i=0;i<steps;i++){window.__game.step(1/60);if((totalSteps-steps+i+1)%30===0)window.__futureStates.push({step:totalSteps-steps+i+1,rng:{...window.__rng},state:JSON.parse(JSON.stringify(window.__state)),traffic:JSON.parse(JSON.stringify(window.__traffic))});}}finally{r.render=original;}
    const beforeError=g.getError(),target=r.getRenderTarget(),framebuffer=g.getParameter(g.FRAMEBUFFER_BINDING),width=g.drawingBufferWidth,height=g.drawingBufferHeight;
    const pixels=new Uint8Array(width*height*4);g.readPixels(0,0,width,height,g.RGBA,g.UNSIGNED_BYTE,pixels);
    const readError=g.getError();g.finish();const afterFinish=new Uint8Array(pixels.length);g.readPixels(0,0,width,height,g.RGBA,g.UNSIGNED_BYTE,afterFinish);
    let finishChangedBytes=0;for(let i=0;i<pixels.length;i++)if(pixels[i]!==afterFinish[i])finishChangedBytes++;
    let binary='';for(let i=0;i<pixels.length;i+=32768)binary+=String.fromCharCode(...pixels.subarray(i,i+32768));
    const camera=w.camera,worldTransforms=[];
    w.scene.traverse(o=>worldTransforms.push([o.type,o.name,o.position.toArray(),o.quaternion.toArray(),o.scale.toArray(),o.visible,o.isLight?o.intensity:null]));
    const cameraState={position:camera.position.toArray(),quaternion:camera.quaternion.toArray(),up:camera.up.toArray(),world:camera.matrixWorld.toArray(),view:camera.matrixWorldInverse.toArray(),projection:camera.projectionMatrix.toArray(),inverseProjection:camera.projectionMatrixInverse.toArray(),fov:camera.fov,aspect:camera.aspect,near:camera.near,far:camera.far};
    const cpu={state:JSON.parse(JSON.stringify(window.__state)),traffic:JSON.parse(JSON.stringify(window.__traffic)),daylight:window.__ports.timeline.daylight(),camera:cameraState,worldTransforms};
    const programs=r.info.programs.map(p=>({name:p.name,linked:g.getProgramParameter(p.program,g.LINK_STATUS),log:g.getProgramInfoLog(p.program)}));
    const water=w.scene.userData.waterMaterial.userData.shader;const waterState={wave:water?.uniforms.waveTime?.value,strength:water?.uniforms.reflectionStrength?.value};const observation=window.__programDiag.snapshot(r);const png=r.domElement.toDataURL('image/png');
    const ext=g.getExtension('WEBGL_debug_renderer_info');
    const audio=window.__audioBuffers.map(b=>({length:b.length,sampleRate:b.sampleRate,head:Array.from(b.getChannelData(0).slice(0,64))}));return{futureStates:window.__futureStates,audio,waterState,observation,nonce:window.__captureNonce,stage,totalSteps,rng:{...window.__rng},cpu,passes,width,height,pixels:btoa(binary),png,beforeError,readError,finishChangedBytes,endError:g.getError(),defaultFramebuffer:target===null&&framebuffer===null,programs,modifiedRenderer:window.__modifiedRenderer,preparationCalls:window.__prepareCalls,debug:r.debug.checkShaderErrors,quality:window.__ports.graphics.quality,contextAttributes:g.getContextAttributes(),renderSettings:{outputEncoding:r.outputEncoding,toneMapping:r.toneMapping,exposure:r.toneMappingExposure,shadows:r.shadowMap.enabled},window:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},gpu:g.getParameter(ext.UNMASKED_RENDERER_WEBGL),navigation:performance.getEntriesByType('navigation')[0]?.toJSON()};
   },{steps,stage,totalSteps});
   const raw=Buffer.from(data.pixels,'base64'),png=Buffer.from(data.png.split(',')[1],'base64'),decoded=decode(png);let pngChangedBytes=0;
   if(decoded.w!==data.width||decoded.h!==data.height||decoded.bpp!==4)throw Error('PNG/RGBA layout mismatch');
   for(let y=0;y<data.height;y++)for(let x=0;x<data.width*4;x++)if(raw[(data.height-1-y)*data.width*4+x]!==decoded.pixels[y*data.width*4+x])pngChangedBytes++;
   save(`${name}-${stage}.rgba`,raw);save(`${name}-${stage}.png`,png);
   const cpuText=JSON.stringify(data.cpu);save(`${name}-${stage}-state.json.gz`,zlib.gzipSync(cpuText));
   data.camera=data.cpu.camera;data.player=data.cpu.state.player;data.stateSHA256=sha(Buffer.from(JSON.stringify(data.cpu.state)));data.trafficSHA256=sha(Buffer.from(JSON.stringify(data.cpu.traffic)));data.worldTransformsSHA256=sha(Buffer.from(JSON.stringify(data.cpu.worldTransforms)));data.daylight=data.cpu.daylight;delete data.cpu;delete data.pixels;delete data.png;
   Object.assign(data,{pixelSHA256:sha(raw),pngSHA256:sha(png),cpuSHA256:sha(Buffer.from(cpuText)),pngChangedBytes});
   if(data.nonce!==nonce||data.beforeError||data.readError||data.endError||data.finishChangedBytes||pngChangedBytes||!data.defaultFramebuffer||!data.debug||data.quality!=='high'||!data.gpu.includes('RTX 3050')||data.preparationCalls!==(1)||data.modifiedRenderer!==(true)||data.programs.some(p=>!p.linked||p.log)){save(`${name}-${stage}-validation-failure.json`,JSON.stringify(data,null,2));throw Error('Invalid visual capture '+name+' '+stage);}
   return data;
  }
  const first=await capture('first',1);
  await page.locator('#startBtn').scrollIntoViewIfNeeded();const rect=await page.locator('#startBtn').boundingBox();
  for(const type of ['mousePressed','mouseReleased'])await cdp.send('Input.dispatchMouseEvent',{type,button:'left',clickCount:1,x:rect.x+rect.width/2,y:rect.y+rect.height/2});
  await cdp.send('Input.dispatchKeyEvent',{type:'keyDown',key:'w',code:'KeyW',windowsVirtualKeyCode:87});const moving=await capture('moving',60);
  await cdp.send('Input.dispatchKeyEvent',{type:'keyUp',key:'w',code:'KeyW',windowsVirtualKeyCode:87});
  for(let i=0;i<2;i++)for(const type of ['keyDown','keyUp'])await cdp.send('Input.dispatchKeyEvent',{type,key:'n',code:'KeyN',windowsVirtualKeyCode:78});const night=await capture('night',300);
  save(name+'.json',JSON.stringify({name,nonce,profile,browser:context.browser().version(),note:'Independent final-frame captures only; not performance data.',errors,warnings,first,moving,night},null,2));
  if(errors.length||moving.player.speed<=0)throw Error('Visual functional failure '+name);
  console.log(name+' independently captured; RGBA/PNG/finish checks passed');
 }finally{await context.close();}
}
(async()=>{
 for(const [label,mode]of [['A1','baseline'],['B','final'],['A2','baseline']])await run(label,mode);
 const all=Object.fromEntries(['A1','B','A2'].map(n=>[n,JSON.parse(fs.readFileSync(path.join(dir,`visual-${round}-${n}.json`)))])),results={};let passed=true;
 for(const stage of ['first','moving','night'])for(const n of ['B','A2']){
  const a=all.A1[stage],b=all[n][stage],rawA=fs.readFileSync(path.join(dir,`visual-${round}-A1-${stage}.rgba`)),rawB=fs.readFileSync(path.join(dir,`visual-${round}-${n}-${stage}.rgba`));let changedPixels=0,maxDelta=0;
  for(let i=0;i<rawA.length;i+=4){let changed=false;for(let k=0;k<4;k++){const delta=Math.abs(rawA[i+k]-rawB[i+k]);changed ||= delta!==0;maxDelta=Math.max(maxDelta,delta);}changedPixels+=changed;}
  const stateEqual=a.stateSHA256===b.stateSHA256&&a.trafficSHA256===b.trafficSHA256&&a.worldTransformsSHA256===b.worldTransformsSHA256&&JSON.stringify(a.camera)===JSON.stringify(b.camera)&&a.daylight===b.daylight;
  const conditionKeys=['width','height','window','gpu','quality','renderSettings','contextAttributes'],conditionsEqual=conditionKeys.every(k=>JSON.stringify(a[k])===JSON.stringify(b[k]));
  results[stage+'-A1-'+n]={changedPixels,maxDelta,stateEqual,conditionsEqual};if(changedPixels||!stateEqual||!conditionsEqual)passed=false;
 }
 save(`visual-${round}-comparison.json`,JSON.stringify({passed,independentNonces:new Set(Object.values(all).map(v=>v.nonce)).size===3,results},null,2));console.log(JSON.stringify({round,passed,results}));
 if(!passed)process.exitCode=2;
})().catch(e=>{save(`visual-${round}-failure.json`,JSON.stringify({error:e.stack},null,2));console.error(e.stack);process.exitCode=1;});
