const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,save=(n,j)=>fs.writeFileSync(path.join(dir,n),JSON.stringify(j,null,2),{flag:'wx'});
(async()=>{
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles','real-start-w'),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
  const page=context.pages()[0],errors=[],warnings=[];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());if(m.type()==='warning')warnings.push(m.text());});
  let observer=fs.readFileSync(path.join(dir,'observe-resource.js'),'utf8');
  observer=observer.replace("if(name==='buildPresentation'){d.ports=result;","if(name==='buildPresentation'){d.state=args[0].state;d.ports=result;");
  await page.addInitScript({content:'('+observer+')("A");'});
  await page.goto(pathToFileURL(path.join(dir,'index-final.html')).href,{waitUntil:'load',timeout:180000});
  await page.waitForFunction(()=>window.__lc?.settled==='fulfilled'&&window.__lc.mainFrames>=2,null,{timeout:150000});
  const first=await page.evaluate(()=>{const d=window.__lc;document.getElementById('startBtn').addEventListener('click',e=>d.clickTrusted=e.isTrusted,{once:true});document.addEventListener('keydown',e=>{if(e.code==='KeyW')d.keyTrusted=e.isTrusted;},{once:true});return{player:{...d.state.player},frames:d.mainFrames};});
  await page.locator('#startBtn').click();await page.keyboard.down('w');
  await page.waitForFunction(p=>{const x=window.__lc.state.player;return x.speed>0&&Math.hypot(x.x-p.x,x.z-p.z)>0.1;},first.player,{timeout:10000});
  await page.waitForTimeout(400);
  const running=await page.evaluate(()=>{const d=window.__lc,r=d.renderer,g=r.getContext();return{player:{...d.state.player},frames:d.mainFrames,clickTrusted:d.clickTrusted,keyTrusted:d.keyTrusted,debug:r.debug.checkShaderErrors,quality:d.ports.graphics.quality,glError:g.getError(),stats:r.__asyncStats,programs:r.info.programs.length,water:{wave:d.world.scene.userData.waterMaterial.userData.shader?.uniforms.waveTime?.value,strength:d.world.scene.userData.waterMaterial.userData.shader?.uniforms.reflectionStrength?.value},GPU:d.snapshot().GPU};});
  await page.keyboard.up('w');
  const after=await page.evaluate(()=>{const d=window.__lc;d.renderer.__startupClose();return d.snapshot();});
  save('real-start-w.json',{browser:context.browser().version(),first,running,after,errors,warnings,note:'Native runtime.start and requestAnimationFrame untouched; real browser mouse/keyboard events. Not a performance measurement.'});
  if(errors.length||!running.clickTrusted||!running.keyTrusted||!running.debug||running.quality!=='high'||running.glError||after.glError||after.pending||after.pollTimers||after.postDispose.length)throw Error('Real runtime smoke failed');
  for(const k of ['program','shader','texture','framebuffer','renderbuffer','buffer','vertexArray'])if(after.byKind[k].unrequested||after.byKind[k].duplicateDeletes)throw Error('Post-game cleanup failed '+k);
  console.log(JSON.stringify({first:first.player,moving:running.player,trusted:[running.clickTrusted,running.keyTrusted],debug:running.debug,quality:running.quality,byKind:after.byKind,errors}));
 }finally{await context.close();}
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
