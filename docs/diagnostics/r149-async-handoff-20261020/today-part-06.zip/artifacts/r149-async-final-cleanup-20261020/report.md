# B++: завершение ресурсной очистки

## Результат

В экспериментальной копии устранены последние восемь неудалённых текстур на окружение. Три последовательных реальных High-цикла на одном GL-контексте прошли без накопления отслеживаемых ресурсов. Production не изменена и не одобрена к интеграции.

Среда: оконный Edge 155.0.4283.62, file://, RTX 3050 Laptop через ANGLE/D3D11. Визуальные захваты: CSS 1528×694, DPR 1.25, framebuffer 1910×867, High, shader checks=true.

## Два разрешённых исправления

**Фасады.** `createFacadeResources()` создаёт шесть исходных CanvasTexture в `world.facadeMaterials`. Display передаёт тот же массив graphics как `facades`; материалы reflection building proxies заимствуют эти карты. Клоны фасадных карт основной сцены имеют собственные Texture-объекты; сбор только текстур основной сцены пропускал шесть оригиналов. `Material.dispose()` самостоятельно карты не уничтожает.

В экспериментальном `dispose-environment.js` добавлено только включение `world.facadeMaterials` в существующий Set текстур. Runtime остановлен, graphics отсоединяет отражения и завершает свои материалы; затем завершаются материалы мира, после них карты через **Texture.dispose()**. Set исключает повторные вызовы для алиасов. Это dedicated world cleanup, а не изменение владения заимствованными картами в действующей графике. Адресный цикл: texture **79/77**, остаток ровно два WebGLState fallback; framebuffer **20/20**. `stage1-acceptance.json`, `facade-patch.json`.

**Fallback.** Официальный `official/WebGLState.js` r149 создаёт одну raw native TEXTURE_2D и одну TEXTURE_CUBE_MAP в локальном `emptyTextures`. Стек двух оставшихся native ID совпал с этим конструктором. У исходного WebGLState нет dispose, renderer.dispose не освобождает эти handles.

В `three-stage2.js` добавлен локальный идемпотентный `state.dispose()`: удаляет только собственные fallback через native `deleteTexture`, очищает записи fallback и кэш texture bindings. Вызывается в конце окончательного renderer.dispose; **reset и bindTexture не изменены**. При потерянном контексте handles уже невалидны: записи очищаются без GL-delete. При восстановлении native r149 создаёт новый WebGLState, новая пара освобождается при завершении текущего renderer. Точный diff — `fallback-patch.json`. Более ранние shader/program, PMREM и framebuffer исправления сохранены.

## Ресурсные проверки

| Последовательный цикл | Program C/D | Shader C/D | Framebuffer C/D | Renderbuffer C/D | Texture C/D |
|---|---:|---:|---:|---:|---:|
| 1 | 89/89 | 178/178 | 20/20 | 15/15 | 79/79 |
| 2 | 178/178 | 356/356 | 40/40 | 30/30 | 158/158 |
| 3 | 267/267 | 534/534 | 60/60 | 45/45 | 237/237 |

Также buffer **9990/9990**, VAO **3342/3342**. Остаток без запроса удаления всех этих видов — 0; двойных delete и зафиксированных bind удалённой texture / draw после завершения — 0. Все шесть CubeUV outputs получили ровно один dispose. WebGL errors, pending promises, polling timers, pagehide handlers и зарегистрированные renderer programs после завершения — 0. Повторное закрытие не изменило счётчики. `cycles-1..3.json`, `resource-acceptance.json`.

Один уже delete-requested текущий program и два attached shader могут оставаться native-valid до смены binding; их число не растёт. Счётчики и сильные ссылки наблюдателя подтверждают запросы удаления, **не полное состояние системной/драйверной GPU-памяти**.

Изолированный `state-fixture-v2.json` подтвердил: обе fallback реально используются при bind(null), reset их сохраняет, повторный renderer.dispose не удаляет повторно. При native context loss старые handles невалидны без delete, после restore появляется новая пара и получает ровно два delete. Это проверка владельца WebGLState, не полная приёмка context loss async-игры. В первой оснастке restore запрашивался в microtask ещё незавершённого lost-event dispatch и получил INVALID_OPERATION; сохранён `state-fixture-failure.json`. Перенос запроса на следующий task исправил **только оснастку**, не renderer и не shader polling. В loss-сценариях ожидаемый CONTEXT_LOST_WEBGL=37442 фиксируется отдельно; нормальные сценарии — 0.

## Отмена и функциональная проверка

- Реальная отмена после наблюдения native COMPLETION_STATUS_KHR=false сохранила исходный signal.reason. Очистка: program **79/79**, shader **158/158**, texture **8/8**, framebuffer **10/10**, renderbuffer **8/8**. Pending/timers/handlers и GL errors — 0. `stage2-B.json`.
- `real-start-w.json`: настоящий runtime.start/requestAnimationFrame, доверенные browser mouse/keyboard events. Игрок сдвинулся x=68 → 64.8344, скорость достигла 11.8174. High, проверки включены, ошибок нет; после завершения texture **79/79**, framebuffer **20/20**, program **89/89**, shader **178/178**.
- Независимые A1/B/A2: первый кадр и ночь побитово совпали. В движении строгий пиксельный gate **false**: 13 318 пикселей, максимум 3 по каналу. Текущий B побитово равен историческому независимому A1; полная координатно-канальная маска и signed delta совпали с прежним A/A с обратным порядком сравнения (SHA256 delta совпали). **Допуски не менялись**, строгая идентичность движения не заявляется. `visual-1-comparison.json`, `functional-analysis.json`.
- Состояние игры, трафика, камеры/трансформаций, вода, audio samples и ключи программ совпали. RNG одинаков на всех трёх стадиях и 12 последующих checkpoints: первый кадр 175932 calls/seed 640593761. Вода: первый wave=0/strength=0; движение 1.016667/1; ночь 6.016667/1. Подготовлено 76, использовано 73, создано 89 программ — без изменения состава. Контрольные дневной/ночной PNG также осмотрены; сцена, вода и отражения присутствуют.

## Ограничения и сохранность

Остаются отдельные задачи до production: ошибка подготовки, отсутствие KHR, полная async-игра при context loss, окончательная визуальная и производительная приёмка. Известная A/A-нестабильность движения остаётся явно отмеченной. Полный performance A/B не запускался: изменения относятся к завершению ресурсов, алгоритм подготовки не менялся.

Все новые файлы — только в этом каталоге. `preservation-check.json` проверяет 128 целевых прежних файлов, включая оригинальный движок, предыдущие B+/B++, lifecycle/PMREM результаты и четыре shaderChecks-файла. `git-final.json` фиксирует HEAD/ветку/статус/индекс. Исторические каталоги не перезаписывались; build/check, commit/push не выполнялись. После отчёта работа остановлена.
