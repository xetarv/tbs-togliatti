const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');const dir=__dirname,root=path.resolve(dir,'../..');
const read=n=>JSON.parse(fs.readFileSync(path.join(dir,n))),runs=[];
for(let pair=1;pair<=3;pair++)for(const mode of ['A','B'])for(const kind of ['fresh','warm']){
 const name=`ab-${pair}-${mode}-${kind}`,j=read(name+'.json'),p=j.programObservation,prep=p.prepared,frame=i=>j.frames.find(f=>f.index===i),event=t=>j.menu.events.find(e=>e.type===t);
 const good=j.menu.successes.find(e=>e.success),preparedIDs=new Set(prep?.ids||[]),prepared=p.programs.filter(q=>preparedIDs.has(q.threeID));
 const end=j.controlReady+10000;
 const afterFrames=j.rows.filter(r=>r.n==='graphics.render'&&r.s>=j.controlReady&&r.s<end);
 const afterTasks=j.longtasks.filter(t=>t.s>=j.controlReady&&t.s<end);
 const errors=j.errors.length+p.glErrors.length+(j.glError!==0?1:0);
 const checks={oneWheel:j.menu.events.filter(e=>e.type==='wheel').length===1,oneClick:j.menu.events.filter(e=>e.type==='click').length===1,trustedClick:event('click').trusted,trustedWheel:event('wheel').trusted,control:Number.isFinite(j.controlReady),checksEnabled:j.debug,quality:j.webgl.quality==='high',gpu:j.webgl.renderer.includes('RTX 3050'),focused:j.window.focus,visible:j.window.visibility==='visible',noErrors:errors===0};
 checks.firstWaterNativeZero=j.firstWater?.nativeWave===0&&j.firstWater?.nativeStrength===0;
 if(Object.values(checks).some(x=>!x))throw Error('Run failed '+name+JSON.stringify(checks));
 const stats={menu:frame(j.menuFrameIndex).pageMs,earlyWheel:event('wheel').s,wheelQueue:event('wheel').s-event('wheel').eventTimestamp,start:good.s,firstFrame:j.firstRender.e,gpuFence:j.firstGPU,control:j.controlReady,firstFrameDuration:j.firstRender.e-j.firstRender.s,maxFrameAfterControl:Math.max(0,...afterFrames.map(r=>r.ms)),maxTaskAfterControl:Math.max(0,...afterTasks.map(t=>t.ms)),lateLinksAfterFirst:p.linked.filter(e=>e.s>j.firstRender.e&&e.s<end).length,lateLinksAfterControl:p.linked.filter(e=>e.s>j.controlReady&&e.s<end).length,created:p.created.length,used:p.used.length,prepared:prep?.submitted||0,preparedUsed:prepared.filter(q=>q.used).length,unusedPrepared:prepared.filter(q=>!q.used).length,lateAfterPreparation:prep?p.linked.filter(e=>e.s>prep.reflected).length:0,submit:prep?prep.submitEnd-prep.start:0,wait:prep?prep.ready-prep.submitEnd:0,poll:prep?.pollMs||0,reflection:prep?prep.reflected-prep.ready:0,errors};
 stats.startToControl=j.controlReady-good.s;
 stats.maxFrameAfterStart=Math.max(0,...j.rows.filter(r=>r.n==='graphics.render'&&r.s>=good.s&&r.s<end).map(r=>r.ms));
 runs.push({name,pair,mode,kind,stats,checks,firstWater:j.firstWater,browser:j.browser,webgl:j.webgl,window:j.window,warnings:j.warnings,slowAfterControl:p.slow.filter(e=>e.s>=j.controlReady&&e.s<end),preparation:prep});
}
const groups={};for(const kind of ['fresh','warm']){groups[kind]={};for(const mode of ['A','B']){groups[kind][mode]={};for(const key of Object.keys(runs[0].stats)){const values=runs.filter(r=>r.mode===mode&&r.kind===kind).map(r=>r.stats[key]).sort((a,b)=>a-b);groups[kind][mode][key]={median:values[1],min:values[0],max:values[2]};}}}
const preserved={};for(const [p,h]of Object.entries(read('preserved-before.json'))){preserved[p]=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex')===h;if(!preserved[p])throw Error('Changed production '+p);}
fs.writeFileSync(path.join(dir,'summary.json'),JSON.stringify({units:'ms unless count',runs,groups,preserved},null,2));console.log(JSON.stringify({groups,preserved},null,2));
