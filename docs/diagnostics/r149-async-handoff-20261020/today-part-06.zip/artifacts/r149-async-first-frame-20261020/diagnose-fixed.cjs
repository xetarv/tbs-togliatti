// Separate deterministic image/smoke check using the existing check-driving controlled-step approach.
// Never runs concurrently with performance measurements.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,root=path.resolve(dir,'../..');
async function run(name,mode){
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles','confirmed-'+mode),{
  executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,
  viewport:null,
  args:['--use-angle=d3d11','--enable-webgl','--enable-precise-memory-info'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
  const page=context.pages()[0],errors=[],warnings=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());if(m.type()==='warning'){warnings.push(m.text());if(/GL_INVALID|WebGL.*error/i.test(m.text()))errors.push(m.text());}});
  await page.addInitScript(()=>{
   localStorage.setItem('tbs.graphicsQuality','high');
   let seed=72421,api;
   Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
   Object.defineProperty(window,'TBS',{get:()=>api,set(value){api=value;
    for(const name of ['createScene','buildWorld','buildPresentation','createRuntime']){
     let fn;Object.defineProperty(api,name,{get:()=>fn,set(original){fn=(...args)=>{
      let restore;
     if(name==='createScene'){const T=args[0].T,C=T.WebGLRenderer;T.WebGLRenderer=new Proxy(C,{construct(target,params,newTarget){const r=Reflect.construct(target,params,newTarget);return r;}});restore=()=>{T.WebGLRenderer=C;};}
     let result;try{result=original(...args);}finally{if(restore)restore();}
      if(name==='buildWorld')window.__world=result;
      if(name==='buildPresentation'){window.__ports=result;window.__state=args[0].state;}
      if(name==='createRuntime'){window.__game=args[0].game;return{...result,start(){window.__game.initialize();window.__visualStarted=true;}};}
      return result;
     };}});
    }
   }});
  });
  const browser=await context.browser().newBrowserCDPSession(),target=await context.newCDPSession(page),{targetInfo}=await target.send('Target.getTargetInfo');
  const bounds=await browser.send('Browser.getWindowForTarget',{targetId:targetInfo.targetId});await browser.send('Browser.setWindowBounds',{windowId:bounds.windowId,bounds:{windowState:'maximized'}});await page.bringToFront();
  const url=pathToFileURL(path.join(dir,'index-'+mode+'.html'));url.search='';
  await page.goto(url.href,{waitUntil:'load',timeout:180000});
  await page.waitForFunction(()=>window.__visualStarted,null,{timeout:180000});
  const cdp=await context.newCDPSession(page);
  async function capture(stage,steps){
   const data=await page.evaluate(steps=>{
    const w=window.__world,r=w.renderer,g=r.getContext(),water=w.scene.userData.waterMaterial;let passes=[];
    const waterState=()=>{const shader=water.userData.shader,props=r.properties.get(water);return{published:!!shader,wave:shader?.uniforms.waveTime?.value,strength:shader?.uniforms.reflectionStrength?.value,propsWave:props.uniforms?.waveTime?.value,propsStrength:props.uniforms?.reflectionStrength?.value,sameUniforms:!!shader&&shader.uniforms===props.uniforms};};
    const beforeStep=waterState();const checkpoints=[{at:"before-step",error:g.getError()}];
    const render=r.render;r.render=function(sc,cam){const row={scene:sc===w.scene?'world':'auxiliary',camera:cam.type,target:!!r.getRenderTarget(),waterBefore:waterState()};passes.push(row);const out=render.call(this,sc,cam);row.waterAfter=waterState();if(sc===w.scene){const p=r.properties.get(water).currentProgram?.program;if(p){row.nativeWave=g.getUniform(p,g.getUniformLocation(p,'waveTime'));row.nativeStrength=g.getUniform(p,g.getUniformLocation(p,'reflectionStrength'));}}return out;};
    try{for(let i=0;i<steps;i++)window.__game.step(1/60);}finally{r.render=render;}
    checkpoints.push({at:"after-step",error:g.getError()}); const pixels=new Uint8Array(g.drawingBufferWidth*g.drawingBufferHeight*4);g.readPixels(0,0,g.drawingBufferWidth,g.drawingBufferHeight,g.RGBA,g.UNSIGNED_BYTE,pixels);
    checkpoints.push({at:'after-readPixels',error:g.getError()}); let binary='';for(let i=0;i<pixels.length;i+=32768)binary+=String.fromCharCode(...pixels.subarray(i,i+32768));
    const inventory={objects:0,meshes:0,instanced:0,instances:0,castShadow:0,receiveShadow:0,lights:0};
    w.scene.traverse(o=>{inventory.objects++;if(o.isMesh)inventory.meshes++;if(o.isInstancedMesh){inventory.instanced++;inventory.instances+=o.count;}if(o.castShadow)inventory.castShadow++;if(o.receiveShadow)inventory.receiveShadow++;if(o.isLight)inventory.lights++;});
    const programs=r.info.programs.map(p=>({name:p.name,linked:g.getProgramParameter(p.program,g.LINK_STATUS),log:g.getProgramInfoLog(p.program)}));
    checkpoints.push({at:'after-validation',error:g.getError()}); const png=r.domElement.toDataURL('image/png');checkpoints.push({at:'after-toDataURL',error:g.getError()}); return{waterBeforeStep:beforeStep,waterAfterStep:waterState(),checkpoints,pixels:btoa(binary),png,inventory,passes,programs,error:checkpoints.find(c=>c.error)?.error||g.getError(),debug:r.debug.checkShaderErrors,quality:window.__ports.graphics.quality,depthSupported:window.__ports.graphics.depthSupported,shadows:r.shadowMap.enabled,player:{x:window.__state.player.x,z:window.__state.player.z,speed:window.__state.player.speed},mode:window.__state.mode,daylight:window.__ports.timeline.daylight(),prepared:r.__asyncStats||null,window:{innerWidth,innerHeight,dpr:devicePixelRatio},renderer:g.getParameter(g.getExtension("WEBGL_debug_renderer_info").UNMASKED_RENDERER_WEBGL)};
   },steps);
   const pixels=Buffer.from(data.pixels,'base64');fs.writeFileSync(path.join(dir,name+'-'+stage+'.rgba'),pixels);
   fs.writeFileSync(path.join(dir,name+'-'+stage+'.png'),Buffer.from(data.png.split(',')[1],'base64'));
   delete data.pixels;delete data.png;data.pixelSHA256=crypto.createHash('sha256').update(pixels).digest('hex');
   return data;
  }
  const first=await capture('first',1);fs.writeFileSync(path.join(dir,name+'.json'),JSON.stringify({errors,warnings,first},null,2));if(errors.length||first.error)throw Error('Cause check failed');console.log(JSON.stringify({name,before:first.waterBeforeStep,after:first.waterAfterStep,world:first.passes.filter(p=>p.scene==='world').map(p=>({before:p.waterBefore,after:p.waterAfter,nativeWave:p.nativeWave,nativeStrength:p.nativeStrength}))}));
 }finally{await context.close();}
}
(async()=>{await run('confirmed-A','A');await run('confirmed-B','B');})().catch(e=>{console.error(e.stack);process.exitCode=1;});
