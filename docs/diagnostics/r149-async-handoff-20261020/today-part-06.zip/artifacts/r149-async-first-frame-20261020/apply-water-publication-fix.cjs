const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');const dir=__dirname,file=path.join(dir,'graphics-experimental.js'),original=fs.readFileSync(file,'utf8');let s=original;
function replace(a,b){if(s.split(a).length!==2)throw Error('Nonunique fix anchor');s=s.replace(a,b);}
replace('    const originalCompile = water.onBeforeCompile;',`    // Preparation may create uniforms, but must not expose them to game updates
    // earlier than stock r149's first actual draw of this water material.
    let deferredWaterShader;
    let deferWaterPublication = true;
    const originalWaterBeforeRender = water.onBeforeRender;
    function publishWaterOnFirstDraw(...args) {
        const result = originalWaterBeforeRender.apply(this, args);
        deferWaterPublication = false;
        if (deferredWaterShader !== undefined) water.userData.shader = deferredWaterShader;
        deferredWaterShader = undefined;
        water.onBeforeRender = originalWaterBeforeRender;
        return result;
    }
    water.onBeforeRender = publishWaterOnFirstDraw;
    const originalCompile = water.onBeforeCompile;`);
replace('        originalCompile(shader);',`        const hadPublishedShader = Object.hasOwn(water.userData, 'shader');
        const publishedShader = water.userData.shader;
        originalCompile(shader);
        if (deferWaterPublication) {
            deferredWaterShader = water.userData.shader;
            if (hadPublishedShader) water.userData.shader = publishedShader;
            else delete water.userData.shader;
        }`);
if(fs.existsSync(path.join(dir,'graphics-before-fix.js')))throw Error('Fix already applied');
fs.writeFileSync(path.join(dir,'graphics-before-fix.js'),original);fs.writeFileSync(file,s);
fs.writeFileSync(path.join(dir,'water-publication-fix.json'),JSON.stringify({change:'Defer publication only; do not reset shader uniforms or change render passes/material parameters',beforeSHA256:crypto.createHash('sha256').update(original).digest('hex'),afterSHA256:crypto.createHash('sha256').update(s).digest('hex')},null,2));
// Independent post-fix A1/B/A2. Earlier observations and historical results stay intact.
let visual=fs.readFileSync(path.join(dir,'visual.cjs'),'utf8').replaceAll("'profiles','visual-'+mode","'profiles','fixed-visual-'+mode").replaceAll('visual-A1','fixed-A1').replaceAll('visual-A2','fixed-A2').replaceAll('visual-B','fixed-B').replaceAll('visual-comparison.json','fixed-comparison.json').replaceAll("'visual-'+label","'fixed-'+label");
fs.writeFileSync(path.join(dir,'visual-fixed.cjs'),visual);
// Same observation as the cause test, with the corrected copy; not a new candidate.
const diagnosed=fs.readFileSync(path.join(dir,'diagnose.cjs'),'utf8').replaceAll("'profiles','cause-'+mode","'profiles','confirmed-'+mode").replaceAll("'cause-A'","'confirmed-A'").replaceAll("'cause-B'","'confirmed-B'");fs.writeFileSync(path.join(dir,'diagnose-fixed.cjs'),diagnosed);
console.log('Applied one water-publication lifecycle correction to experimental graphics only.');
