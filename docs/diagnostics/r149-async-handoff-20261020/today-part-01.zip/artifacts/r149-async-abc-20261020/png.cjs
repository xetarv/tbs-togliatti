// Minimal decoder for Chrome's non-interlaced 8-bit RGB/RGBA PNG screencast frames.
const zlib=require('node:zlib');
exports.decode=buffer=>{
 let at=8,w,h,type,depth,interlace;const chunks=[];
 while(at<buffer.length){const n=buffer.readUInt32BE(at),tag=buffer.toString('ascii',at+4,at+8),data=buffer.subarray(at+8,at+8+n);at+=n+12;
  if(tag==='IHDR'){w=data.readUInt32BE(0);h=data.readUInt32BE(4);depth=data[8];type=data[9];interlace=data[12];}if(tag==='IDAT')chunks.push(data);
 }
 if(depth!==8||![2,6].includes(type)||interlace!==0)throw Error('Unsupported screencast PNG format');
 const bpp=type===6?4:3,stride=w*bpp,raw=zlib.inflateSync(Buffer.concat(chunks)),pixels=Buffer.alloc(h*stride);
 const paeth=(a,b,c)=>{const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c;};
 let offset=0;for(let y=0;y<h;y++){const filter=raw[offset++];for(let x=0;x<stride;x++){
  const a=x>=bpp?pixels[y*stride+x-bpp]:0,b=y?pixels[(y-1)*stride+x]:0,c=y&&x>=bpp?pixels[(y-1)*stride+x-bpp]:0,v=raw[offset++];
  pixels[y*stride+x]=(v+(filter===0?0:filter===1?a:filter===2?b:filter===3?Math.floor((a+b)/2):filter===4?paeth(a,b,c):NaN))&255;
 }}return{w,h,bpp,pixels};
};
exports.button=im=>{
 const rows=[];for(let y=Math.floor(im.h*.45);y<im.h-12;y++){let count=0,min=im.w,max=0;
  for(let x=Math.floor(im.w*.2);x<im.w*.8;x++){const i=(y*im.w+x)*im.bpp,r=im.pixels[i],g=im.pixels[i+1],b=im.pixels[i+2];if(r>225&&g>50&&g<165&&b<130&&r>g*1.4){count++;min=Math.min(min,x);max=Math.max(max,x);}}
  if(count>=100)rows.push({y,count,min,max});
 }const groups=[];for(const r of rows){let g=groups.at(-1);if(!g||r.y-g.at(-1).y>4)groups.push(g=[]);g.push(r);}
 const candidates=groups.map(g=>({x0:Math.min(...g.map(r=>r.min)),x1:Math.max(...g.map(r=>r.max)),y0:g[0].y,y1:g.at(-1).y,count:g.reduce((n,r)=>n+r.count,0)})).filter(g=>g.y1-g.y0>=20&&g.y1-g.y0<=65&&g.x1-g.x0>=180&&g.x1-g.x0<=500&&g.count>=2500);
 return candidates.at(-1)||null;
};
