// External observation only; no click(), no synthetic DOM events or game mutations.
(() => {
 const m=window.__menuDiag={timeOrigin:performance.timeOrigin,domAt:null,registeredAt:null,events:[],successes:[]};
 const signal=x=>window.__menuSignal(JSON.stringify(x));
 const emit=(kind,extra={})=>signal({kind,s:performance.now(),timeOrigin:performance.timeOrigin,...extra});
 const observer=new MutationObserver(()=>{const b=document.getElementById('startBtn');if(b){m.domAt=performance.now();emit('dom');observer.disconnect();}});
 observer.observe(document,{childList:true,subtree:true});
 const add=EventTarget.prototype.addEventListener;
 EventTarget.prototype.addEventListener=function(...args){
  const result=Reflect.apply(add,this,args);
  if(this instanceof Element&&this.id==='startBtn'&&args[0]==='click'){
   m.registeredAt=performance.now();emit('registered');EventTarget.prototype.addEventListener=add;
  }
  return result;
 };
 for(const type of ['pointerover','mousedown','mouseup','click','keydown','wheel','scroll'])Reflect.apply(add,window,[type,e=>{
  const target=e.target instanceof Element?e.target.closest('#startBtn'):null;
  if(!target&&!['keydown','wheel','scroll'].includes(type))return;
  m.events.push({type,s:performance.now(),eventTimestamp:e.timeStamp,trusted:e.isTrusted,target:e.target.id,key:e.code,scrollTop:e.target.scrollTop,deltaY:e.deltaY});
 },{capture:true,passive:true}]);
 Reflect.apply(add,window,['click',e=>{
  if(!(e.target instanceof Element)||!e.target.closest('#startBtn'))return;
  const d=window.__bootDiag,success=d?.state?.mode==='playing'&&document.getElementById('overlay').classList.contains('hidden');
  const row={s:performance.now(),trusted:e.isTrusted,success,mode:d?.state?.mode,hidden:document.getElementById('overlay').classList.contains('hidden')};
  m.successes.push(row);if(success&&d.keyRequested==null)d.keyRequested=performance.now();emit('click-result',row);
 },false]);
})();
