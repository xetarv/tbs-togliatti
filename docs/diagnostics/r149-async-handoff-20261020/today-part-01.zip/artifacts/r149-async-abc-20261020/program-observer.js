// External measurement only: preserve all GL return values and arguments.
(()=>{
 const d=window.__programDiag={created:[],linked:[],used:[],slow:[],glErrors:[]},ids=new WeakMap(),seen=new WeakSet();let next=0;
 const phase=()=>window.__bootDiag?.firstRender?'after-first-frame':window.__bootDiag?.rows.some(r=>r.n==='graphics.render'&&r.ms===0)?'first-frame':'before-first-frame';
 for(const proto of [WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype])for(const name of ['createProgram','deleteProgram','linkProgram','useProgram','getProgramParameter','getProgramInfoLog','getShaderInfoLog','getActiveUniform','getUniformLocation','getActiveAttrib','getAttribLocation','drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced','getError']){
  const original=proto[name];if(!original||original.__programObserved)continue;
  const wrapped=function(...args){const s=performance.now();let result;try{result=Reflect.apply(original,this,args);return result;}finally{
   const ms=performance.now()-s;
   if(name==='createProgram'&&result){ids.set(result,++next);d.created.push({id:next,s});}
   const id=ids.get(args[0]);
   if(name==='linkProgram')d.linked.push({id,s,ms,phase:phase()});
   if(name==='useProgram'&&args[0]&&!seen.has(args[0])){seen.add(args[0]);d.used.push({id,s,phase:phase()});}
   if(name==='getError'&&result)d.glErrors.push({s,error:result});
   if(ms>=5)d.slow.push({name,id,s,ms,param:name==='getProgramParameter'?args[1]:undefined,phase:phase()});
  }};wrapped.__programObserved=true;proto[name]=wrapped;
 }
 d.snapshot=r=>({created:d.created,linked:d.linked,used:d.used,slow:d.slow,glErrors:d.glErrors,prepared:r.__asyncStats||null,programs:r.info.programs.map(p=>({threeID:p.id,nativeID:ids.get(p.program),name:p.name,used:seen.has(p.program),cacheKey:p.cacheKey}))});
})();
