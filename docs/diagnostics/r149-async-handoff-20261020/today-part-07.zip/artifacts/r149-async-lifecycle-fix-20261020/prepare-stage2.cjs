const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{pathToFileURL}=require('node:url');
const dir=__dirname,sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const b=JSON.parse(fs.readFileSync(path.join(dir,'stage1-B.json'))),a=JSON.parse(fs.readFileSync(path.join(dir,'stage1-T.json')));
for(const j of [a,b]){const s=j.settled;if(s.rendererPrograms.length||s.pending||s.pollTimers||s.pagehideActive||s.glError||s.postDispose.length)throw Error('Stage 1 gate failed');for(const k of ['program','shader','buffer','framebuffer','renderbuffer'])if(s.byKind[k].unrequested||s.byKind[k].duplicateDeletes)throw Error('Stage 1 owner cleanup '+k);}
if(!b.settled.reason.sameAbort||!b.settled.triggered||b.settled.graphicsDisposeCalls!==1)throw Error('Abort not confirmed');
fs.writeFileSync(path.join(dir,'stage1-acceptance.json'),JSON.stringify({passed:true,programs:{cancel:b.settled.byKind.program,stock:a.settled.byKind.program},shaders:{cancel:b.settled.byKind.shader,stock:a.settled.byKind.shader},baselineTextures:a.settled.byKind.texture,remainingTextures:b.settled.byKind.texture,meaning:'Explicit delete requests, not instantaneous native destruction; one currently bound deleted program/shaders and two renderer state textures also exist in stock A. No context loss used.'},null,2),{flag:'wx'});
let engine=fs.readFileSync(path.join(dir,'three-stage1.js'),'utf8');const before=engine;
const old='ot.dispose(),lt.dispose(),$.dispose(),tt.dispose(),et.dispose(),rt.dispose()';
const next='ot.dispose(),lt.dispose(),ut.dispose(),tt.dispose(),et.dispose(),$.dispose(),rt.dispose()';
if(engine.split(old).length!==2)throw Error('Renderer disposal anchor');engine=engine.replace(old,next);
fs.writeFileSync(path.join(dir,'three-stage2.js'),engine,{flag:'wx'});
fs.writeFileSync(path.join(dir,'stage2-engine-patch.json'),JSON.stringify({beforeSHA256:sha(before),afterSHA256:sha(engine),before:old,after:next,reason:'Dispose private ShadowMap and PMREM owners through Material.dispose before renderer material properties are discarded; no native deletion/refcount changes.'},null,2),{flag:'wx'});
let html=fs.readFileSync(path.join(dir,'index-stage1.html'),'utf8').replace(pathToFileURL(path.join(dir,'three-stage1.js')).href,pathToFileURL(path.join(dir,'three-stage2.js')).href);fs.writeFileSync(path.join(dir,'index-stage2.html'),html,{flag:'wx'});
console.log('Stage 1 accepted; stage 2 changes only private owner disposal order.');
