// Terminal cleanup for this dedicated experimental game environment only.
// No GL handles, refcount edits, renderer sharing or reusable resource manager.
function installStartupEnvironmentCleanup(world, runtime) {
  const r = world.renderer;
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    const errors = [];
    const attempt = (owner, dispose) => {
      try { dispose(); } catch (error) { errors.push({ owner, error }); }
    };
    attempt('runtime', () => runtime.stop());
    const instances = new Set();
    // Native InstancedMesh clones own their instance attributes, while borrowing
    // world materials/geometries. Capture before graphics detaches those clones.
    attempt('instance owners', () => {
      for (const pass of r.__startupPasses()) pass.scene.traverse(o => {
        if (o.isInstancedMesh) instances.add(o);
      });
    });
    attempt('graphics', () => r.__startupDispose());
    const materials = new Set(), geometries = new Set(), textures = new Set(), shadows = new Set();
    const texture = value => {
      if (value?.isTexture && !value.isRenderTargetTexture) textures.add(value);
    };
    attempt('world owners', () => world.scene.traverse(o => {
      if (o.shadow) shadows.add(o.shadow);
      if (o.geometry) geometries.add(o.geometry);
      if (o.material) for (const m of Array.isArray(o.material) ? o.material : [o.material]) materials.add(m);
    }));
    for (const m of materials) {
      for (const value of Object.values(m)) texture(value);
      if (m.uniforms) for (const uniform of Object.values(m.uniforms)) {
        if (Array.isArray(uniform.value)) uniform.value.forEach(texture);
        else texture(uniform.value);
      }
    }
    for (const instance of instances) attempt('instance', () => instance.dispose());
    for (const shadow of shadows) attempt('light shadow', () => shadow.dispose());
    for (const material of materials) attempt('world material', () => material.dispose());
    for (const geometry of geometries) attempt('world geometry', () => geometry.dispose());
    for (const map of textures) attempt('world texture', () => map.dispose());
    attempt('scene environment target', () => world.startupEnvironmentTarget.dispose());
    // The private owner exposes its native Material.dispose path; never destroy
    // registered programs or change usedTimes from the preparation controller.
    if (r.shadowMap.dispose) attempt('shadow map owner', () => r.shadowMap.dispose());
    attempt('renderer', () => r.dispose());
    delete r.__startupPasses;
    delete r.__startupDispose;
    delete r.__startupClose;
    if (errors.length) throw new AggregateError(errors.map(e => e.error), 'Experimental environment cleanup failed: ' + errors.map(e => e.owner).join(', '));
  };
  r.__startupClose = close;
  return close;
}
