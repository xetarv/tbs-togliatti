/* Local graphics pipeline for the bundled Three.js r149. No external assets. */
'use strict';
window.TBS.createGraphics = function ({ T, renderer, scene, camera, sky, car, water, buildings, facades, reflectObjects = [], initialQuality, }) {
    let disposed = false;
    const waterBindings = new Map();
    const environmentMaps = new Map();
    const originalAutoReset = renderer.info.autoReset;
    const presets = {
        low: { ratio: 1, shadow: 0, ao: 0, bloom: 0, reflection: 0, distance: 85 },
        medium: { ratio: 1.3, shadow: 1024, ao: 0.35, bloom: 0.09, reflection: 0, distance: 110 },
        high: { ratio: 1.75, shadow: 2048, ao: 0.55, bloom: 0.15, reflection: 1, distance: 135 },
    };
    let quality = Object.hasOwn(presets, initialQuality) ? initialQuality : 'medium', settings = presets[quality], clock = 0, cubeDue = -10, waterDue = -10;
    renderer.info.autoReset = false;
    const depthSupported = renderer.capabilities.isWebGL2 || renderer.extensions.has('WEBGL_depth_texture');
    const sceneTarget = new T.WebGLRenderTarget(1, 1, {
        minFilter: T.LinearFilter,
        magFilter: T.LinearFilter,
    });
    sceneTarget.depthTexture = new T.DepthTexture(1, 1, T.UnsignedIntType);
    const postScene = new T.Scene(), postCamera = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const uniforms = {
        image: { value: sceneTarget.texture },
        depth: { value: sceneTarget.depthTexture },
        pixel: { value: new T.Vector2(1, 1) },
        inverseProjection: { value: camera.projectionMatrixInverse },
        ao: { value: 0 },
        glow: { value: 0 },
    };
    const postMaterial = new T.ShaderMaterial({
        depthTest: false,
        depthWrite: false,
        toneMapped: false,
        extensions: { derivatives: true },
        uniforms,
        vertexShader: 'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}',
        fragmentShader: `varying vec2 vUv;uniform sampler2D image;uniform sampler2D depth;uniform vec2 pixel;uniform mat4 inverseProjection;uniform float ao;uniform float glow;
      vec3 viewPosition(vec2 uv){float d=texture2D(depth,uv).x;vec4 p=inverseProjection*vec4(uv*2.-1.,d*2.-1.,1.);return p.xyz/p.w;}
      vec3 antialiased(vec2 uv){
        vec3 middle=texture2D(image,uv).rgb,nw=texture2D(image,uv+vec2(-1.,-1.)*pixel).rgb,ne=texture2D(image,uv+vec2(1.,-1.)*pixel).rgb,sw=texture2D(image,uv+vec2(-1.,1.)*pixel).rgb,se=texture2D(image,uv+pixel).rgb;
        vec3 luma=vec3(.299,.587,.114);float m=dot(middle,luma),a=dot(nw,luma),b=dot(ne,luma),c=dot(sw,luma),d=dot(se,luma),lo=min(m,min(min(a,b),min(c,d))),hi=max(m,max(max(a,b),max(c,d)));
        if(hi-lo<max(.025,hi*.125))return middle;
        vec2 direction=vec2(-((a+b)-(c+d)),(a+c)-(b+d));float reduce=max((a+b+c+d)*.03125,.0078125);direction=clamp(direction/(min(abs(direction.x),abs(direction.y))+reduce),vec2(-6.),vec2(6.))*pixel;
        vec3 small=.5*(texture2D(image,uv-direction/6.).rgb+texture2D(image,uv+direction/6.).rgb);
        vec3 wide=small*.5+.25*(texture2D(image,uv-direction*.5).rgb+texture2D(image,uv+direction*.5).rgb);float l=dot(wide,luma);return l<lo||l>hi?small:wide;
      }
      void main(){
        vec3 color=antialiased(vUv);float d=texture2D(depth,vUv).x;float obstruction=0.;
        if(d<.99995&&ao>0.){
          vec3 p=viewPosition(vUv);vec3 normal=normalize(cross(dFdx(p),dFdy(p)));float radius=clamp(110./max(-p.z,1.),2.,15.);
          for(int i=0;i<8;i++){float a=float(i)*2.399963;vec2 offset=vec2(cos(a),sin(a))*pixel*radius*(.45+.55*float(i+1)/8.);vec3 delta=viewPosition(clamp(vUv+offset,pixel,1.-pixel))-p;float distance=length(delta);
            obstruction+=max(0.,dot(normal,delta/max(distance,.001))-.12)*(1.-smoothstep(.15,2.2,distance));}
          color*=1.-min(.3,obstruction*ao/4.);
        }
        if(glow>0.){
          vec3 bloom=vec3(0.);
          for(int i=0;i<8;i++){float a=float(i)*.785398;vec2 offset=vec2(cos(a),sin(a))*pixel*4.;vec3 sampleColor=texture2D(image,clamp(vUv+offset,vec2(0.),vec2(1.))).rgb;bloom+=sampleColor*smoothstep(.72,1.,max(max(sampleColor.r,sampleColor.g),sampleColor.b));}
          color+=bloom*(glow/8.);
        }
        gl_FragColor=vec4(color,1.);
        #include <encodings_fragment>
      }`,
    });
    const postGeometry = new T.PlaneGeometry(2, 2);
    postScene.add(new T.Mesh(postGeometry, postMaterial));
    // A small reflection scene reproduces nearby building volumes and facades.
    const reflectionScene = new T.Scene();
    reflectionScene.environment = scene.environment;
    const reflectionSky = sky.clone();
    reflectionScene.add(reflectionSky);
    const ambient = new T.HemisphereLight(0xc4d8ef, 0x596459, 2);
    reflectionScene.add(ambient);
    const reflectionSun = new T.DirectionalLight(0xffdfbe, 2);
    reflectionSun.position.set(-35, 62, 40);
    reflectionScene.add(reflectionSun);
    const proxies = [], proxyGeometry = new T.BoxGeometry(1, 1, 1), proxyMaterials = new Map();
    const reflectionObjects = new Map();
    const buildingProxies = new Map();
    let quarterDirty = false;
    // Reconcile only on explicit world changes. Native clones borrow world resources.
    function orderReflections() {
        const objects = [...reflectionObjects.values(), ...proxies];
        reflectionScene.remove(...objects);
        for (const object of objects)
            reflectionScene.add(object);
    }
    function setReflectionObjects(sources) {
        if (disposed)
            return;
        const next = new Map();
        const previous = [...reflectionObjects.keys()];
        for (const source of sources) {
            if (!next.has(source))
                next.set(source, reflectionObjects.get(source) || source.clone(true));
        }
        if (next.size === previous.length &&
            [...next.keys()].every((source, i) => source === previous[i]))
            return;
        for (const [source, mesh] of reflectionObjects) {
            if (!next.has(source))
                reflectionScene.remove(mesh);
        }
        reflectionObjects.clear();
        for (const [source, mesh] of next)
            reflectionObjects.set(source, mesh);
        orderReflections();
        quarterDirty = true;
    }
    function setReflectionBuildings(sources) {
        if (disposed)
            return;
        const next = new Map();
        const usedMaterials = new Set();
        let changed = false;
        for (const b of sources) {
            if (next.has(b))
                continue;
            const key = b.color + ':' + (b.seed % facades.length);
            if (!proxyMaterials.has(key))
                proxyMaterials.set(key, new T.MeshStandardMaterial({
                    color: b.color,
                    map: facades[b.seed % facades.length],
                    roughness: 0.65,
                }));
            const proxy = buildingProxies.get(b) || new T.Mesh(proxyGeometry, proxyMaterials.get(key));
            if (proxies[next.size] !== proxy ||
                proxy.material !== proxyMaterials.get(key) ||
                proxy.position.x !== b.x ||
                proxy.position.y !== b.h / 2 ||
                proxy.position.z !== b.z ||
                proxy.scale.x !== b.w ||
                proxy.scale.y !== b.h ||
                proxy.scale.z !== b.d)
                changed = true;
            proxy.material = proxyMaterials.get(key);
            proxy.position.set(b.x, b.h / 2, b.z);
            proxy.scale.set(b.w, b.h, b.d);
            next.set(b, proxy);
            usedMaterials.add(key);
        }
        if (!changed && next.size === buildingProxies.size)
            return;
        for (const [source, proxy] of buildingProxies) {
            if (!next.has(source))
                reflectionScene.remove(proxy);
        }
        buildingProxies.clear();
        proxies.length = 0;
        for (const [source, proxy] of next) {
            buildingProxies.set(source, proxy);
            proxies.push(proxy);
        }
        orderReflections();
        for (const [key, material] of proxyMaterials) {
            if (usedMaterials.has(key))
                continue;
            material.dispose();
            proxyMaterials.delete(key);
        }
        quarterDirty = true;
    }
    setReflectionObjects(reflectObjects);
    setReflectionBuildings(buildings);
    quarterDirty = false;
    const cubeTarget = new T.WebGLCubeRenderTarget(128, {
        generateMipmaps: true,
        minFilter: T.LinearMipmapLinearFilter,
    });
    const cubeCamera = new T.CubeCamera(0.3, 120, cubeTarget);
    const quarter = scene.userData.quarterLighting;
    const quarterTarget = quarter
        ? new T.WebGLCubeRenderTarget(128, {
            generateMipmaps: true,
            minFilter: T.LinearMipmapLinearFilter,
        })
        : null;
    const quarterCamera = quarter ? new T.CubeCamera(0.3, 120, quarterTarget) : null;
    let quarterDaylight = -1, quarterDue = -10;
    const waterTarget = new T.WebGLRenderTarget(512, 256, {
        minFilter: T.LinearFilter,
        magFilter: T.LinearFilter,
    });
    const mirrorCamera = new T.PerspectiveCamera(), mirrorDirection = new T.Vector3(), reflectionMatrix = new T.Matrix4();
    let cubeReady = false, waterReady = false;
    const originalCompile = water.onBeforeCompile;
    const compileWater = (shader) => {
        originalCompile(shader);
        if (disposed)
            return;
        const previous = waterBindings.get(shader)?.previous || {
            waterReflection: shader.uniforms.waterReflection,
            waterReflectionMatrix: shader.uniforms.waterReflectionMatrix,
            reflectionStrength: shader.uniforms.reflectionStrength,
        };
        shader.uniforms.waterReflection = { value: waterTarget.texture };
        shader.uniforms.waterReflectionMatrix = { value: reflectionMatrix };
        shader.uniforms.reflectionStrength = { value: 0 };
        waterBindings.set(shader, {
            previous,
            installed: {
                waterReflection: shader.uniforms.waterReflection,
                waterReflectionMatrix: shader.uniforms.waterReflectionMatrix,
                reflectionStrength: shader.uniforms.reflectionStrength,
            },
        });
        shader.vertexShader =
            'uniform mat4 waterReflectionMatrix;varying vec4 vWaterReflection;\n' + shader.vertexShader;
        shader.vertexShader = shader.vertexShader.replace('#include <project_vertex>', 'vWaterReflection=waterReflectionMatrix*modelMatrix*vec4(transformed,1.0);\n#include <project_vertex>');
        shader.fragmentShader =
            'uniform sampler2D waterReflection;uniform float reflectionStrength;varying vec4 vWaterReflection;\n' +
                shader.fragmentShader;
        shader.fragmentShader = shader.fragmentShader.replace('#include <output_fragment>', `
      vec2 reflectionUv=vWaterReflection.xy/max(vWaterReflection.w,.001)*.5+.5;
      reflectionUv+=normal.xy*.009;
      float inFrame=step(0.,reflectionUv.x)*step(reflectionUv.x,1.)*step(0.,reflectionUv.y)*step(reflectionUv.y,1.)*step(0.,vWaterReflection.w);
      vec3 reflected=texture2D(waterReflection,clamp(reflectionUv,vec2(.001),vec2(.999))).rgb*vec3(.6,.8,.92);
      float fresnel=pow(1.-clamp(dot(normal,normalize(vViewPosition)),0.,1.),2.);
      outgoingLight=mix(outgoingLight,reflected,inFrame*reflectionStrength*(.1+.38*fresnel));
      #include <output_fragment>`);
    };
    water.onBeforeCompile = compileWater;
    water.needsUpdate = true;
    function setEnvironmentMap(material, map) {
        if (!environmentMaps.has(material))
            environmentMaps.set(material, material.envMap);
        material.envMap = map;
        material.needsUpdate = true;
    }
    function resize() {
        if (disposed)
            return;
        renderer.setPixelRatio(Math.min(devicePixelRatio || 1, settings.ratio));
        renderer.setSize(innerWidth, innerHeight, false);
        const size = renderer.getDrawingBufferSize(new T.Vector2());
        sceneTarget.setSize(quality === 'low' ? 1 : size.x, quality === 'low' ? 1 : size.y);
        uniforms.pixel.value.set(1 / size.x, 1 / size.y);
        waterTarget.setSize(Math.min(768, Math.max(256, Math.round(innerWidth * 0.5))), Math.min(512, Math.max(128, Math.round(innerHeight * 0.5))));
        waterReady = false;
        waterDue = -10;
    }
    function setQuality(value) {
        if (disposed)
            return quality;
        quality = Object.hasOwn(presets, value) ? value : 'medium';
        settings = presets[quality];
        renderer.shadowMap.enabled = settings.shadow > 0;
        scene.traverse((o) => {
            if (o.isDirectionalLight && o.castShadow) {
                o.shadow.mapSize.set(settings.shadow || 512, settings.shadow || 512);
                if (o.shadow.map) {
                    o.shadow.map.dispose();
                    o.shadow.map = null;
                }
                o.shadow.needsUpdate = true;
            }
        });
        if (!settings.reflection) {
            setEnvironmentMap(car.userData.paint, null);
        }
        if (quarter)
            for (const material of quarter.reflective) {
                setEnvironmentMap(material, settings.reflection && quarterDaylight >= 0 ? quarterTarget.texture : null);
            }
        cubeDue = -10;
        waterDue = -10;
        resize();
        try {
            localStorage.setItem('tbs.graphicsQuality', quality);
        }
        catch {
            // Graphics settings still work when the browser disables persistent storage.
        }
        return quality;
    }
    function updateCube(camera, target) {
        const generateMipmaps = target.texture.generateMipmaps;
        try {
            camera.update(renderer, reflectionScene);
        }
        finally {
            // r149 CubeCamera changes this flag before rendering its six faces.
            target.texture.generateMipmaps = generateMipmaps;
        }
    }
    function updateReflections(dt, daylight) {
        clock += dt;
        if (!settings.reflection) {
            if (water.userData.shader)
                water.userData.shader.uniforms.reflectionStrength.value = 0;
            return;
        }
        const refreshCube = clock - cubeDue > 0.85, refreshWater = camera.position.z < 90 && clock - waterDue > 0.12;
        const refreshQuarter = quarter &&
            Math.hypot(camera.position.x - quarter.x, camera.position.z - quarter.z) < 90 &&
            (quarterDirty || Math.abs(daylight - quarterDaylight) > 0.12) &&
            clock - quarterDue > 1;
        if (refreshCube || refreshWater || refreshQuarter) {
            ambient.intensity = 0.55 + 1.45 * daylight;
            reflectionSun.intensity = 0.1 + 1.9 * daylight;
            for (const [source, mesh] of reflectionObjects) {
                mesh.position.copy(source.position);
                mesh.quaternion.copy(source.quaternion);
                mesh.visible = source.position.distanceToSquared(car.position) < 120 * 120;
            }
            for (const proxy of proxies)
                proxy.visible =
                    Math.abs(proxy.position.x - car.position.x) < 110 &&
                        Math.abs(proxy.position.z - car.position.z) < 110;
        }
        const previousToneMapping = renderer.toneMapping;
        if (refreshCube || refreshWater || refreshQuarter)
            renderer.toneMapping = T.NoToneMapping;
        if (refreshQuarter) {
            quarterDue = clock;
            quarterDaylight = daylight;
            for (const proxy of proxies)
                proxy.visible =
                    Math.abs(proxy.position.x - quarter.x) < 110 &&
                        Math.abs(proxy.position.z - quarter.z) < 110;
            quarterCamera.position.set(quarter.x + 12.5, 4, quarter.z - 5.8);
            reflectionSky.position.copy(quarterCamera.position);
            updateCube(quarterCamera, quarterTarget);
            quarterDirty = false;
            quarterTarget.texture.needsPMREMUpdate = true;
            for (const material of quarter.reflective) {
                setEnvironmentMap(material, quarterTarget.texture);
            }
            for (const proxy of proxies)
                proxy.visible =
                    Math.abs(proxy.position.x - car.position.x) < 110 &&
                        Math.abs(proxy.position.z - car.position.z) < 110;
        }
        if (refreshCube) {
            cubeDue = clock;
            cubeCamera.position.copy(car.position);
            cubeCamera.position.y = 2;
            reflectionSky.position.copy(cubeCamera.position);
            updateCube(cubeCamera, cubeTarget);
            cubeTarget.texture.needsPMREMUpdate = true;
            if (!cubeReady) {
                setEnvironmentMap(car.userData.paint, cubeTarget.texture);
                cubeReady = true;
            }
            // Switching back from a cheaper preset restores the same reusable target.
            if (car.userData.paint.envMap !== cubeTarget.texture) {
                setEnvironmentMap(car.userData.paint, cubeTarget.texture);
            }
        }
        if (refreshWater) {
            waterDue = clock;
            mirrorCamera.copy(camera);
            mirrorCamera.position.y = 0.04 - camera.position.y;
            mirrorCamera.up.set(0, -1, 0);
            camera.getWorldDirection(mirrorDirection);
            mirrorDirection.y = -mirrorDirection.y;
            mirrorCamera.lookAt(mirrorDirection.add(mirrorCamera.position));
            mirrorCamera.updateMatrixWorld();
            reflectionMatrix.multiplyMatrices(mirrorCamera.projectionMatrix, mirrorCamera.matrixWorldInverse);
            reflectionSky.position.copy(mirrorCamera.position);
            renderer.setRenderTarget(waterTarget);
            renderer.render(reflectionScene, mirrorCamera);
            renderer.setRenderTarget(null);
            waterReady = true;
        }
        if (water.userData.shader)
            water.userData.shader.uniforms.reflectionStrength.value =
                waterReady && camera.position.z < 90 ? 1 : 0;
        renderer.toneMapping = previousToneMapping;
    }
    renderer.__startupPasses=()=>[
      {name:'main-linear',scene,camera,target:sceneTarget,toneMapping:renderer.toneMapping},
      {name:'reflection-cube-linear',scene:reflectionScene,camera:cubeCamera.children[0],target:cubeTarget,toneMapping:T.NoToneMapping},
      {name:'water-reflection-linear',scene:reflectionScene,camera:mirrorCamera,target:waterTarget,toneMapping:T.NoToneMapping},
      {name:'post-output',scene:postScene,camera:postCamera,target:null,toneMapping:renderer.toneMapping}
    ];
    function render(dt, daylight) {
        if (disposed)
            return;
        const previousTarget = renderer.getRenderTarget();
        const previousFace = renderer.getActiveCubeFace();
        const previousMipmap = renderer.getActiveMipmapLevel();
        const previousToneMapping = renderer.toneMapping;
        const previousXr = renderer.xr.enabled;
        let completed = false;
        try {
            renderFrame(dt, daylight);
            completed = true;
        }
        finally {
            if (!completed) {
                renderer.toneMapping = previousToneMapping;
                renderer.xr.enabled = previousXr;
                renderer.setRenderTarget(previousTarget, previousFace, previousMipmap);
            }
        }
    }
    function renderFrame(dt, daylight) {
        renderer.info.reset();
        updateReflections(dt, daylight);
        if (quality === 'low' || !depthSupported) {
            renderer.setRenderTarget(null);
            renderer.render(scene, camera);
            return;
        }
        uniforms.ao.value = settings.ao;
        uniforms.glow.value = settings.bloom * (1 - daylight);
        uniforms.inverseProjection.value = camera.projectionMatrixInverse;
        renderer.setRenderTarget(sceneTarget);
        renderer.render(scene, camera);
        renderer.setRenderTarget(null);
        renderer.render(postScene, postCamera);
    }
    function dispose() {
        if (disposed)
            return;
        disposed = true;
        const targets = [sceneTarget, cubeTarget, quarterTarget, waterTarget];
        if (targets.some((target) => target !== null && renderer.getRenderTarget() === target))
            renderer.setRenderTarget(null);
        for (const [material, original] of environmentMaps) {
            if (material.envMap === cubeTarget.texture ||
                (quarterTarget && material.envMap === quarterTarget.texture)) {
                material.envMap = original;
                material.needsUpdate = true;
            }
        }
        environmentMaps.clear();
        let recompileWater = false;
        for (const [shader, binding] of waterBindings) {
            for (const name of [
                'waterReflection',
                'waterReflectionMatrix',
                'reflectionStrength',
            ]) {
                if (shader.uniforms[name] !== binding.installed[name])
                    continue;
                const previous = binding.previous[name];
                if (previous)
                    shader.uniforms[name] = previous;
                else
                    delete shader.uniforms[name];
                recompileWater = true;
            }
        }
        waterBindings.clear();
        if (water.onBeforeCompile === compileWater) {
            water.onBeforeCompile = originalCompile;
            recompileWater = true;
        }
        if (recompileWater)
            water.needsUpdate = true;
        // Native Mesh.clone shares materials/geometries: detach clones, never dispose them.
        reflectionScene.remove(...reflectionScene.children);
        reflectionScene.environment = null;
        postScene.remove(...postScene.children);
        reflectionObjects.clear();
        buildingProxies.clear();
        proxies.length = 0;
        postGeometry.dispose();
        postMaterial.dispose();
        proxyGeometry.dispose();
        for (const material of proxyMaterials.values())
            material.dispose();
        proxyMaterials.clear();
        // r149's renderer disposes an initialized target's depth texture via its listener.
        // A never-rendered target has no such listener, so dispose that texture explicitly.
        const depth = sceneTarget.depthTexture;
        let depthDisposed = false;
        const onDepthDispose = () => {
            depthDisposed = true;
        };
        if (depth)
            depth.addEventListener('dispose', onDepthDispose);
        try {
            sceneTarget.dispose();
            if (depth && !depthDisposed)
                depth.dispose();
        }
        finally {
            if (depth)
                depth.removeEventListener('dispose', onDepthDispose);
        }
        cubeTarget.dispose();
        if (quarterTarget)
            quarterTarget.dispose();
        waterTarget.dispose();
        if (renderer.info.autoReset === false)
            renderer.info.autoReset = originalAutoReset;
    }
    setQuality(quality);
    return {
        dispose,
        setReflectionObjects,
        setReflectionBuildings,
        render,
        resize,
        setQuality,
        get quality() {
            return quality;
        },
        get distance() {
            return settings.distance;
        },
        get depthSupported() {
            return depthSupported;
        },
    };
};
