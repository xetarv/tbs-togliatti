// Separate deterministic image/smoke check using the existing check-driving controlled-step approach.
// Never runs concurrently with performance measurements.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,root=path.resolve(dir,'../..');
async function run(name,mode){
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles','fixed-visual-'+mode),{
  executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,
  viewport:null,
  args:['--use-angle=d3d11','--enable-webgl','--enable-precise-memory-info'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
  const page=context.pages()[0],errors=[],warnings=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());if(m.type()==='warning'){warnings.push(m.text());if(/GL_INVALID|WebGL.*error/i.test(m.text()))errors.push(m.text());}});
  await page.addInitScript(()=>{
   localStorage.setItem('tbs.graphicsQuality','high');
   let seed=72421,api;
   Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
   Object.defineProperty(window,'TBS',{get:()=>api,set(value){api=value;
    for(const name of ['createScene','buildWorld','buildPresentation','createRuntime']){
     let fn;Object.defineProperty(api,name,{get:()=>fn,set(original){fn=(...args)=>{
      let restore;
     if(name==='createScene'){const T=args[0].T,C=T.WebGLRenderer;T.WebGLRenderer=new Proxy(C,{construct(target,params,newTarget){const r=Reflect.construct(target,params,newTarget);return r;}});restore=()=>{T.WebGLRenderer=C;};}
     let result;try{result=original(...args);}finally{if(restore)restore();}
      if(name==='buildWorld')window.__world=result;
      if(name==='buildPresentation'){window.__ports=result;window.__state=args[0].state;}
      if(name==='createRuntime'){window.__game=args[0].game;return{...result,start(){window.__game.initialize();window.__visualStarted=true;}};}
      return result;
     };}});
    }
   }});
  });
  const browser=await context.browser().newBrowserCDPSession(),target=await context.newCDPSession(page),{targetInfo}=await target.send('Target.getTargetInfo');
  const bounds=await browser.send('Browser.getWindowForTarget',{targetId:targetInfo.targetId});await browser.send('Browser.setWindowBounds',{windowId:bounds.windowId,bounds:{windowState:'maximized'}});await page.bringToFront();
  const url=pathToFileURL(path.join(dir,'index-'+mode+'.html'));url.search='';
  await page.goto(url.href,{waitUntil:'load',timeout:180000});
  await page.waitForFunction(()=>window.__visualStarted,null,{timeout:180000});
  const cdp=await context.newCDPSession(page);
  async function capture(stage,steps){
   const data=await page.evaluate(steps=>{
    const w=window.__world,r=w.renderer,g=r.getContext();let passes=[];const checkpoints=[{at:"before-step",error:g.getError()}];
    const render=r.render;r.render=function(sc,cam){passes.push({scene:sc===w.scene?'world':'auxiliary',camera:cam.type,target:!!r.getRenderTarget()});return render.call(this,sc,cam);};
    try{for(let i=0;i<steps;i++)window.__game.step(1/60);}finally{r.render=render;}
    checkpoints.push({at:"after-step",error:g.getError()}); const pixels=new Uint8Array(g.drawingBufferWidth*g.drawingBufferHeight*4);g.readPixels(0,0,g.drawingBufferWidth,g.drawingBufferHeight,g.RGBA,g.UNSIGNED_BYTE,pixels);
    checkpoints.push({at:'after-readPixels',error:g.getError()}); let binary='';for(let i=0;i<pixels.length;i+=32768)binary+=String.fromCharCode(...pixels.subarray(i,i+32768));
    const inventory={objects:0,meshes:0,instanced:0,instances:0,castShadow:0,receiveShadow:0,lights:0};
    w.scene.traverse(o=>{inventory.objects++;if(o.isMesh)inventory.meshes++;if(o.isInstancedMesh){inventory.instanced++;inventory.instances+=o.count;}if(o.castShadow)inventory.castShadow++;if(o.receiveShadow)inventory.receiveShadow++;if(o.isLight)inventory.lights++;});
    const programs=r.info.programs.map(p=>({name:p.name,linked:g.getProgramParameter(p.program,g.LINK_STATUS),log:g.getProgramInfoLog(p.program)}));
    checkpoints.push({at:'after-validation',error:g.getError()}); const png=r.domElement.toDataURL('image/png');checkpoints.push({at:'after-toDataURL',error:g.getError()}); return{checkpoints,pixels:btoa(binary),png,inventory,passes,programs,error:checkpoints.find(c=>c.error)?.error||g.getError(),debug:r.debug.checkShaderErrors,quality:window.__ports.graphics.quality,depthSupported:window.__ports.graphics.depthSupported,shadows:r.shadowMap.enabled,player:{x:window.__state.player.x,z:window.__state.player.z,speed:window.__state.player.speed},mode:window.__state.mode,daylight:window.__ports.timeline.daylight(),prepared:r.__asyncStats||null,window:{innerWidth,innerHeight,dpr:devicePixelRatio},renderer:g.getParameter(g.getExtension("WEBGL_debug_renderer_info").UNMASKED_RENDERER_WEBGL)};
   },steps);
   const pixels=Buffer.from(data.pixels,'base64');fs.writeFileSync(path.join(dir,name+'-'+stage+'.rgba'),pixels);
   fs.writeFileSync(path.join(dir,name+'-'+stage+'.png'),Buffer.from(data.png.split(',')[1],'base64'));
   delete data.pixels;delete data.png;data.pixelSHA256=crypto.createHash('sha256').update(pixels).digest('hex');
   return data;
  }
  const first=await capture('first',1);
  await page.locator('#startBtn').scrollIntoViewIfNeeded();const rect=await page.locator('#startBtn').boundingBox();
  await cdp.send('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,x:rect.x+rect.width/2,y:rect.y+rect.height/2});
  await cdp.send('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,x:rect.x+rect.width/2,y:rect.y+rect.height/2});
  await cdp.send('Input.dispatchKeyEvent',{type:'keyDown',key:'w',code:'KeyW',windowsVirtualKeyCode:87});
  const moving=await capture('moving',60);
  await cdp.send('Input.dispatchKeyEvent',{type:'keyUp',key:'w',code:'KeyW',windowsVirtualKeyCode:87});
  for(let i=0;i<2;i++){await cdp.send('Input.dispatchKeyEvent',{type:'keyDown',key:'n',code:'KeyN',windowsVirtualKeyCode:78});await cdp.send('Input.dispatchKeyEvent',{type:'keyUp',key:'n',code:'KeyN',windowsVirtualKeyCode:78});}
  const night=await capture('night',300);
  fs.writeFileSync(path.join(dir,name+'.json'),JSON.stringify({note:'Controlled visual/smoke check, excluded from performance statistics; fixed RNG and 1/60 steps.',errors,warnings,first,moving,night},null,2));
  if(errors.length||first.error||moving.error||night.error||moving.player.speed<=0||[...first.programs,...moving.programs,...night.programs].some(p=>!p.linked))throw Error(name+' failed');
  console.log(name+' visual/smoke OK');
 }finally{await context.close();}
}
(async()=>{
 for(const [name,mode] of [['fixed-A1','A'],['fixed-B','B'],['fixed-A2','A']])await run(name,mode);
 const results={};
 for(const stage of ['first','moving','night']){
  const a=fs.readFileSync(path.join(dir,'fixed-A1-'+stage+'.rgba'));
  for(const label of ['B','A2']){
   const b=fs.readFileSync(path.join(dir,'fixed-'+label+'-'+stage+'.rgba'));let channels=0,pixels=0,total=0,max=0;
   for(let i=0;i<a.length;i+=4){let changed=false;for(let k=0;k<4;k++){const delta=Math.abs(a[i+k]-b[i+k]);if(delta){channels++;changed=true;}total+=delta;max=Math.max(max,delta);}if(changed)pixels++;}
   results[stage+'-A1-vs-'+label]={changedPixels:pixels,changedChannels:channels,maxDelta:max,meanAbsoluteDelta:total/a.length,totalPixels:a.length/4};
  }
 }
 fs.writeFileSync(path.join(dir,'fixed-comparison.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results));
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
