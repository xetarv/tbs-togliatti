const fs=require('node:fs'),path=require('node:path');const dir=__dirname,comparison=JSON.parse(fs.readFileSync(path.join(dir,'fixed-comparison.json')));
if(Object.values(comparison).some(x=>x.changedPixels!==0))throw Error('Visual gate failed; timing is prohibited');
let probe=fs.readFileSync(path.join(dir,'probe.js'),'utf8');const anchor='    const gl=d.world.renderer.getContext();';if(probe.split(anchor).length!==2)throw Error('Probe anchor');
probe=probe.replace(anchor,anchor+`
    const material=d.world.scene.userData.waterMaterial,shader=material.userData.shader,program=d.world.renderer.properties.get(material).currentProgram?.program;
    d.firstWater={published:!!shader,wave:shader?.uniforms.waveTime?.value,strength:shader?.uniforms.reflectionStrength?.value};
    if(program){d.firstWater.nativeWave=gl.getUniform(program,gl.getUniformLocation(program,'waveTime'));d.firstWater.nativeStrength=gl.getUniform(program,gl.getUniformLocation(program,'reflectionStrength'));}
`);fs.writeFileSync(path.join(dir,'probe.js'),probe);
let runner=fs.readFileSync(path.join(dir,'run-ab.cjs'),'utf8');runner=runner.replace('firstRender:d.firstRender,firstGPU:','firstRender:d.firstRender,firstWater:d.firstWater,firstGPU:');fs.writeFileSync(path.join(dir,'run-ab.cjs'),runner);
fs.copyFileSync(path.join(dir,'../r149-async-principle-20261019/analyze.cjs'),path.join(dir,'analyze.cjs'));
console.log('Visual gate passed in all six comparisons; timing observers ready.');
