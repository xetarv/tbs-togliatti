// In-memory startup timers only. No source, shaders, render options or scheduler replacement.
(() => {
  const d = window.__bootDiag = { probeVersion:2, rows: [], surfaces: [], gl: {}, longtasks: [], firstRender: null,
    firstGPU: null, gpuUnavailable: false, controlReady: null, anchor: performance.now() };
  performance.mark('tbs.diag.anchor');
  try { localStorage.setItem('tbs.graphicsQuality','high'); } catch { /* file storage may be unavailable */ }
  const stack = [];
  const span = (n, fn) => {
    const r = { n, s: performance.now(), ms: 0, self: 0, child: 0 };
    d.rows.push(r); stack.push(r);
    try { return fn(); }
    finally {
      r.ms = performance.now()-r.s; r.self = r.ms-r.child; stack.pop();
      if (stack.length) stack.at(-1).child += r.ms;
      delete r.child;
    }
  };
  const method = (object,key,n,after) => {
    const fn = object[key];
    object[key] = function(...args) {
      const start = performance.now();
      const value = span(n, () => Reflect.apply(fn,this,args));
      if (after) after(value,args,start);
      return value;
    };
  };
  function port(object, names, prefix, after) {
    const descriptors = Object.getOwnPropertyDescriptors(object);
    for (const key of names) if(typeof object[key] === 'function') {
      const fn = object[key];
      descriptors[key] = { ...descriptors[key], value: function(...args) {
        const start = performance.now();
        const value = span(prefix+'.'+key, () => Reflect.apply(fn,object,args));
        if(after) after(key,args,start);
        return value;
      } };
    }
    const copy = Object.create(Object.getPrototypeOf(object), descriptors);
    return Object.isFrozen(object) ? Object.freeze(copy) : copy;
  }
  let visual = false, surface = 0, texture = 0, nextCanvas = true;
  const names = ['asphalt','stone','paving','brick'];
  const create = document.createElement;
  document.createElement = function(tag,...args) {
    if(visual && surface<4 && nextCanvas && String(tag).toLowerCase()==='canvas') {
      d.surfaces[surface] = { name:names[surface], s:performance.now() }; nextCanvas=false;
    }
    return Reflect.apply(create,this,[tag,...args]);
  };
  for (const key of ['getImageData','putImageData']) {
    const fn = CanvasRenderingContext2D.prototype[key];
    CanvasRenderingContext2D.prototype[key] = function(...args) {
      const r = visual && surface<4 ? d.surfaces[surface] : null;
      const start = performance.now();
      if(r && key==='getImageData') r.normalStart=start;
      const result = Reflect.apply(fn,this,args);
      if(r) {
        r[key] = performance.now()-start;
        if(key==='getImageData') r.readbackEnd=performance.now();
        else r.normalEnd=performance.now();
      }
      return result;
    };
  }
  for(const proto of [WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype]) {
    for(const key of ['compileShader','linkProgram','getProgramParameter','getShaderParameter','getProgramInfoLog','getShaderInfoLog','texImage2D','bufferData']) {
      const fn=proto[key]; if(!fn || fn.__bootTimed) continue;
      const wrapped=function(...args) {
        const start=performance.now();
        try { return Reflect.apply(fn,this,args); }
        finally {
          const ms=performance.now()-start;
          const phase = d.firstRender ? 'afterFirstRender' : stack.some(r=>r.n==='graphics.render') ? 'firstRender' : 'construction';
          const group = phase+':'+key;
          const r=d.gl[group] ||= {phase,key,count:0,ms:0,max:0,slow:[]};
          r.count++; r.ms+=ms; r.max=Math.max(r.max,ms);
          if(ms>=5) r.slow.push({s:start,ms,param:key.includes('Parameter')?args[1]:undefined});
        }
      };
      wrapped.__bootTimed=true; proto[key]=wrapped;
    }
  }
  try { new PerformanceObserver(list => { for(const r of list.getEntries()) d.longtasks.push({s:r.startTime,ms:r.duration}); }).observe({type:'longtask',buffered:true}); } catch { /* unsupported diagnostic */ }
  function firstFrame(_key,_args,start) {
    if(d.firstRender) return;
    d.firstRender={s:start,e:performance.now()};
    const gl=d.world.renderer.getContext();
    const material=d.world.scene.userData.waterMaterial,shader=material.userData.shader,program=d.world.renderer.properties.get(material).currentProgram?.program;
    d.firstWater={published:!!shader,wave:shader?.uniforms.waveTime?.value,strength:shader?.uniforms.reflectionStrength?.value};
    if(program){d.firstWater.nativeWave=gl.getUniform(program,gl.getUniformLocation(program,'waveTime'));d.firstWater.nativeStrength=gl.getUniform(program,gl.getUniformLocation(program,'reflectionStrength'));}

    if(!gl.fenceSync) {d.gpuUnavailable=true;return;}
    const sync=gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE,0); gl.flush();
    function poll() {
      const result=gl.clientWaitSync(sync,0,0);
      if(result===gl.TIMEOUT_EXPIRED) {requestAnimationFrame(poll);return;}
      if(result===gl.WAIT_FAILED) d.gpuUnavailable=true;
      else d.firstGPU=performance.now();
      gl.deleteSync(sync);
    }
    requestAnimationFrame(poll);
  }
  const factories = ['createDom','createScene','createGeometryHelpers','createVegetationCulling',
    'createWorldResources','createVisualAssets','createTerrain','createRoads','createParks',
    'createBuildings','createShowcase','populateWorld','createDroneModels','buildWorld',
    'createCarModels','createFastback','createPlayerCar','createTrafficView','createDisplay',
    'createGraphics','createLighting','createInput','buildPresentation','buildGame','createRuntime'];
  let registry;
  Object.defineProperty(window,'TBS',{configurable:true,get:()=>registry,set(value) {
    registry=value;
    for(const name of factories) {
      let wrapped;
      Object.defineProperty(value,name,{configurable:true,get:()=>wrapped,set(original) {
        wrapped=function(...args) {
          let restore;
          if(name==='createVisualAssets') {
            visual=true; surface=0;texture=0;nextCanvas=true;
            const T=args[0], originalTexture=T.CanvasTexture;
            T.CanvasTexture=new Proxy(originalTexture,{construct(target,params,newTarget) {
              const result=Reflect.construct(target,params,newTarget);
              if(surface<4 && ++texture%3===0) {
                d.surfaces[surface].e=performance.now();surface++;nextCanvas=true;
              }
              return result;
            }});
            restore=()=>{T.CanvasTexture=originalTexture;visual=false;};
          }
          if(name==='createScene') {
            const T=args[0].T, C=T.WebGLRenderer;
            T.WebGLRenderer=new Proxy(C,{construct(target,params,newTarget) {
              const renderer=span('WebGLRenderer.constructor',()=>Reflect.construct(target,params,newTarget));
              method(renderer,'render','renderer.render');
              return renderer;
            }});
            restore=()=>{T.WebGLRenderer=C;};
          }
          let result;
          if(name==='createRuntime') {
            args[0]={...args[0],game:port(args[0].game,['step','initialize'],'game',()=>{
              if(d.keyRequested!=null && d.controlReady==null && d.state.player.speed>0) d.controlReady=performance.now();
            })};
          }
          try {result=span(name,()=>Reflect.apply(original,this,args));}
          finally {if(restore)restore();}
          if(name==='buildWorld')d.world=result;
          if(name==='buildPresentation') {d.state=args[0].state; d.ports=result;}
          if(name==='createCarModels') result=port(result,['createHeroCar','createTrafficCar'],'model');
          if(name==='createGraphics') result=port(result,['render'],'graphics',firstFrame);
          if(name==='createRuntime') {
            result=port(result,['start'],'runtime');
          }
          return result;
        };
      }});
    }
  }});
  document.addEventListener('click',event=>{
    if(event.target.closest && event.target.closest('#startBtn')) d.startEvent={s:performance.now(),trusted:event.isTrusted};
  },true);
})();
