const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=__dirname,root=path.resolve(dir,'../..'),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n))),a=read('A.json'),b=read('B.json'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const preserved={};for(const[p,h]of Object.entries(read('preserved-before.json'))){preserved[p]=sha(fs.readFileSync(path.join(root,p)))===h;if(!preserved[p])throw Error('Changed preserved file '+p);}
const summary={decision:'Stopped without correction: two independently owned cleanup paths fail. Production remains prohibited.',head:'5cbd6f741415bf10d44b2a6088b9bc26e1916d50',candidateChanged:false,scenarios:{A:{preparation:a.before.settled,programsAfterDisposal:a.settled.rendererPrograms.length,privateDepth:a.settled.rendererPrograms.filter(p=>p.name==='MeshDepthMaterial').length,privatePMREM:a.settled.rendererPrograms.filter(p=>p.name==='ShaderMaterial').length,publicOwnersReleased:a.after.publicOwnersReleased,pending:a.settled.pending,pollTimers:a.settled.pollTimers,pagehideHandlers:a.settled.pagehideActive,duplicateProgramDeletes:a.settled.byKind.program.duplicateDeletes,duplicateShaderDeletes:a.settled.byKind.shader.duplicateDeletes,GL:a.settled.glError},B:{actualNativeNotReady:b.settled.events.some(e=>e.name==='native-program-not-ready'),abortReason:b.settled.reason,pending:b.settled.pending,pollTimers:b.settled.pollTimers,pagehideHandlers:b.settled.pagehideActive,programsStillRegistered:b.settled.rendererPrograms.length,unrequestedProgramDeletes:b.settled.byKind.program.unrequested,unrequestedShaderDeletes:b.settled.byKind.shader.unrequested,graphicsDisposeCalls:b.settled.graphicsDisposeCalls,postDisposeGLCalls:b.settled.postDispose.length,GL:b.settled.glError},C:'Not run: stop condition reached',D:'Not run: stop condition reached',E:'Not run: stop condition reached'},repeatedCycles:'Not run: basic teardown tests failed; no claim about growth across cycles.',functionalRecheck:'Not repeated: no correction and basic lifecycle gate failed.',preserved};
fs.writeFileSync(path.join(dir,'summary.json'),JSON.stringify(summary,null,2),{flag:'wx'});
let report=`# Lifecycle B++: остановка на двух подтверждённых путях неполной очистки

HEAD/main: 5cbd6f741415bf10d44b2a6088b9bc26e1916d50. Production не изменялся. Исправление в этом задании **не выполнялось**.

**Вердикт:** B++ нельзя рекомендовать к следующей production-приёмке до отдельного решения двух проблем владения/очистки. По прямому условию задания после их подтверждения проверки остановлены. C/D/E, повторные циклы и повторный визуальный gate не выполнялись. Они не объявляются успешными по старым данным.

## Точные материалы

- Проверяемый сохранённый B++: ../r149-async-rng-20261020/three-r149-async-plusplus.min.js, SHA-256 ${sha(fs.readFileSync(path.join(dir,'three-r149-async-plusplus.min.js')))}.
- Исправленный water/graphics и app: одноимённые экспериментальные файлы из r149-async-rng-20261020, побитовые копии здесь.
- Предыдущие RNG/изображения: ../r149-async-rng-20261020/correctness.json, report.md. Предыдущий B+: ../r149-async-late-programs-20261020/.
- Новая оснастка: observe.js/run.cjs, реальные данные A.json и B.json. Архивы не восстанавливались. Движок/программы/шейдеры и состав batch не патчились.

## 1. Короткая карта владения

| Ресурс | Создатель и владелец | После успешной подготовки | Освобождение / состояние при отмене |
| --- | --- | --- | --- |
| Native WebGLShader | Конструктор WebGLProgram создаёт vertex/fragment shaders и attach/link | Отложенный firstUse запрашивает deleteShader после проверки; attach сохраняется до освобождения program | destroy запрашивает deleteShader для ещё не прошедших firstUse; не вызывается, если владелец program не освобождён |
| Native WebGLProgram | WebGLPrograms.acquireProgram → WebGLProgram; после конструктора сразу регистрируется в renderer cache | Там же; material properties.programs удерживают ссылки через usedTimes | Material.dispose → releaseProgram → destroy при usedTimes=0. Prep не имеет права удалять такие native handles вручную |
| Частично подготовленные/ещё неготовые программы | С момента успешного acquireProgram уже renderer-owned; pending — только временный список ссылок | После ожидания остаются в том же кеше | Abort завершает promise, но сам не освобождает renderer-owned programs. Необходим корректный teardown владельцев |
| 16 подготовленных, не использованных в сценарии | Кеши материалов/renderer, включая 3 private depth-варианта | Сохраняются для потенциального использования; само по себе это не утечка | Должны освобождаться при завершении владельцев, а не после каждого batch |
| Depth/distance material для подготовки B++ | Уже существующие private материалы WebGLShadowMap; B++ не создаёт ранние clones | Их program maps удерживают 10 depth-вариантов | Обычный пользовательский scene material.dispose эти private maps не освобождает; после renderer.dispose остаются 10 depth programs |
| Другие временные объекты/геометрия | Списки passes, initial/pending, stats — JS; B++ не добавляет временной Mesh/Geometry или RNG/UUID clones | Метаданные __asyncStats и функция __startupPasses остаются на renderer | Списки promise перестают ожидать; освобождение JS по GC не равно освобождению native GL handles |
| Wait callbacks/promise | compileAsyncPasses; polling setTimeout(resolve,10) | Promise fulfilled, активных wait timers нет | Проверка AbortSignal на цикле, rejection после текущего timeout; app finally удаляет pagehide cancel handler. B подтвердил завершение, а не простой таймаут оснастки |
| Reflection/scene/post targets | createGraphics владеет sceneTarget, cubeTarget, quarterTarget, waterTarget, post/proxy resources | Программы и targets используются штатным renderer | graphics.dispose — владелец; reflection clones заимствуют world geometry/materials и только отсоединяются. На failure/cancel app этот disposer не вызывает |
| Чужие world assets / environment | Сцена/фабрики мира; shared материалы/геометрия не принадлежат reflection clones | Текущие владельцы | Не объявлялись ресурсами preparation и не удалялись вручную native GL calls |

Отдельной фазы «готово, теперь передать program renderer» нет: передача происходит внутри acquireProgram до завершения ожидания. Конструктор, который выбросит исключение до регистрации, — отдельный ещё не проверенный случай C; его безопасность не предполагается.

Реальные исходники: renderer Material.dispose handler вызывает releaseMaterialProgramReferences → programCache.releaseProgram. В WebGLPrograms.dispose r149 находится только _customShaders.dispose(), без release зарегистрированных programs. Renderer.dispose вызывает properties.dispose() **до** cubeuvmaps.dispose(), вследствие чего material dispose внутренних PMREM-материалов уже не находит прежние property program maps. Private ShadowMap depth materials вообще не входят в список пользовательских материалов сцены. Эти адресные пути рассмотрены по сохранённым официальным r149 исходникам и точным minified фрагментам; полноценный аудит движка не выполнялся.

## 2. A — успех и завершение

Настоящий оконный Edge ${a.browser}, file://, High, ${a.before.GPU}. Все 76 программ подготовлены, затем реальные main/reflection/post draw использовали их; дождались двух main frames. Checks=true, GL error=0, promise fulfilled.

Завершение в изолированном окружении: runtime.stop → существующий graphics.dispose → dispose ${a.after.publicOwnersReleased.materials} уникальных public scene materials и ${a.after.publicOwnersReleased.geometries} geometries → renderer.dispose. Reflection clones предварительно отсоединены своим владельцем; материалы дедуплицированы. Прямых gl.delete* из teardown оснастки не было. Владение внешними текстурами/невыданным environment render target не выдумывалось; полная очистка всего исторического мира не заявлена.

После этого:

- Pending promise=0, polling timers=0, pagehide cancel handlers=0.
- Повторных deleteProgram/deleteShader=0.
- **12 programs всё ещё зарегистрированы и native-valid:** 10 MeshDepthMaterial + 2 ShaderMaterial PMREM, usedTimes=1.
- Всего createProgram=89, deleteProgram=77. Native isProgram=true у 13: 12 без delete request и ещё одна программа, для которой delete уже был запрошен, но native handle пока valid. Это различие учтено, 13 не выдаётся за 13 неосвобождённых владельцев; точный момент драйверного освобождения не измерялся.
- DeleteShader запрошен для всех 178, но native shaders могут оставаться attached к неосвобождённым/текущей программе. Delete request не равен мгновенному освобождению драйверной памяти.

**A не пройден по финальному освобождению private renderer-owned programs.** Подготовка/использование и завершение ожиданий прошли.

## 3. B — настоящая отмена во время native not-ready

Оснастка увидела **реальный false COMPLETION_STATUS_KHR**. Затем синтетическое pagehide-событие вызвало существующий app cancel handler, который выполнил настоящий AbortController.abort(). GPU readiness не подменялась, измерение просто не прекращалось. Native check → pagehide → rejection → renderer.dispose подтверждены events в B.json.

- Promise rejected с тем же объектом options.signal.reason: Error("Page left during preparation").
- Pending=0, polling timers=0, cancel-handler=0; ожидающая операция завершилась.
- В течение контрольного интервала не было отслеженных program-query/use/draw вызовов после dispose. Checks=true, GL error=0; новый игровой runtime не стартовал.
- **Graphics.dispose calls=0.** App catch вызывает только runtime.stop и renderer.dispose.
- В кеше осталось **77 программ**, из них 76 нового batch. 77 programs без delete request; **152 shaders** нового batch без delete request.
- В живом контексте также остаются native textures/framebuffers/renderbuffers; агрегаты: 7/9/8 без delete request. Эти суммы включают world/environment allocations, поэтому все они не приписываются preparation. Но setRenderTarget для проходов действительно инициализирует graphics targets, а их владелец graphics.dispose при отмене не вызывается.

**B частично пройден по abort/promise, не пройден по очистке.** Это второй путь: пропуск graphics/material owners в app error/cancel teardown, в дополнение к private renderer cache cleanup после освобождения public owners в A.

## 4. Почему остановка без одной корректировки

Для первой проблемы требуется освобождение private renderer-owned programs через их владельца с корректными refcounts/порядком. Для второй — передача teardown владельцам graphics и остальных созданных ресурсов при abort/error. Простое ручное gl.deleteProgram из подготовки нарушило бы владение. Одно добавление graphics.dispose также не решило бы 12 private programs в A. Объединять независимые изменения и перестраивать общий lifecycle без отдельного решения запрещено заданием.

Поэтому B++ не менялся. Отмена/ошибка/cleanup не «исправлялись» принудительным закрытием браузера: снимки делались в остающемся живым контексте. После сохранения доказательств тестовые браузеры штатно закрыты. Закрытие страницы/контекста может освободить GL через браузер, но это не доказательство корректности in-page teardown.

## 5. Остальные обязательные проверки

| Сценарий | Статус |
| --- | --- |
| A normal | Подготовка/render успешны; private cleanup не пройден |
| B cancel | Настоящий abort завершён; cleanup не пройден |
| C controlled error | Не запускался после условия остановки |
| D no KHR | Не запускался; старый fallback не засчитывался |
| E context loss | Не запускался; поддержка WEBGL_lose_context и восстановление здесь не проверены |
| Повторное создание/уничтожение | Не выполнялось: базовое освобождение уже не прошло |
| Новый first/moving/night/RNG gate | Не повторялся: нет разрешённого исправления и lifecycle gate не пройден |

Накопление ресурсов по повторным циклам не измерено. Доказано сохранение конкретных renderer cache/native handles после teardown в одном живом контексте. Это не вывод из JS heap/renderer.info.memory или системной GPU-памяти. Диагностические strong references позволяют проверять explicit delete/validity и могут препятствовать автоматическому GC; поэтому необратимая утечка драйвера после закрытия страницы не утверждается. Сами renderer cache entries и usedTimes также остаются, независимо от одного счётчика памяти.

## 6. Сохранность

Все ${Object.keys(preserved).length} выбранных исходных/исторических SHA-256 совпали: production, original bundled Three r149, четыре shaderChecks-файла, B+, B++, water/RNG fix и прежние результаты. Новые материалы только здесь. Измеряемый preparation path не менялся — performance A/B, build/check не запускались.

HEAD/main прежние; индекс пуст; status содержит только прежние M dist/adapters/rendering/scene.js, src/adapters/rendering/scene.ts, types/rendering-contracts.d.ts и ?? tests/shader-checks.test.cjs. Commit/push отсутствуют. git diff --check проверен отдельно.
`;
fs.writeFileSync(path.join(dir,'report.md'),report,{flag:'wx',encoding:'utf8'});
fs.writeFileSync(path.join(dir,'provenance.json'),JSON.stringify({head:summary.head,candidateChanged:false,executed:['A','B'],notExecuted:['C','D','E','repeated cycles','functional recheck'],hashes:Object.fromEntries(['three-r149-async-plusplus.min.js','graphics-experimental.js','app-experimental.js','prepare.cjs','observe.js','run.cjs'].map(n=>[n,sha(fs.readFileSync(path.join(dir,n)))])),instrumentation:'Native-call forwarding, explicit-handle counters, real native readiness observation and AbortController. Only observer functions/errors/pagehide dispatch; no production modification.'},null,2),{flag:'wx'});
console.log(JSON.stringify({decision:summary.decision,preserved:Object.keys(preserved).length,A:summary.scenarios.A,B:summary.scenarios.B}));
