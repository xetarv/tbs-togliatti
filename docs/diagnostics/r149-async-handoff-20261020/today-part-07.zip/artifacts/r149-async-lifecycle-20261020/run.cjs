const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,save=(name,j)=>fs.writeFileSync(path.join(dir,name),JSON.stringify(j,null,2),{flag:'wx'});
async function run(scenario){
 console.log('START lifecycle '+scenario);const context=await chromium.launchPersistentContext(path.join(dir,'profiles',scenario),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
  const page=context.pages()[0],errors=[],messages=[];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(m.type()==='error'||m.type()==='warning')messages.push({type:m.type(),text:m.text()});});
  const observer=fs.readFileSync(path.join(dir,'observe.js'),'utf8');await page.addInitScript({content:`(${observer})(${JSON.stringify(scenario)});`});
  await page.goto(pathToFileURL(path.join(dir,'index.html')).href,{waitUntil:'load',timeout:180000});
  await page.waitForFunction(()=>window.__lc?.settled==='rejected'?window.__lc.disposeCalls>0:window.__lc?.mainFrames>=2,null,{timeout:150000});
  await page.waitForTimeout(50);
  const before=await page.evaluate(()=>window.__lc.snapshot());let after;
  if(['A','D'].includes(scenario)){
   after=await page.evaluate(()=>{
    const d=window.__lc;d.runtime.stop();d.ports.graphics.dispose();
    // The isolated environment ends here: release unique public scene owners first.
    // Reflection clones were detached by graphics.dispose and shared materials deduped.
    const materials=new Set(),geometries=new Set();d.world.scene.traverse(o=>{if(o.material)for(const m of Array.isArray(o.material)?o.material:[o.material])materials.add(m);if(o.geometry)geometries.add(o.geometry);});
    for(const m of materials)m.dispose();for(const g of geometries)g.dispose();
    d.publicOwnersReleased={materials:materials.size,geometries:geometries.size};d.renderer.dispose();
    return{...d.snapshot(),publicOwnersReleased:d.publicOwnersReleased,scope:'Existing graphics disposer then deduped public scene material/geometry owners then renderer.dispose. No manual native GL deletion or assumption of owning external textures.'};
   });
  }else after=before;
  await page.waitForTimeout(100);const settled=await page.evaluate(()=>window.__lc.snapshot());
  const outcome={scenario,errors,messages,browser:context.browser().version(),before,after,settled};save(scenario+'.json',outcome);
  console.log(JSON.stringify({scenario,settled:settled.settled,reason:settled.reason,pending:settled.pending,pollTimers:settled.pollTimers,pagehide:settled.pagehideActive,rendererPrograms:settled.rendererPrograms.length,resources:settled.byKind,checks:settled.checks,glError:settled.glError,graphicsDispose:settled.graphicsDisposeCalls,postDispose:settled.postDispose.length}));
 }catch(e){let snapshot;try{snapshot=await context.pages()[0].evaluate(()=>window.__lc?.snapshot());}catch{}save(scenario+'-harness-failure.json',{error:e.stack,snapshot});throw e;}
 finally{await context.close();}
}
(async()=>{for(const scenario of process.argv.slice(2).length?process.argv.slice(2):['A','B','C','D','E'])await run(scenario);})().catch(e=>{console.error(e.stack);process.exitCode=1;});
