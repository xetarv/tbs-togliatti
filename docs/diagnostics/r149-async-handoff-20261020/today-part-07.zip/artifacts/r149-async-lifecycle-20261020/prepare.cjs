const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{pathToFileURL}=require('node:url');
const dir=__dirname,root=path.resolve(dir,'../..'),prior=path.join(root,'artifacts/r149-async-rng-20261020'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const preserved=JSON.parse(fs.readFileSync(path.join(prior,'preserved-before.json')));for(const n of ['three-r149-async-plusplus.min.js','engine-patch.json','report.md','correctness.json','summary-2.json','provenance.json'])preserved[path.relative(root,path.join(prior,n))]=sha(fs.readFileSync(path.join(prior,n)));
fs.writeFileSync(path.join(dir,'preserved-before.json'),JSON.stringify(preserved,null,2),{flag:'wx'});
for(const n of ['three-r149-async-plusplus.min.js','graphics-experimental.js','app-experimental.js'])fs.copyFileSync(path.join(prior,n),path.join(dir,n),fs.constants.COPYFILE_EXCL);
let html=fs.readFileSync(path.join(prior,'index-Q.html'),'utf8');for(const n of ['three-r149-async-plusplus.min.js','graphics-experimental.js','app-experimental.js'])html=html.replace(pathToFileURL(path.join(prior,n)).href,pathToFileURL(path.join(dir,n)).href);
fs.writeFileSync(path.join(dir,'index.html'),html,{flag:'wx'});
console.log('Lifecycle copy prepared; original candidate unchanged.');
