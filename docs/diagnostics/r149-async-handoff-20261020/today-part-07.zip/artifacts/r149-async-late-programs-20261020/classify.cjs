const fs=require('node:fs'),path=require('node:path');const dir=__dirname,root=path.resolve(dir,'../..');
const data=[];
for(let pair=1;pair<=3;pair++)for(const kind of ['fresh','warm']){
 const j=JSON.parse(fs.readFileSync(path.join(root,`artifacts/r149-async-abc-timing-20261020/abc-${pair}-B-${kind}.json`))),p=j.programObservation;
 const late=p.linked.filter(q=>q.s>p.prepared.reflected&&q.s<j.firstRender.e),ids=new Set(late.map(q=>q.id));
 const programs=p.programs.filter(q=>ids.has(q.nativeID)).map(q=>{
  let group,pass,reason,source;
  if(q.name==='MeshDepthMaterial'){group='shadow-depth';pass='Directional shadow depth before main';reason='Stock renderer.compile only traverses object.material; private shadow depth material selected inside shadow render';source='official/WebGLShadowMap.js getDepthMaterial/renderObject';}
  else if(q.cacheKey.includes('signal-exact-r149')){group='signal-housing';pass='Main scene signal housing';reason='Real onBeforeRender temporarily installs cache key and shader hook, restored onAfterRender; stock compile deliberately does not invoke render callbacks';source='dist/adapters/simulation/traffic.js:97-144';}
  else if(q.name==='ShaderMaterial'&&q.cacheKey.includes('CUBEUV_MAX_MIP')){group='PMREM-blur';pass='Dynamic reflection cubemap -> PMREM blur';reason='Private PMREM blur shader is sized and allocated on first conversion of 128px cube';source='official/PMREMGenerator.js _allocateTargets/_applyPMREM';}
  else if(q.name==='ShaderMaterial'){group='PMREM-cube';pass='Dynamic reflection cubemap -> CubeUV conversion';reason='Private cubemap shader created by PMREM texture conversion, not scene traversal';source='official/PMREMGenerator.js _textureToCubeUV';}
  else {group=q.name==='MeshPhysicalMaterial'?'physical-reflection':'standard-reflection';pass='Main scene with dynamic CubeUV reflection';reason='First real updateReflections assigns 128px cube target envMaps; CubeUV height changes from initial environment 1024 to 512';source='src/adapters/rendering/graphics.ts:353-389; official/WebGLPrograms.js getParameters';}
  const calls=p.slow.filter(c=>c.id===q.nativeID),link=late.find(c=>c.id===q.nativeID);
  return{...q,group,pass,reason,source,linkMs:link.ms,firstUse:p.used.find(c=>c.id===q.nativeID)?.s,slowCalls:calls,slowLogMs:calls.filter(c=>c.name==='getProgramInfoLog').reduce((s,c)=>s+c.ms,0),slowOtherMs:calls.filter(c=>c.name!=='getProgramInfoLog').reduce((s,c)=>s+c.ms,0)};
 });
 if(programs.length!==17||programs.some(q=>!q.used))throw Error('Unexpected late set');
 const groups={};for(const q of programs){const g=groups[q.group]||={count:0,slowLogMs:0,slowOtherMs:0,linkMs:0};g.count++;g.slowLogMs+=q.slowLogMs;g.slowOtherMs+=q.slowOtherMs;g.linkMs+=q.linkMs;}
 data.push({pair,kind,programs,groups});
}
const visual={};for(const label of ['A1','B','C','A2']){const j=JSON.parse(fs.readFileSync(path.join(dir,`visual-1-${label}.json`)));const p=j.first.observation,ids=new Set(p.prepared.ids);visual[label]={prepared:p.prepared.submitted,preparedUsed:p.programs.filter(q=>ids.has(q.threeID)&&q.used).length,depth:p.programs.filter(q=>q.name==='MeshDepthMaterial'),rng:j.first.rng,water:j.first.waterState};}
fs.writeFileSync(path.join(dir,'late-classification.json'),JSON.stringify({note:'Prior six B runs; slow API events threshold 5ms. Log and other API times are nested inside actual render, not additive to render. No per-program sub-5ms reflection totals available. Pass mapping combines live cache keys/full GLSL from saved localization with stock source; per-draw object mapping not newly captured.',runs:data,visual},null,2),{flag:'wx'});
console.log(JSON.stringify(data.filter(d=>d.kind==='warm').map(d=>({pair:d.pair,groups:d.groups}))));
