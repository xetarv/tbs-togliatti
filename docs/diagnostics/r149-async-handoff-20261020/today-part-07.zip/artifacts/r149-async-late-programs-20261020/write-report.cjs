const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=__dirname,read=n=>JSON.parse(fs.readFileSync(path.join(dir,n))),s=read('summary-2.json'),classification=read('late-classification.json'),coverage=read('coverage-comparison.json');
const sec=x=>(x/1000).toFixed(3),g=(kind,mode,k)=>sec(s.groups[kind][mode][k].median);
let text=`# B+: подготовка реальных теневых вариантов до первого render

HEAD/main: 5cbd6f741415bf10d44b2a6088b9bc26e1916d50. Только диагностический кандидат; production не одобрена.

## Решение

**B+ перспективен для дальнейшей отдельной приёмки, но не для немедленной production-интеграции.** В двух корректных чередующихся парах полное повторное navigation→W быстрее на 1,119 и 0,792 с. Диапазоны B 4,913–5,430 с и B+ 4,121–4,311 с не перекрываются; наименьший парный выигрыш больше внутривариантного диапазона B 0,517 с и B+ 0,190 с. N=2, третья пара для различения этого эффекта от наблюдаемого разброса не потребовалась. Это не оценка вероятности или универсальный процент ускорения.

Новый профиль не замедлился в проверенных парах; отдельное дополнительное ускорение нового запуска не доказано (одна разница всего 4,6 мс). Исторические A/C — только ориентиры, новых A/C не запускали и не объединяли с этой серией. Устранение warm-регрессии относительно актуальных A/C пока не доказано.

## 1. Какие 17 программ были поздними

Все 17 действительно используются в первом полном High-render B. Полные native/Three IDs, cache keys, link/first-use и измеренные API — late-programs.json и late-classification.json. Состав одинаков в шести сохранённых B-run; native IDs в исходной серии 70–86.

| Native IDs | Материал / назначение | Проход | Количество | getProgramInfoLog ≥5 мс, warm, диапазон суммы |
| --- | --- | --- | ---: | ---: |
| 70–76 | MeshDepthMaterial: инстансинг/цвета, map/alphaTest, стороны | Shadow depth перед main | 7 | 0,076–0,201 с |
| 77 | MeshStandardMaterial, signal-exact-r149 | Корпус инстансированных светофоров, main | 1 | 0,023–0,028 с |
| 78 | ShaderMaterial: samplerCube → CubeUV | PMREM динамических отражений | 1 | 0,052–0,098 с |
| 79 | ShaderMaterial: CubeUV blur, MAX_MIP=7 | PMREM динамических отражений | 1 | 0–0,008 с |
| 80–83 | MeshStandardMaterial, instancing, CubeUV height=512 | Main с динамическим envMap | 4 | 0,031–0,032 с |
| 84–86 | MeshPhysicalMaterial, обычный/инстансинг, CubeUV height=512 | Main с динамическим envMap | 3 | 0,078–0,113 с |

Это вложенные интервалы внутри render; их нельзя ещё раз прибавлять к render. Slow-events имеют порог 5 мс: ноль означает отсутствие зарегистрированного события ≥5 мс, а не нулевую стоимость. Сумма linkProgram для всей поздней группы <0,4 мс в каждом сохранённом warm-run; отдельное событие другого API ≥5 мс было только в одном warm-run (5 мс). Полных самостоятельных сумм быстрых uniform reflection API по каждой программе в старой оснастке нет.

Причины пропуска установлены по исходникам r149, полным сохранённым GLSL и cache keys:

- Stock compile обходит object.material; реальный depth material выбирается внутри WebGLShadowMap при отрисовке теней.
- Корпус светофора меняет hook/cache key в onBeforeRender и восстанавливает в onAfterRender; compile эти callbacks не вызывает. Преждевременно вызывать произвольные render callbacks не стали.
- PMREM создаёт частные conversion/blur материалы во время переработки динамических cube textures. Первый updateReflections присваивает envMap, полученный от 128px cube; CubeUV height=512 отличается от первоначальной environment height=1024. Подготовка только текущего состояния не охватывает будущий вариант. Вызов штатного PMREM .get/fromCubemap здесь вызвал бы настоящий GPU-render и изменил кеш/targets.
- Не все группы одинаково дороги: shadow — существенная, но не единственная часть. Остальные 10 не объявлены подготовленными. Адресная принадлежность к типам проходов установлена; новый полный per-draw object audit не выполнялся.

Официальные исходники r149 сохранены в official/: [WebGLShadowMap](https://github.com/mrdoob/three.js/blob/r149/src/renderers/webgl/WebGLShadowMap.js), [WebGLPrograms](https://github.com/mrdoob/three.js/blob/r149/src/renderers/webgl/WebGLPrograms.js), [PMREMGenerator](https://github.com/mrdoob/three.js/blob/r149/src/extras/PMREMGenerator.js).

## 2. Единственный кандидат и границы

prepare.cjs применяет четыре адресные замены к неизменённому corrected B renderer; полный diff — engine-patch.json. В диагностическом WebGLShadowMap добавлен ограниченный обход текущих видимых shadow casters, который использует **тот же частный getDepthMaterial**. В main-linear compile, пока настроены штатные lights, эти материалы передаются в **тот же getProgram и program cache** с тем же empty scene, что и реальный shadow draw.

Не выполняются draw, shadow.updateMatrices, onBeforeRender/onAfterRender, обновление envMap/PMREM, переключение готовности отражений или шаг симуляции. Отдельного GLSL-корпуса/кеша нет. Вызов compileAsyncPasses, KHR polling (10 мс), shader checks, renderer cache/reflection, app и исправленный water hook сохранены. Диагностические app/graphics и базовый engine побитово скопированы из B. Исправлялась синтаксическая ошибка генератора до браузерного запуска; другой оптимизационный кандидат не создавался.

| Метрика программ | B | B+ |
| --- | ---: | ---: |
| Создано всего | 86 | 89 |
| Подготовлено batch | 66 | 76 |
| Подготовлено и использовано | 53 | 60 |
| Подготовлено, не использовано в сценарии | 13 | 16 |
| Реально использовано всего (native useProgram) | 73 | 73 |
| Новых после batch / до управления | 17 | 10 |
| Новых после первого полного render | 0 | 0 |

**Ограничение покрытия:** без предварительного изменения shadow matrices/frustum обход является консервативным. Он подготовил 10 текущих вариантов теней: все 7 реально требуемых и 3 дополнительных неиспользованных. Это варианты реальных кастеров сцены, не исторический список и не произвольные шейдеры, но точного минимального frustum coverage пока нет. Capture RNG показывает 12 дополнительных вызовов, что согласуется с тремя UUID-аллокациями r149 по четыре вызова. Depth selector создаёт частные clones; точная атрибуция каждой дополнительной аллокации не инструментировалась. RNG не подменялся в B+, проверенные состояния симуляции/камеры/мира и изображения совпали. Нельзя переносить это наблюдение на все будущие случайные события игры. До production требуется отдельная оценка этого побочного эффекта; в этом задании второй правкой его не устраняли.

Все baseline cache keys сохранились, наборы 73 использованных ключей B/B+ совпали. Семь перенесённых depth программ используются настоящими draw через тот же renderer, а не отдельными диагностическими программами.

## 3. Визуальная и функциональная проверка

Независимые профили B1/B+1/B+2/B2, фиксированный RNG/step: первый кадр, движение, ночь. B1/B+1/B+2 побитово совпали во всех трёх состояниях; PNG соответствует RGBA, readPixels до/после finish одинаков, default framebuffer/размеры/High совпали. CPU state, traffic, camera, world transforms и water wave/reflection strength совпали. Все LINK_STATUS успешны, logs пусты, GL errors=0, checks=true, движение подтверждено.

Строгий старый harness вернул отрицательный pixel gate из-за **B1/B2**: только движение 13 318 пикселей / max channel Δ3, первое/ночь идентичны. Это именно разрешённая заданием известная контрольная нестабильность; сохранён исходный strict result и отдельное diagnostic admission в summary-2.json. Существенного нового расхождения B+ нет. Такой допуск не является production-приёмкой изображения.

## 4. Сопоставимые времена до управления, секунды

Оконный Edge ${s.runs[0].browser}, file://, High, ANGLE/D3D11 RTX 3050 Laptop. CSS 1528×694, DPR 1,25, framebuffer 1910×867. Настоящий runtime/RAF и доверенные CDP wheel/mouse/KeyW. Пара 1 (файлы cycle2): B+ fresh→его warm, затем B fresh→его warm. Пара 2 (cycle3): B fresh→его warm, затем B+ fresh→его warm. Независимые профили между парами/вариантами; warm — перезапуск того же собственного профиля. Системный/драйверный кэш не очищался и не объявляется холодным.

| Профиль | Пара | B | B+ | B+−B |
| --- | ---: | ---: | ---: | ---: |
`;
for(const kind of ['fresh','warm']){
 for(const cycle of [2,3]){const b=s.runs.find(r=>r.cycle===cycle&&r.kind===kind&&r.mode==='B').stats,p=s.runs.find(r=>r.cycle===cycle&&r.kind===kind&&r.mode==='P').stats;text+=`| ${kind==='fresh'?'Новый':'Повторный'} | ${cycle-1} | ${sec(b.control)} | ${sec(p.control)} | ${sec(p.control-b.control)} |\n`;}
 text+=`| ${kind==='fresh'?'Новый':'Повторный'} | **Медиана** | **${g(kind,'B','control')}** | **${g(kind,'P','control')}** | **${sec(s.paired[kind].control.median)}** |\n`;
}
text+=`
| Метрика, медиана с | Новый B | Новый B+ | Повторный B | Повторный B+ |
| --- | ---: | ---: | ---: | ---: |
`;
for(const [label,key]of [['Первое видимое меню (screencast)','menuVisible'],['Регистрация Start','startRegistered'],['Обработан ранний wheel','earlyInput'],['Start → управление','startToControl'],['Конец первого полного render','firstRenderEnd'],['Длительность первого render','firstRenderDuration'],['Подтверждение GPU-ready','GPU'],['Подготовка: отправка','prepSubmit'],['Подготовка: ready wait','prepWait'],['Подготовка: reflection','prepReflection'],['Подготовка всего','prepTotal'],['Поздние getProgramInfoLog ≥5 мс','lateLogSlowMs']])text+=`| ${label} | `+['fresh','warm'].flatMap(k=>['B','P'].map(m=>g(k,m,key))).join(' | ')+' |\n';
text+=`
Warm Start→W по парам: B 0,871/0,748 с; B+ 0,110/0,683 с. Полное время важнее этого интервала: момент доставки Start зависит от занятого главного потока. В fresh Start→W B 0,062/3,255 с, B+ 3,136/0,060 с — один и тот же первый render может происходить до или после принятого Start. Из этих разных фаз доставки нельзя выводить воспроизводимое ускорение отдельного обработчика Start. DOM, регистрация, compositor image и обработка ввода не приравнивались. Ранняя отзывчивость всё ещё плохая: wheel обрабатывается через ~3,19 с warm B+ при видимом меню ~0,18 с.

## 5. Куда делось ожидание и первые 10 секунд

В warm B+ полная подготовка сократилась в обеих парах на ~0,958 с; сокращение первого render только 0,141 с в первой паре, во второй render длиннее на 0,003 с. Поэтому результат **не является простым переносом сэкономленного render времени в batch**. Наблюдается ускорение всего пути покрытия/подготовки. Почему расширение batch меняет его ready wait настолько сильно на уровне ANGLE/драйвера/планировщика, эта серия не устанавливает; вину конкретного шейдера, polling или 13 прежних лишних программ не объявляем доказанной.

Остаётся 10 поздних программ. Их warm getProgramInfoLog ≥5 мс: 0,330/0,367 с B+ против 0,413/0,391 с B. Нельзя считать проблему поздней подготовки полностью устранённой. Исторические A/C (4,222/4,037 с warm по медианам) здесь не новые парные измерения; B+ 4,216 с лишь приблизился к этим ориентирам.

За 10 секунд после подтверждённого W во всех восьми корректных runs новых links=0, зарегистрированных GL API ≥5 мс=0, WebGL/page errors=0. B+ fresh max game.step 32,6/33,8 мс, warm 65,3/35,6 мс; max interval между шагами B+ 66 мс. B fresh имел единичный step 220 мс, warm 39,7/31,7 мс. Сохранены long-frame-details.json: 65 мс соответствует реальному RAF/game.step, 61,1 мс внутри graphics.render; объяснения источника этой задержки по текущей трассе нет. Одновременные события других потоков не доказывают причинность. Многосекундного переноса shader wait после W в измеренном окне нет; отсутствия всех будущих задержек не утверждаем.

## 6. Надёжность измерений и сохранность

Прежние probe.js/menu-probe-final.js/program-observer.js не изменены. Fixed-step visual timings не использованы как performance. Метрики инструментированы: неизвестный общий overhead trace/screencast/GL wrappers/первого getUniform не вычитался; GPU-ready — верхняя оценка наблюдения fence через RAF, не аппаратный timestamp. Host PNG processing ~0,393–0,930 с/run влияет на ранний протокол ввода и не является изолированной поправкой. Bookkeeping span до W 0,4–1,1 мс — только часть overhead.

Первый технический cycle1 исключён **целиком**: адаптация старой оснастки заменила префикс только fresh-вызова, а ложные warm открывали другой профиль. Сырые данные не удалены, причина/исправление — measurement-correction.json. Основные восемь результатов — два полностью корректных цикла2/3. После исправления измерительного harness shader-кандидат не менялся. Ещё была исправлена ошибка индексов в offline-анализаторе без повторения измерений.

Совпали все ${Object.keys(s.preserved).length} выбранных SHA-256 исходных и исторических файлов. Original Three r149, production, четыре shaderChecks-файла, исходный B, water fix и старая диагностика сохранены. Новые файлы только в этом каталоге. HEAD/ветка прежние, индекс пуст; status: прежние M scene.ts, dist scene.js, rendering-contracts.d.ts и ?? tests/shader-checks.test.cjs. git diff --check успешен. Build/check, commit/push не выполнялись.

Дальнейшая работа требует отдельного поручения. Этот кандидат подтверждает полезность ограниченного переноса shadow-программ в текущем эксперименте; он не доказывает полноту High, точный минимальный набор вариантов, нейтральность UUID/RNG, универсальное устранение warm-регрессии или готовность к production.
`;
fs.writeFileSync(path.join(dir,'report.md'),text,{flag:'wx',encoding:'utf8'});
const files=['three-r149-async.min.js','three-r149-async-plus.min.js','graphics-experimental.js','app-experimental.js','probe.js','menu-probe-final.js','program-observer.js','run-bp.cjs','verify-visual.cjs','prepare.cjs'];
const hashes=Object.fromEntries(files.map(n=>[n,crypto.createHash('sha256').update(fs.readFileSync(path.join(dir,n))).digest('hex')]));
fs.writeFileSync(path.join(dir,'provenance.json'),JSON.stringify({head:'5cbd6f741415bf10d44b2a6088b9bc26e1916d50',hashes,official:Object.fromEntries(fs.readdirSync(path.join(dir,'official')).map(n=>[n,crypto.createHash('sha256').update(fs.readFileSync(path.join(dir,'official',n))).digest('hex')])),candidateCount:1,correctMeasuredRuns:8,excludedProtocolRuns:4,visualRuns:4,productionChanged:false},null,2),{flag:'wx'});
console.log('Report and provenance written; no browser/build/test executed.');
