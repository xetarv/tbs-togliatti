const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {pathToFileURL}=require('node:url');
const dir=__dirname,root=path.resolve(dir,'../..'),prior=path.join(root,'artifacts/r149-async-abc-timing-20261020');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const original=fs.readFileSync(path.join(prior,'three-r149-async.min.js'),'utf8');
let engine=original;const patches=[];
function replace(before,after){if(engine.split(before).length!==2)throw Error('Nonunique anchor '+before.slice(0,80));engine=engine.replace(before,after);patches.push({before,after});}
// The existing selector remains the single source of shadow material parameters.
// No draw, frustum/matrix update, target allocation, world callback or GPU upload.
replace('this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=1,this.render=function(e,i,o){',`
this.prepareDepthMaterials=function(scene,camera,lights,prepare){
 if(!this.enabled)return;
 for(const light of lights){
  const shadow=light.shadow;if(!shadow)continue;
  scene.traverseVisible(object=>{
   if(!object.layers.test(camera.layers)||!(object.isMesh||object.isLine||object.isPoints)||!(object.castShadow||(object.receiveShadow&&this.type===3)))return;
   const visit=material=>{if(material&&material.visible)prepare(_(object,material,light,shadow.camera.near,shadow.camera.far,this.type),object);};
   if(Array.isArray(object.material)){for(const group of object.geometry.groups)visit(object.material[group.materialIndex]);}
   else visit(object.material);
  });
 }
};
this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=1,this.render=function(e,i,o){`);
replace('this.compile=function(t,e){function i(t,e,i){','this.compile=function(t,e,tbsOptions){function i(t,e,i){');
replace('f.pop(),p=null};\nthis.compileAsyncPasses=',`tbsOptions?.shadowDepth&&ut.prepareDepthMaterials(t,e,p.state.shadowsArray,(material,object)=>Ut(material,q,object)),f.pop(),p=null};
this.compileAsyncPasses=`);
replace('this.compile(pass.scene,pass.camera);','this.compile(pass.scene,pass.camera,{shadowDepth:pass.name===\'main-linear\'});');
fs.writeFileSync(path.join(dir,'three-r149-async-plus.min.js'),engine,{flag:'wx'});
fs.writeFileSync(path.join(dir,'engine-patch.json'),JSON.stringify({baselineSHA256:hash(original),candidateSHA256:hash(engine),patches,scope:'Only stock shadow-material acquisition and program-cache coverage; unchanged KHR polling, water and graphics.'},null,2),{flag:'wx'});
for(const name of ['three-r149-async.min.js','graphics-experimental.js','app-experimental.js','probe.js','menu-probe-final.js','program-observer.js','png.cjs'])fs.copyFileSync(path.join(prior,name),path.join(dir,name),fs.constants.COPYFILE_EXCL);
for(const mode of ['B','P']){
 let html=fs.readFileSync(path.join(root,'index.html'),'utf8').replace('<head>','<head>\n<base href="'+pathToFileURL(root+path.sep).href+'">');
 for(const [old,name]of [['assets/three.min.js',mode==='P'?'three-r149-async-plus.min.js':'three-r149-async.min.js'],['dist/adapters/rendering/graphics.js','graphics-experimental.js'],['dist/app.js','app-experimental.js']])html=html.replace('src="'+old+'"','src="'+pathToFileURL(path.join(dir,name)).href+'"');
 fs.writeFileSync(path.join(dir,'index-'+mode+'.html'),html,{flag:'wx'});
}
let visual=fs.readFileSync(path.join(root,'artifacts/r149-async-abc-acceptance-20261020/verify-visual.cjs'),'utf8');
visual=visual.replace("mode==='B'?1:0","1").replace("mode!=='A'","true")
 .replace("[['A1','A'],['B','B'],['C','C'],['A2','A']]","[['A1','B'],['B','P'],['C','P'],['A2','B']]");
// The pre-existing observer measures reuse without altering callbacks or rendering.
visual=visual.replace("await page.bringToFront();","await page.bringToFront();await page.addInitScript({path:path.join(dir,'program-observer.js')});");
visual=visual.replace("const png=r.domElement.toDataURL('image/png');","const observation=window.__programDiag.snapshot(r);const png=r.domElement.toDataURL('image/png');");
visual=visual.replace('return{nonce:window.__captureNonce','return{observation,nonce:window.__captureNonce');
// Keep water/publication state for direct comparison, in addition to framebuffer.
visual=visual.replace('const observation=window.__programDiag.snapshot(r);',"const water=w.scene.userData.waterMaterial.userData.shader;const waterState={wave:water?.uniforms.waveTime?.value,strength:water?.uniforms.reflectionStrength?.value};const observation=window.__programDiag.snapshot(r);");
visual=visual.replace('return{observation,nonce:','return{waterState,observation,nonce:');
fs.writeFileSync(path.join(dir,'verify-visual.cjs'),visual,{flag:'wx'});
let run=fs.readFileSync(path.join(prior,'run-abc.cjs'),'utf8');
run=run.replace("data.preparationCalls!==(mode==='B'?1:0)||data.modifiedRenderer!==(mode!=='A')","data.preparationCalls!==1||data.modifiedRenderer!==true");
run=run.replace("const orders=[['A','B','C'],['B','C','A'],['C','A','B']];for(let pair=1;pair<=3;pair++)", "const cycle=Number(process.argv[2]||1);const orders=[['B','P'],['P','B'],['B','P']];for(let pair=cycle;pair<=cycle;pair++)");
run=run.replace("'abc'","'late'");
run=run.replace("pair1 A/B/C; pair2 B/C/A; pair3 C/A/B; own new profile then same profile restart per variant","cycle1 B/B+; cycle2 B+/B; optional cycle3 B/B+; own new profile then same profile restart per variant");
run=run.replace('Native timer probe and trace enabled equally in six runs.','Native timer probe and trace enabled equally in B and B+. New profile does not imply cold system/GPU cache.');
run=run.replace("base:'89613bbf312bbb053de05471b98ee1f8747f5739'","base:'5cbd6f741415bf10d44b2a6088b9bc26e1916d50'");
fs.writeFileSync(path.join(dir,'run-bp.cjs'),run,{flag:'wx'});
console.log(JSON.stringify({patches:patches.length,bytes:engine.length,candidate:hash(engine)}));
