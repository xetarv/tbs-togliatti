(() => {
  const d = window.__localization = { events: [], frames: [], passReads: [], currentStep: 0, readStateChanges: 0 };
  const array = v => v?.toArray ? v.toArray() : ArrayBuffer.isView(v) ? Array.from(v) : v;
  const uniformValues = uniforms => Object.fromEntries(Object.entries(uniforms || {}).filter(([k]) => ['waveTime', 'reflectionStrength', 'waterReflectionMatrix', 'inverseProjection', 'ao', 'glow', 'pixel'].includes(k)).map(([k, v]) => [k, array(v.value)]));
  const hash = bytes => {
    let a = 2166136261, b = 0;
    for (let i = 0; i < bytes.length; i++) { a = Math.imul(a ^ bytes[i], 16777619); b = (Math.imul(b, 33) + bytes[i]) | 0; }
    return [bytes.length, a >>> 0, b >>> 0];
  };
  const waterState = () => {
    const water = d.world?.scene.userData.waterMaterial, props = water && d.renderer.properties.get(water);
    return { published: !!water?.userData.shader, uniforms: uniformValues(water?.userData.shader?.uniforms), cached: uniformValues(props?.uniforms), materialVersion: water?.version, program: props?.currentProgram?.cacheKey };
  };
  d.attachRenderer = (renderer, T) => {
    d.renderer = renderer; d.T = T;
    const gl = renderer.getContext(), originalRender = renderer.render; let nesting = 0;
    renderer.render = function(scene, camera) {
      const level = nesting++, target = renderer.getRenderTarget(), face = renderer.getActiveCubeFace();
      const role = scene === d.world?.scene ? 'world-main' : target?.isWebGLCubeRenderTarget ? `reflection-cube-${target.width}` : camera.isOrthographicCamera && !target ? 'post-output' : 'reflection-planar';
      const row = { step: d.currentStep, level, role, face, target: target ? [target.width, target.height, target.texture.type] : null };
      if (level === 0) { row.waterBefore = waterState(); row.camera = { position: camera.position.toArray(), quaternion: camera.quaternion.toArray(), projection: camera.projectionMatrix.toArray(), inverse: camera.projectionMatrixInverse.toArray() }; }
      let result;
      try { result = originalRender.apply(this, arguments); } finally { nesting--; }
      if (level === 0 && (d.currentStep <= 61 || d.currentStep === 361)) {
        row.waterAfter = waterState();
        const width = target?.width || gl.drawingBufferWidth, height = target?.height || gl.drawingBufferHeight;
        if (!target || target.texture.type === T.UnsignedByteType) {
          const before = { framebuffer: gl.getParameter(gl.FRAMEBUFFER_BINDING), target: renderer.getRenderTarget(), face: renderer.getActiveCubeFace(), mip: renderer.getActiveMipmapLevel() };
          const pixels = new Uint8Array(width * height * 4); gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
          row.pixelHash = hash(pixels); row.readError = gl.getError();
          if (before.framebuffer !== gl.getParameter(gl.FRAMEBUFFER_BINDING) || before.target !== renderer.getRenderTarget() || before.face !== renderer.getActiveCubeFace() || before.mip !== renderer.getActiveMipmapLevel()) d.readStateChanges++;
          // Retain only final moving-frame main/output images; all other reads are hashes.
          if (d.currentStep === 61 && ['world-main', 'post-output'].includes(role)) d.passReads.push({ role, width, height, pixels });
        }
        if (role === 'world-main') {
          const p = renderer.properties.get(d.world.scene.userData.waterMaterial).currentProgram?.program;
          if (p) row.nativeWater = Object.fromEntries(['waveTime', 'reflectionStrength', 'waterReflectionMatrix'].map(k => [k, array(gl.getUniform(p, gl.getUniformLocation(p, k)))]));
        }
        if (role === 'post-output') row.postUniforms = uniformValues(scene.children[0]?.material.uniforms);
        d.frames.push(row);
      }
      return result;
    };
  };
  d.attachWorld = world => { d.world = world; };
  d.attachGraphics = options => {
    const water = options.water, compile = water.onBeforeCompile;
    const observedCompile = function(shader) {
      d.events.push({ kind: 'compile-before', step: d.currentStep, water: waterState() });
      const result = compile.apply(this, arguments);
      d.events.push({ kind: 'compile-after', step: d.currentStep, water: waterState(), shaderUniforms: uniformValues(shader.uniforms) });
      return result;
    };
    observedCompile.toString = () => compile.toString();
    water.onBeforeCompile = observedCompile;
    d.world.scene.traverse(object => {
      if (object.material !== water) return;
      for (const event of ['onBeforeRender', 'onAfterRender']) {
        const original = object[event];
        object[event] = function() {
          if (d.currentStep <= 2 || d.currentStep === 61) d.events.push({ kind: event, step: d.currentStep, water: waterState() });
          return original.apply(this, arguments);
        };
      }
    });
  };
  d.finish = () => {
    const r = d.renderer, gl = r.getContext();
    const sources = r.info.programs.map(p => ({ name: p.name, cacheKey: p.cacheKey, sources: (gl.getAttachedShaders(p.program) || []).map(s => ({ type: gl.getShaderParameter(s, gl.SHADER_TYPE), source: gl.getShaderSource(s) })) }));
    const passReads = d.passReads.map(({ pixels, ...row }) => { let s = ''; for (let i = 0; i < pixels.length; i += 32768) s += String.fromCharCode(...pixels.subarray(i, i + 32768)); return { ...row, rgba: btoa(s) }; });
    return { events: d.events, frames: d.frames, readStateChanges: d.readStateChanges, sources, passReads, error: gl.getError() };
  };
})();
