const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=__dirname,read=n=>JSON.parse(fs.readFileSync(path.join(dir,n)));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const observations=Object.fromEntries(['A1','B','C','A2'].map(n=>[n,read(`local-${n}-observation.json`)]));
const controls=Object.fromEntries(['A1','B','C','A2'].map(n=>[n,read(`local-${n}.json`)]));
const results={};
for(const name of ['B','C','A2']){
 const a=observations.A1,b=observations[name],mismatches=[];
 for(let i=0;i<Math.max(a.frames.length,b.frames.length);i++){
  const x=a.frames[i],y=b.frames[i];
  if(!x||!y){mismatches.push({index:i,missing:true});continue;}
  const fields=['step','role','face','target','pixelHash','camera','postUniforms','nativeWater'];
  const unequal=fields.filter(k=>!same(x[k],y[k]));
  if(unequal.length)mismatches.push({index:i,step:x.step,role:x.role,fields:unequal,a:Object.fromEntries(unequal.map(k=>[k,x[k]])),b:Object.fromEntries(unequal.map(k=>[k,y[k]]))});
 }
 const sourceSignature=p=>sha(Buffer.from(JSON.stringify(p.sources)));
 const sa=a.sources.map(sourceSignature),sb=b.sources.map(sourceSignature);
 results[name]={frameCount:[a.frames.length,b.frames.length],mismatchCount:mismatches.length,firstMismatches:mismatches.slice(0,6),allMismatches:mismatches,sourceCount:[sa.length,sb.length],sourceSetsEqual:same([...sa].sort(),[...sb].sort()),onlyASources:a.sources.filter((p,i)=>!sb.includes(sa[i])).map((p,i)=>({name:p.name,hash:sourceSignature(p)})),onlyOtherSources:b.sources.filter((p,i)=>!sa.includes(sb[i])).map(p=>({name:p.name,hash:sourceSignature(p)})),readStateChanges:b.readStateChanges,errors:controls[name].errors,glError:b.error,preparationCalls:controls[name].first.preparationCalls};
}
fs.writeFileSync(path.join(dir,'pass-comparison.json'),JSON.stringify(results,null,2));
console.log(JSON.stringify(Object.fromEntries(Object.entries(results).map(([n,r])=>[n,{frameCount:r.frameCount,mismatchCount:r.mismatchCount,firstMismatches:r.firstMismatches,sourceSetsEqual:r.sourceSetsEqual,sourceCount:r.sourceCount,readStateChanges:r.readStateChanges,errors:r.errors,glError:r.glError,preparationCalls:r.preparationCalls}]))));
