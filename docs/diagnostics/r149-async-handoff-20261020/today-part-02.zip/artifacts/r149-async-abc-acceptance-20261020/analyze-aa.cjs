const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=__dirname,read=n=>JSON.parse(fs.readFileSync(path.join(dir,n))),sha=b=>crypto.createHash('sha256').update(b).digest('hex'),same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const a=read('aa-A1-draws.json'),b=read('aa-A2-draws.json'),ca=read('aa-A1.json'),cb=read('aa-A2.json');
const source=p=>sha(Buffer.from(JSON.stringify(p.sources))),diffs=[];
for(let i=0;i<Math.max(a.draws.length,b.draws.length);i++){
 const x=a.draws[i],y=b.draws[i];if(!x||!y){diffs.push({i,missing:true});continue;}
 const fields=['call','args','metadata','textures'].filter(k=>!same(x[k],y[k]));
 const uniformNames=[...new Set([...Object.keys(x.uniforms),...Object.keys(y.uniforms)])].filter(k=>!same(x.uniforms[k],y.uniforms[k]));
 const sourceEqual=source(a.programs[x.program])===source(b.programs[y.program]);
 if(fields.length||uniformNames.length||!sourceEqual)diffs.push({i,name:x.metadata.name,type:x.metadata.type,material:x.metadata.material,depthPass:x.metadata.depthPass,fields,sourceEqual,uniformDifferences:Object.fromEntries(uniformNames.map(k=>[k,{a:x.uniforms[k],b:y.uniforms[k]}])),metadataDifferences:!same(x.metadata,y.metadata)?{a:x.metadata,b:y.metadata}:undefined});
}
const bufferDiff=(an,bn)=>{const x=fs.readFileSync(path.join(dir,an)),y=fs.readFileSync(path.join(dir,bn));let changedPixels=0,maxDelta=0;for(let i=0;i<x.length;i+=4){let changed=false;for(let k=0;k<4;k++){const v=Math.abs(x[i+k]-y[i+k]);if(v)changed=true;maxDelta=Math.max(maxDelta,v);}changedPixels+=changed;}return{changedPixels,maxDelta,bytesEqual:x.equals(y)};};
const result={drawCounts:[a.draws.length,b.draws.length],programCounts:[a.programs.length,b.programs.length],textureCounts:[a.textures.length,b.textures.length],drawInputsEqual:diffs.length===0,differentDrawCount:diffs.length,firstDifferences:diffs.slice(0,8),allDifferences:diffs,cameraEqual:same(ca.moving.camera,cb.moving.camera),simulationEqual:ca.moving.stateSHA256===cb.moving.stateSHA256&&ca.moving.trafficSHA256===cb.moving.trafficSHA256,worldTransformsEqual:ca.moving.worldTransformsSHA256===cb.moving.worldTransformsSHA256,captureMetadata:[a.captures,b.captures],mainImage:bufferDiff('aa-A1-second-main.rgba','aa-A2-second-main.rgba'),outputImage:bufferDiff('aa-A1-moving.rgba','aa-A2-moving.rgba'),firstImage:bufferDiff('aa-A1-first.rgba','aa-A2-first.rgba'),limits:['Texture bindings use deterministic creation-order IDs; complete texture/geometry payloads and internal PMREM contents are not compared.','Native uniform uploads are recorded without additional getUniform calls. Capturing draw metadata affects timing; no performance conclusion from these runs.']};
fs.writeFileSync(path.join(dir,'aa-comparison.json'),JSON.stringify(result,null,2),{flag:'wx'});
console.log(JSON.stringify({...result,allDifferences:undefined,firstDifferences:result.firstDifferences.map(x=>({...x,metadataDifferences:undefined})),captureMetadata:undefined}));
