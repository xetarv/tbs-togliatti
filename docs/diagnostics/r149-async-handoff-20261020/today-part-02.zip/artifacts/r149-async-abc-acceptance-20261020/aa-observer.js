// Targeted stock A/A observer: record actual uniform uploads and draw inputs only for step 2.
(() => {
 const d=window.__aa={step:0,draws:[],programs:[],textures:[],captures:[],error:0},contexts=new WeakMap(),locations=new WeakMap();
 const context=g=>{let s=contexts.get(g);if(!s){s={program:null,unit:0,bindings:{},programIDs:new WeakMap(),textureIDs:new WeakMap(),uniforms:new Map()};contexts.set(g,s);}return s;};
 const programID=(s,p)=>{if(!s.programIDs.has(p)){s.programIDs.set(p,d.programs.length);d.programs.push({id:d.programs.length,sources:[]});}return s.programIDs.get(p);};
 const textureID=(s,t)=>{if(!t)return null;if(!s.textureIDs.has(t)){s.textureIDs.set(t,d.textures.length);d.textures.push({id:d.textures.length});}return s.textureIDs.get(t);};
 const array=v=>ArrayBuffer.isView(v)||Array.isArray(v)?Array.from(v):v;
 const names=['createProgram','getUniformLocation','useProgram','activeTexture','bindTexture','uniform1f','uniform2f','uniform3f','uniform4f','uniform1i','uniform2i','uniform3i','uniform4i','uniform1ui','uniform2ui','uniform3ui','uniform4ui','uniform1fv','uniform2fv','uniform3fv','uniform4fv','uniform1iv','uniform2iv','uniform3iv','uniform4iv','uniformMatrix2fv','uniformMatrix3fv','uniformMatrix4fv','uniformMatrix2x3fv','uniformMatrix3x2fv','uniformMatrix2x4fv','uniformMatrix4x2fv','uniformMatrix3x4fv','uniformMatrix4x3fv','drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced'];
 for(const proto of [WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype])for(const name of names){
  const original=proto[name];if(!original||original.__aaObserved)continue;
  const wrapped=function(...args){const s=context(this),result=Reflect.apply(original,this,args);
   if(name==='createProgram'&&result)programID(s,result);
   if(name==='getUniformLocation'&&result)locations.set(result,{id:programID(s,args[0]),name:args[1]});
   if(name==='useProgram')s.program=args[0];
   if(name==='activeTexture')s.unit=args[0]-this.TEXTURE0;
   if(name==='bindTexture')s.bindings[s.unit+':'+args[0]]=textureID(s,args[1]);
   if(name.startsWith('uniform')&&args[0]){
    const loc=locations.get(args[0]);if(loc){let values;
     if(name.includes('Matrix'))values=array(args[2]).slice(args[3]||0,args[4]?((args[3]||0)+args[4]):undefined);
     else if(name.endsWith('v'))values=array(args[1]).slice(args[2]||0,args[3]?((args[2]||0)+args[3]):undefined);
     else values=args.slice(1);
     if(/fv?$/.test(name))values=values.map(Math.fround);
     let u=s.uniforms.get(loc.id);if(!u)s.uniforms.set(loc.id,u={});u[loc.name]=values;
    }
   }
   if(name.startsWith('draw')&&d.step===2&&d.drawMetadata&&s.program){
    const id=programID(s,s.program),p=d.programs[id];
    if(!p.sources.length)p.sources=(this.getAttachedShaders(s.program)||[]).map(shader=>({type:this.getShaderParameter(shader,this.SHADER_TYPE),source:this.getShaderSource(shader)}));
    d.draws.push({call:name,args,program:id,metadata:d.drawMetadata,uniforms:JSON.parse(JSON.stringify(s.uniforms.get(id)||{})),textures:{...s.bindings}});
   }
   return result;
  };wrapped.__aaObserved=true;proto[name]=wrapped;
 }
 d.attachWorld=world=>{
  const r=world.renderer,g=r.getContext(),render=r.render,direct=r.renderBufferDirect;let currentScene;
  r.render=function(scene,camera){const before=currentScene;currentScene=scene;let result;
   try{result=Reflect.apply(render,this,arguments);
    if(d.step===2&&scene===world.scene){
     const target=r.getRenderTarget(),binding=g.getParameter(g.FRAMEBUFFER_BINDING),w=target?.width||g.drawingBufferWidth,h=target?.height||g.drawingBufferHeight,pixels=new Uint8Array(w*h*4);
     g.readPixels(0,0,w,h,g.RGBA,g.UNSIGNED_BYTE,pixels);let s='';for(let i=0;i<pixels.length;i+=32768)s+=String.fromCharCode(...pixels.subarray(i,i+32768));
     d.captures.push({kind:'second-main',width:w,height:h,pixels:btoa(s),camera:{position:camera.position.toArray(),quaternion:camera.quaternion.toArray(),world:camera.matrixWorld.toArray(),view:camera.matrixWorldInverse.toArray(),projection:camera.projectionMatrix.toArray()},dither:g.isEnabled(g.DITHER),sameFramebuffer:binding===g.getParameter(g.FRAMEBUFFER_BINDING),error:g.getError()});
    }
    return result;
   }finally{currentScene=before;}
  };
  r.renderBufferDirect=function(camera,scene,geometry,material,object,group){
   const old=d.drawMetadata;
   if(d.step===2&&currentScene===world.scene)d.drawMetadata={name:object.name,type:object.type,material:material.type,depthPass:!!material.isMeshDepthMaterial,world:object.matrixWorld.toArray(),modelView:object.modelViewMatrix.toArray(),normal:object.normalMatrix.toArray(),position:object.position.toArray(),quaternion:object.quaternion.toArray(),geometry:{type:geometry.type,indexCount:geometry.index?.count||0,attributes:Object.fromEntries(Object.entries(geometry.attributes).map(([k,v])=>[k,{count:v.count,itemSize:v.itemSize,normalized:v.normalized}]))},materialState:{color:material.color?.toArray(),emissive:material.emissive?.toArray(),roughness:material.roughness,metalness:material.metalness,opacity:material.opacity,side:material.side,transparent:material.transparent,depthTest:material.depthTest,depthWrite:material.depthWrite},group};
   try{return Reflect.apply(direct,this,arguments);}finally{d.drawMetadata=old;}
  };
 };
 d.finish=()=>({draws:d.draws,programs:d.programs,textures:d.textures,captures:d.captures});
})();
