const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=__dirname,root=path.resolve(dir,'../..'),prior=path.resolve(dir,'../r149-async-failures-20261020'),clean=path.resolve(dir,'../r149-async-final-cleanup-20261020');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),write=(n,s)=>fs.writeFileSync(path.join(dir,n),s,{flag:'wx'});
const m=JSON.parse(fs.readFileSync(path.join(prior,'preserved-before.json')));
for(const [f,h]of Object.entries(m))if(sha(fs.readFileSync(path.join(root,f)))!==h)throw Error('Historical file changed '+f);
for(const n of ['prepare.cjs','observe.js','run.cjs','summary.json','report.md','shader-error.json','no-khr.json','loss-pending.json','loss-after-ready.json'])m[path.relative(root,path.join(prior,n))]=sha(fs.readFileSync(path.join(prior,n)));
for(const n of ['index.html','dist/app.js','dist/adapters/rendering/graphics.js'])m[n]=sha(fs.readFileSync(path.join(root,n)));
write('preserved-before.json',JSON.stringify(m,null,2));
write('dispose-environment.js',fs.readFileSync(path.join(clean,'dispose-environment.js')));
let o=fs.readFileSync(path.join(prior,'observe.js'),'utf8');
function once(a,b){if(o.split(a).length!==2)throw Error('Observer anchor '+a);o=o.replace(a,b);}
once("for(const name of ['buildWorld','buildPresentation','createRuntime'])","for(const name of ['createScene','buildWorld','buildPresentation','createRuntime'])");
once('const result=Reflect.apply(original,this,args);',`let result;
  if(name==='createScene'){
   d.environmentTargets ||= new Map();const proto=THREE.PMREMGenerator.prototype,from=proto.fromScene;
   proto.fromScene=function(...a){const target=Reflect.apply(from,this,a);d.environmentTargets.set(target.texture,target);return target;};
   try{result=Reflect.apply(original,this,args);}finally{proto.fromScene=from;}
  }else result=Reflect.apply(original,this,args);`);
once('d.world=result;const r=result.renderer;d.renderer=r;',`d.world=result;const r=result.renderer;d.renderer=r;
   // Diagnostic owner exposure only; the original createScene/game are unchanged.
   result.startupEnvironmentTarget=d.environmentTargets.get(result.scene.environment);
   d.seenScenes=new Set([result.scene]);r.__startupPasses=()=>[...d.seenScenes].map(scene=>({scene}));
   d.components=()=>{
    const gl=r.getContext(),tex=value=>{if(!value?.isTexture)return null;const h=r.properties.get(value).__webglTexture;return{uuid:value.uuid,native:ids.get(h)?.id,valid:!!h&&!gl.isContextLost()&&gl.isTexture(h),renderTarget:!!value.isRenderTargetTexture};};
    const paints=new Set(),shadows=[];
    result.scene.traverse(o=>{if(o.userData.paint?.envMap)paints.add(o.userData.paint.envMap);if(o.isLight&&o.shadow?.map)shadows.push({type:o.type,map:tex(o.shadow.map.texture)});});
    const water=result.scene.userData.waterMaterial?.userData.shader;
    return{environment:tex(result.scene.environment),paint:[...paints].map(tex),quarter:[...new Set((result.scene.userData.quarterLighting?.reflective||[]).map(m=>m.envMap).filter(Boolean))].map(tex),water:{texture:tex(water?.uniforms.waterReflection?.value),strength:water?.uniforms.reflectionStrength?.value,wave:water?.uniforms.waveTime?.value},shadows,fullMainFrames:d.completedMainFrames};
   };`);
once('const before=d.draws,lost=r.getContext().isContextLost();', 'd.seenScenes.add(scene);const before=d.draws,lost=r.getContext().isContextLost();');
once('window.requestAnimationFrame=function(fn){let id;',`window.requestAnimationFrame=function(fn){
  if(scenario==='A1'&&d.runtime&&!d.triggered){d.triggered=true;event('loss-before-first-stock-frame',{frames:d.completedMainFrames});d.beforeLoss=d.components();const ext=d.renderer.getContext().getExtension('WEBGL_lose_context');if(!ext)throw Error('WEBGL_lose_context unavailable');ext.loseContext();}
  let id;`);
write('observe-a.js',o);
console.log('Prepared original-index stock A control with external observation/fault injection; '+Object.keys(m).length+' preserved files.');
