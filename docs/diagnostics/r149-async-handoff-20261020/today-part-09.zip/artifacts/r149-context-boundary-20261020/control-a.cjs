const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,root=path.resolve(dir,'../..'),save=(n,j)=>fs.writeFileSync(path.join(dir,n),JSON.stringify(j,null,2),{flag:'wx'});
async function run(mode){
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles',mode),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 let page;const errors=[],messages=[];
 try{
  page=context.pages()[0];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(['error','warning'].includes(m.type()))messages.push({type:m.type(),text:m.text()});});
  await page.addInitScript({content:fs.readFileSync(path.join(dir,'dispose-environment.js'),'utf8')+'\nwindow.__installDiagnosticCleanup=installStartupEnvironmentCleanup;'});
  await page.addInitScript({content:'('+fs.readFileSync(path.join(dir,'observe-a.js'),'utf8')+')('+JSON.stringify(mode)+');'});
  await page.goto(pathToFileURL(path.join(root,'index.html')).href,{waitUntil:'load',timeout:180000});
  if(mode==='A2'){
   await page.waitForFunction(()=>__lc.completedMainFrames>=2,null,{timeout:60000});
   await page.evaluate(()=>{const d=__lc;d.beforeLoss=d.components();d.triggered=true;d.renderer.getContext().getExtension('WEBGL_lose_context').loseContext();});
  }
  await page.waitForFunction(()=>__lc.contextLost,null,{timeout:60000});
  const lost=await page.evaluate(()=>({components:__lc.components(),snapshot:__lc.snapshot()}));
  const restored=await page.evaluate(async()=>{
   const d=__lc,canvas=d.renderer.domElement;
   await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Restore event timeout')),5000);canvas.addEventListener('webglcontextrestored',()=>{clearTimeout(timer);resolve();},{once:true});d.loseExtension.restoreContext();});
   return{snapshot:d.snapshot(),components:d.components()};
  });
  await page.waitForFunction(n=>__lc.completedMainFrames>=n+2,lost.snapshot.completedMainFrames,{timeout:60000});
  await page.evaluate(()=>{const d=__lc;document.getElementById('startBtn').addEventListener('click',e=>d.clickTrusted=e.isTrusted,{once:true});document.addEventListener('keydown',e=>{if(e.code==='KeyW')d.keyTrusted=e.isTrusted;},{once:true});});
  const player=await page.evaluate(()=>({...__lc.state.player}));await page.locator('#startBtn').click();await page.keyboard.down('w');
  await page.waitForFunction(p=>__lc.state.player.speed>0&&Math.hypot(__lc.state.player.x-p.x,__lc.state.player.z-p.z)>0.1,player,{timeout:10000});
  await page.waitForTimeout(1000);await page.keyboard.up('w');
  const beforeClose=await page.evaluate(()=>({snapshot:__lc.snapshot(),components:__lc.components(),player:{...__lc.state.player},quality:__lc.ports.graphics.quality,modifiedRenderer:typeof __lc.renderer.compileAsyncPasses==='function',trusted:[__lc.clickTrusted,__lc.keyTrusted]}));
  await page.screenshot({path:path.join(dir,mode+'-restored.png')});
  const after=await page.evaluate(()=>{const d=__lc;d.close=__installDiagnosticCleanup(d.world,d.runtime);d.close();return d.snapshot();});
  const j={mode,browser:context.browser().version(),originalURL:pathToFileURL(path.join(root,'index.html')).href,beforeLoss:await page.evaluate(()=>__lc.beforeLoss),lost,restored,beforeClose,after,errors,messages,note:'Original index/renderer/app/graphics, no async preparation. Only external tracing/fault injection. Terminal control calls original public owners through the same diagnostic world teardown; it does not patch A.'};
  save(mode+'.json',j);
  console.log(JSON.stringify({mode,modifiedRenderer:beforeClose.modifiedRenderer,frames:beforeClose.snapshot.completedMainFrames,components:beforeClose.components,move:Math.hypot(beforeClose.player.x-player.x,beforeClose.player.z-player.z),trusted:beforeClose.trusted,glBefore:beforeClose.snapshot.glError,glAfter:after.glError,errors:errors.length}));
 }catch(error){let snapshot;try{snapshot=await page.evaluate(()=>__lc?.snapshot());}catch{}save(mode+'-failure.json',{error:error.stack,snapshot,errors,messages});throw error;}
 finally{await context.close();}
}
(async()=>{await run('A1');await run('A2');})().catch(e=>{console.error(e.stack);process.exitCode=1;});
