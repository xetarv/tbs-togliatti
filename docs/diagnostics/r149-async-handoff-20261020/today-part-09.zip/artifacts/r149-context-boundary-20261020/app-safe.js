'use strict';
(async () => {
    const api = window.TBS;
    function reportError(error) {
        console.error(error);
        let message;
        try {
            message =
                error !== null &&
                    (typeof error === 'object' || typeof error === 'function') &&
                    'message' in error
                    ? String(error.message)
                    : String(error);
        }
        catch {
            // Keep the original value in the console even if its getters/coercion fail.
            message = 'Не удалось получить описание ошибки';
        }
        const toast = document.getElementById('toast');
        if (toast) {
            toast.textContent = 'Ошибка запуска 3D: ' + message;
            toast.classList.add('show');
        }
        const startButton = document.getElementById('startBtn');
        if (startButton)
            startButton.disabled = true;
    }
    addEventListener('error', (event) => reportError(event.error || new Error(event.message)));
    try {
        const dom = api.createDom(document);
        if (!window.THREE) {
            dom.getElement('overlayCopy').textContent =
                'Не удалось загрузить локальную библиотеку 3D. Проверьте, что папка assets находится рядом с index.html.';
            dom.getElement('startBtn').disabled = true;
            return;
        }
        const T = window.THREE;
        T.ColorManagement.legacyMode = false;
        const state = api.domain.createState();
        const presentation = api.createPresentationState(state);
        const world = api.buildWorld({ T, canvas: dom.canvas, config: api.domain.config });
        const { runtime, session } = api.buildGame({ state, presentation, world, dom });
        const startupAbort=new AbortController();
        const closeCore=installStartupEnvironmentCleanup(world,runtime);
        const canvas=world.renderer.domElement;
        let contextFailure=null;
        const closeEnvironment=()=>{
            canvas.removeEventListener('webglcontextlost',onContextLoss);
            closeCore();
        };
        function onContextLoss(event) {
            if (event) event.preventDefault();
            if (contextFailure) return;
            contextFailure=new Error('Графический контекст потерян. Перезапустите страницу клавишей F5 или кнопкой обновления браузера.');
            startupAbort.abort(contextFailure);
            try { closeEnvironment(); }
            catch (cleanupError) { console.error('Cleanup error (context loss preserved)',cleanupError); }
            reportError(contextFailure);
            dom.getElement('overlayCopy').textContent=contextFailure.message;
            dom.getElement('overlay').classList.remove('hidden');
        }
        world.renderer.__startupClose=closeEnvironment;
        canvas.addEventListener('webglcontextlost',onContextLoss);
        const cancel=()=>startupAbort.abort(new Error('Page left during preparation'));
        addEventListener('pagehide',cancel,{once:true});
        try {
            await world.renderer.compileAsyncPasses(world.renderer.__startupPasses(),{signal:startupAbort.signal});
            // A resolved result is not permission to start a closed/lost generation.
            if (world.renderer.getContext().isContextLost()) onContextLoss();
            if (startupAbort.signal.aborted) throw startupAbort.signal.reason;
        }
        catch(error){try{closeEnvironment();}catch(cleanupError){console.error("Cleanup error (original preparation error preserved)",cleanupError);}if(contextFailure!==null&&error===contextFailure)return;throw error;}
        finally {removeEventListener('pagehide',cancel);}
        runtime.start();
        if (new URLSearchParams(location.search).has('play'))
            session.start();
    }
    catch (error) {
        reportError(error);
    }
})();
