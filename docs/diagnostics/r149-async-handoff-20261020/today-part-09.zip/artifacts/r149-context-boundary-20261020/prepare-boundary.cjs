const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{pathToFileURL}=require('node:url');
const dir=__dirname,prior=path.resolve(dir,'../r149-async-final-cleanup-20261020'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const write=(n,s)=>fs.writeFileSync(path.join(dir,n),s,{flag:'wx'});
const control=JSON.parse(fs.readFileSync(path.join(dir,'A2.json')));
if(control.beforeClose.modifiedRenderer||control.beforeClose.components.environment.valid||control.after.glError!==1282)throw Error('Stock A attribution not established');
for(const n of ['three-stage2.js','scene.js','graphics.js'])write(n,fs.readFileSync(path.join(prior,n)));
const before=fs.readFileSync(path.join(prior,'app.js'),'utf8');
const old="        const closeEnvironment=installStartupEnvironmentCleanup(world,runtime);\n        const startupAbort=new AbortController();";
const next=`        const startupAbort=new AbortController();
        const closeCore=installStartupEnvironmentCleanup(world,runtime);
        const canvas=world.renderer.domElement;
        let contextFailure=null;
        const closeEnvironment=()=>{
            canvas.removeEventListener('webglcontextlost',onContextLoss);
            closeCore();
        };
        function onContextLoss(event) {
            if (event) event.preventDefault();
            if (contextFailure) return;
            contextFailure=new Error('Графический контекст потерян. Перезапустите страницу клавишей F5 или кнопкой обновления браузера.');
            startupAbort.abort(contextFailure);
            try { closeEnvironment(); }
            catch (cleanupError) { console.error('Cleanup error (context loss preserved)',cleanupError); }
            reportError(contextFailure);
            dom.getElement('overlayCopy').textContent=contextFailure.message;
            dom.getElement('overlay').classList.remove('hidden');
        }
        world.renderer.__startupClose=closeEnvironment;
        canvas.addEventListener('webglcontextlost',onContextLoss);`;
if(before.split(old).length!==2)throw Error('Boundary anchor');
let after=before.replace(old,next);
const awaitOld='try {await world.renderer.compileAsyncPasses(world.renderer.__startupPasses(),{signal:startupAbort.signal});}';
const awaitNew=`try {
            await world.renderer.compileAsyncPasses(world.renderer.__startupPasses(),{signal:startupAbort.signal});
            // A resolved result is not permission to start a closed/lost generation.
            if (world.renderer.getContext().isContextLost()) onContextLoss();
            if (startupAbort.signal.aborted) throw startupAbort.signal.reason;
        }`;
if(after.split(awaitOld).length!==2)throw Error('Handoff anchor');after=after.replace(awaitOld,awaitNew);
const catchOld='catch(error){try{closeEnvironment();}catch(cleanupError){console.error("Cleanup error (original preparation error preserved)",cleanupError);}throw error;}';
const catchNew='catch(error){try{closeEnvironment();}catch(cleanupError){console.error("Cleanup error (original preparation error preserved)",cleanupError);}if(contextFailure!==null&&error===contextFailure)return;throw error;}';
if(after.split(catchOld).length!==2)throw Error('Catch anchor');after=after.replace(catchOld,catchNew);
write('app-before.js',before);write('app-safe.js',after);
write('boundary-patch.json',JSON.stringify({beforeSHA256:sha(before),afterSHA256:sha(after),file:'app-safe.js',before:old,after:next,handoff:{before:awaitOld,after:awaitNew},catch:{before:catchOld,after:catchNew},reason:'One terminal context-loss boundary: abort the current startup permission, stop/close before any restore, remove the loss listener on terminal cleanup, show explicit user-controlled reload. No engine/world/PMREM/polling changes.'},null,2));
let html=fs.readFileSync(path.join(prior,'index-final.html'),'utf8').split(pathToFileURL(prior).href+'/').join(pathToFileURL(dir).href+'/');
write('index-before.html',html.replace('/app.js','/app-before.js'));
write('index-safe.html',html.replace('/app.js','/app-safe.js'));
console.log('Prepared one application context-loss boundary; engine/graphics/world cleanup unchanged.');
