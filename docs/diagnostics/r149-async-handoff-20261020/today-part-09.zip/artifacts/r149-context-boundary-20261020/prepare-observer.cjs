const fs=require('node:fs'),path=require('node:path');const dir=__dirname;
let o=fs.readFileSync(path.resolve(dir,'../r149-async-failures-20261020/observe.js'),'utf8');
const a=fs.readFileSync(path.join(dir,'observe-a.js'),'utf8');
const start=a.indexOf('   d.components=()=>{'),end=a.indexOf('\n   };',start)+6;
if(start<0||end<6)throw Error('Component observation anchor');
const components=a.slice(start,end);
function once(x,y){if(o.split(x).length!==2)throw Error('Unique observer anchor '+x);o=o.replace(x,y);}
once('d.world=result;const r=result.renderer;d.renderer=r;','d.world=result;const r=result.renderer;d.renderer=r;\n'+components);
once('if(!lost&&d.draws>before)d.completedMainFrames++;',`if(!lost&&d.draws>before){d.completedMainFrames++;d.firstFullAt??=performance.now();if(d.state&&d.state.player.speed>0&&Math.hypot(d.state.player.x-d.startPlayer.x,d.state.player.z-d.startPlayer.z)>0.01)d.controlAt??=performance.now();}`);
once("if(name==='buildPresentation'){d.state=args[0].state;", "if(name==='buildPresentation'){d.state=args[0].state;d.startPlayer={...d.state.player};");
once('const add=EventTarget.prototype.addEventListener,remove=EventTarget.prototype.removeEventListener,pagehide=new Set();','const add=EventTarget.prototype.addEventListener,remove=EventTarget.prototype.removeEventListener,pagehide=new Set(),boundary=new Set();');
once("if(this===window&&type==='pagehide'){pagehide.add(fn);", "if(type==='webglcontextlost'&&fn?.name==='onContextLoss')boundary.add(fn);if(this===window&&type==='pagehide'){pagehide.add(fn);");
once("if(this===window&&type==='pagehide'){pagehide.delete(fn);", "if(type==='webglcontextlost'&&fn?.name==='onContextLoss')boundary.delete(fn);if(this===window&&type==='pagehide'){pagehide.delete(fn);");
once('if(args[0]===d.preparationError)d.errorReported=true;', 'if(args[0]===d.preparationError)d.errorReported=true;if(d.signal?.aborted&&args[0]===d.signal.reason)d.boundaryErrorReported=true;');
once('scenario,epoch:d.epoch,',`scenario,signalAborted:!!d.signal?.aborted,signalReason:d.signal?.reason?.message,boundaryErrorReported:!!d.boundaryErrorReported,boundaryListeners:boundary.size,firstFullAt:d.firstFullAt,controlAt:d.controlAt,epoch:d.epoch,`);
fs.writeFileSync(path.join(dir,'observe-b.js'),o,{flag:'wx'});
console.log('Prepared forwarding observer for terminal boundary, real frames/input and one timing pair.');
