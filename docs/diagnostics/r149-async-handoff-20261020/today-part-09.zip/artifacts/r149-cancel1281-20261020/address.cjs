const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,save=(n,j)=>fs.writeFileSync(path.join(dir,n),JSON.stringify(j,null,2),{flag:'wx'});
const kinds=['program','shader','texture','framebuffer','renderbuffer','buffer','vertexArray'];
const balanced=s=>kinds.every(k=>!s.byKind[k]?.unrequested&&!s.byKind[k]?.duplicateDeletes);
const quiet=s=>!s.pending&&!s.pollTimers&&!s.pagehideActive&&!s.boundaryListeners&&!s.postDispose.length&&!s.staleUses.length;
async function normal(page){
 await page.waitForFunction(()=>__lc.completedMainFrames>=2,null,{timeout:60000,polling:100});
 await page.evaluate(()=>{document.getElementById('startBtn').addEventListener('click',e=>__lc.clickTrusted=e.isTrusted,{once:true});document.addEventListener('keydown',e=>{if(e.code==='KeyW')__lc.keyTrusted=e.isTrusted;},{once:true});});
 const initial=await page.evaluate(()=>({...__lc.state.player}));await page.locator('#startBtn').click();await page.keyboard.down('w');
 try{await page.waitForFunction(p=>__lc.state.player.speed>0&&Math.hypot(__lc.state.player.x-p.x,__lc.state.player.z-p.z)>0.1,initial,{timeout:10000,polling:50});}finally{await page.keyboard.up('w');}
 const running=await page.evaluate(()=>({snapshot:__lc.snapshot(),components:__lc.components(),quality:__lc.ports.graphics.quality,player:{...__lc.state.player},trusted:[__lc.clickTrusted,__lc.keyTrusted],window:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},navigation:performance.getEntriesByType('navigation')[0].type}));
 const after=await page.evaluate(()=>{__lc.close();return __lc.snapshot();});
 if(!balanced(after)||!quiet(after)||after.glError||!after.checks||running.quality!=='high'||running.trusted.some(x=>!x)||!running.components.environment.valid||running.components.quarter.some(x=>!x.valid)||!running.components.water.texture?.valid||running.components.shadows.some(x=>!x.map.valid))throw Error('Normal High/input/cleanup regression');
 return{initial,running,after};
}
async function run(label,mode,html){
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles',label),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 let page;const errors=[],messages=[],navigations=[];
 try{
  page=context.pages()[0];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(['error','warning'].includes(m.type()))messages.push({type:m.type(),text:m.text()});});page.on('framenavigated',f=>{if(f===page.mainFrame())navigations.push(f.url());});
  const cdp=await context.newCDPSession(page),browser=await context.browser().newBrowserCDPSession(),{targetInfo}=await cdp.send('Target.getTargetInfo'),win=await browser.send('Browser.getWindowForTarget',{targetId:targetInfo.targetId});await browser.send('Browser.setWindowBounds',{windowId:win.windowId,bounds:{windowState:'maximized'}});await page.bringToFront();
  const observer=fs.readFileSync(path.join(dir,'observe.js'),'utf8');
  await page.addInitScript({content:`(()=>{let mode=${JSON.stringify(mode)};if(['E','L'].includes(mode)){const key='tbs.test.context-boundary.'+mode;if(sessionStorage.getItem(key))mode='N';else sessionStorage.setItem(key,'1');}(${observer})(mode);})();`});
  await page.goto(pathToFileURL({"A":"C:\\Users\\s.nikushkin\\Documents\\tbs-togliatti\\index.html","B":"C:\\Users\\s.nikushkin\\Documents\\tbs-togliatti\\artifacts\\r149-context-boundary-20261020\\index-before.html","Safe":"C:\\Users\\s.nikushkin\\Documents\\tbs-togliatti\\artifacts\\r149-context-boundary-20261020\\index-safe.html"}[html]).href,{waitUntil:'load',timeout:180000});
  let result;
  if(mode==='N')result=await normal(page);
  else{
   await page.waitForFunction(()=>__lc.disposeCalls>0&&__lc.pending===0,null,{timeout:60000,polling:100});
   const failed=await page.evaluate(()=>({snapshot:__lc.snapshot(),copy:document.getElementById('overlayCopy').textContent,overlayVisible:!document.getElementById('overlay').classList.contains('hidden'),startDisabled:document.getElementById('startBtn').disabled}));
   if(!quiet(failed.snapshot)||!failed.snapshot.checks||failed.snapshot.completedMainFrames)throw Error('Failure did not stop cleanly');
   if(mode==='B'){
    if(!balanced(failed.snapshot)||!failed.snapshot.reason?.sameAbort||failed.snapshot.glError)throw Error('Ordinary cancellation regression');
    result={failed};
   }else{
    if(!failed.snapshot.signalAborted||!failed.snapshot.boundaryErrorReported||!failed.copy.includes('F5')||!failed.overlayVisible||!failed.startDisabled||!failed.snapshot.contextLost)throw Error('Context failure boundary not established');
    const restored=await page.evaluate(async()=>{
     const d=__lc,canvas=d.renderer.domElement;
     await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Native restore timeout')),5000);canvas.addEventListener('webglcontextrestored',()=>{clearTimeout(timer);resolve();},{once:true});d.loseExtension.restoreContext();});
     d.close();return d.snapshot();
    });
    await page.locator('#startBtn').scrollIntoViewIfNeeded();const b=await page.locator('#startBtn').boundingBox();if(b)await page.mouse.click(b.x+b.width/2,b.y+b.height/2);await page.keyboard.down('w');await page.waitForTimeout(100);await page.keyboard.up('w');
    const afterInput=await page.evaluate(()=>__lc.snapshot());
    if(restored.glError||!quiet(afterInput)||afterInput.glError||afterInput.completedMainFrames||!afterInput.signalAborted||afterInput.objects.some(x=>x.deletes>1))throw Error('Stale generation resumed or post-restore cleanup failed');
    // Explicit test-controller reload models the user's F5, not application reload.
    await page.screenshot({path:path.join(dir,label+'-restart-notice.png')});
    await page.reload({waitUntil:'load',timeout:180000});const restarted=await normal(page);
    if(restarted.running.navigation!=='reload'||navigations.length!==2)throw Error('Expected exactly one explicit restart');
    result={failed,restored,afterInput,restarted};
   }
  }
  if(errors.length)throw Error('Unexpected page errors '+errors.join('\n'));
  const j={label,mode,html,browser:context.browser().version(),result,errors,messages,navigations};save(label+'.json',j);
  console.log(JSON.stringify({label,mode,passed:true,failure:result.failed&&{settled:result.failed.snapshot.settled,reason:result.failed.snapshot.signalReason,context:result.failed.snapshot.contextLost,signal:result.failed.snapshot.signalAborted,frames:result.failed.snapshot.completedMainFrames},restoredGL:result.restored?.glError,restarted:!!result.restarted,normalCounts:(result.after||result.restarted?.after)?.byKind,timing:result.running&&{firstMainMs:result.running.snapshot.firstFullAt,controlMs:result.running.snapshot.controlAt},errors:errors.length}));
 }catch(error){let snapshot;try{snapshot=await page.evaluate(()=>__lc?.snapshot());}catch{}save(label+'-failure.json',{error:error.stack,snapshot,errors,messages,navigations});throw error;}
 finally{await context.close();}
}
(async()=>{for(const [label,mode,html]of [['address-cancel','B','Safe']])await run(label,mode,html);})().catch(e=>{console.error(e.stack);process.exitCode=1;});
