// External lifecycle observer. Forward native arguments/results; no shader/RNG changes.
scenario=>{
 const d=window.__lc={scenario,phase:'building',events:[],pending:0,settled:null,mainFrames:0,disposeCalls:0,graphicsDisposeCalls:0,pagehideActive:0,timers:new Set(),statusCalls:0,postDispose:[],objects:[],contextLost:false,restored:false,triggered:false,epoch:0,draws:0,completedMainFrames:0,staleUses:[],glErrors:[],extensionRequests:[],raf:new Set()};
 const ids=new WeakMap(),contexts=new Set();let next=0;
 const event=(name,data={})=>d.events.push({name,t:performance.now(),...data});
 d.operations=[];d.programLifecycle=[];d.active=[];d.abortArmed=false;
 const nativeErrorFns=new Map([WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype].map(p=>[p,p.getError]));
 d.describe=h=>{const row=h&&typeof h==='object'&&ids.get(h);return row?{id:row.id,kind:row.kind,epoch:row.epoch,deletes:row.deletes,shaders:row.shaders}:typeof h==='number'?h:h===null?null:typeof h;};
 d.owners=h=>d.renderer?.info.programs.filter(p=>p.program===h).map(p=>({id:p.id,usedTimes:p.usedTimes,name:p.name}))||[];
 const createKinds={createProgram:'program',createShader:'shader',createTexture:'texture',createBuffer:'buffer',createFramebuffer:'framebuffer',createRenderbuffer:'renderbuffer',createVertexArray:'vertexArray',fenceSync:'sync'};
 const deleteKinds={deleteProgram:'program',deleteShader:'shader',deleteTexture:'texture',deleteBuffer:'buffer',deleteFramebuffer:'framebuffer',deleteRenderbuffer:'renderbuffer',deleteVertexArray:'vertexArray',deleteSync:'sync'};
 const nativeError=console.error;console.error=function(...a){if(a[0]===d.injectedError)d.originalErrorReported=true;return Reflect.apply(nativeError,this,a);};
 for(const proto of [WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype])for(const name of [...Object.keys(createKinds),...Object.keys(deleteKinds),'getError','shaderSource','attachShader','bindTexture','getSupportedExtensions','getExtension','getProgramParameter','useProgram','drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced']){
  const fn=proto[name];if(!fn||fn.__lifecycle)continue;
  const wrapped=function(...a){
   contexts.add(this);
   if(name==='getExtension'&&a[0]==='KHR_parallel_shader_compile'&&scenario==='D'){d.extensionHidden=true;d.extensionRequests.push({phase:d.phase,epoch:d.epoch,result:null});return null;}
   if(d.disposeCalls&&!d.reading&&['getProgramParameter','useProgram','drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced'].includes(name))d.postDispose.push({name,t:performance.now(),phase:d.phase});
   if(name==='bindTexture'&&a[1]){const old=ids.get(a[1]);if(old?.deletes)d.postDispose.push({name:'bind-deleted-texture',id:old.id});}
   if(name==='getSupportedExtensions'&&scenario==='D')return Reflect.apply(fn,this,a)?.filter(x=>x!=='KHR_parallel_shader_compile');
   if(name==='shaderSource'&&scenario==='F'&&d.phase==='preparing'&&!d.badShader&&this.getShaderParameter(a[0],this.SHADER_TYPE)===this.FRAGMENT_SHADER){
    d.badShader=a[0];d.triggered=true;d.injectedSourceLength=a[1].length;event('inject-real-fragment-compile-error',{shader:ids.get(a[0])?.id});a[1]+='\n#error TBS_CONTROLLED_SHADER_FAILURE\n';
   }
   if(name==='attachShader'){const row=ids.get(a[0]);if(row)(row.shaders||=[]).push(ids.get(a[1])?.id);}if(name==='attachShader'&&a[1]===d.badShader){d.badProgram=a[0];d.badProgramID=ids.get(a[0])?.id;}
   if(['useProgram','bindTexture'].includes(name)){const row=ids.get(a[name==='useProgram'?0:1]);if(row&&row.epoch!==d.epoch&&!this.isContextLost())d.staleUses.push({name,id:row.id,old:row.epoch,current:d.epoch});}
   if(name==='useProgram'&&a[0]===d.badProgram)d.badProgramUses=(d.badProgramUses||0)+1;
   const value=Reflect.apply(fn,this,a);
   if(name==='getExtension'&&a[0]==='WEBGL_lose_context'&&value)d.loseExtension=value;
   if(name==='getError'&&value)d.glErrors.push({value,phase:d.phase,epoch:d.epoch,lost:this.isContextLost()});
   if(name==='getProgramParameter'&&a[0]===d.badProgram&&a[1]===this.LINK_STATUS)d.badLinkStatus=value;
   if(name.startsWith('draw'))d.draws++;
   if(createKinds[name]&&value){const row={id:++next,kind:createKinds[name],phase:d.phase,created:performance.now(),deletes:0,epoch:d.epoch,handle:value,gl:this,stack:["framebuffer","texture"].includes(createKinds[name])?new Error().stack:undefined};ids.set(value,row);d.objects.push(row);}
   if(deleteKinds[name]&&a[0]){const row=ids.get(a[0]);if(row){row.deletes++;row.deleted=performance.now();}}
   if(name==='getProgramParameter'&&a[1]===0x91b1){
    d.statusCalls++;
    if(d.phase==='preparing'&&value===false&&!d.triggered&&['B','E'].includes(scenario)){
     d.triggered=true;event('native-program-not-ready',{program:ids.get(a[0])?.id});
     queueMicrotask(()=>{
      if(scenario==='B'){d.abortArmed=true;event('cancel-begin',{error:this.getError(),pending:d.pending,timers:d.timers.size,active:d.active.slice()});event('dispatch-pagehide');dispatchEvent(new PageTransitionEvent('pagehide'));}
      else{const ext=this.getExtension('WEBGL_lose_context');d.contextLossSupported=!!ext;if(ext){event('lose-context');ext.loseContext();}else event('context-loss-unavailable');}
     });
    }
   }
   return value;
  };wrapped.__lifecycle=true;proto[name]=wrapped;
 }
 const suspicious=['createProgram','createShader','attachShader','detachShader','linkProgram','getProgramParameter','getProgramInfoLog','getShaderParameter','getShaderInfoLog','getActiveUniform','getUniformLocation','getActiveAttrib','getAttribLocation','deleteProgram','deleteShader','useProgram'];
 for(const proto of [WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype])for(const name of suspicious){
  const fn=proto[name];if(typeof fn!=='function'||fn.__address1281)continue;
  const nativeGetError=nativeErrorFns.get(proto);
  const wrap=function(...args){
   const armed=d.abortArmed&&!d.reading,lost=this.isContextLost();
   const row={name,t:performance.now(),args:args.map(d.describe),owners:d.owners(args[0]),phase:d.phase,pending:d.pending,timers:d.timers.size,active:d.active.slice(),lost};
   if(armed&&!lost)row.errorBefore=Reflect.apply(nativeGetError,this,[]);
   let value;try{value=Reflect.apply(fn,this,args);return value;}finally{
    if(armed&&!this.isContextLost())row.errorAfter=Reflect.apply(nativeGetError,this,[]);
    if(typeof value==='boolean'||typeof value==='number'||value===null)row.result=value;
    if(armed||name==='deleteProgram'||name==='deleteShader'){row.stack=new Error().stack;d.operations.push(row);}
   }
  };wrap.__address1281=true;proto[name]=wrap;
 }
 const add=EventTarget.prototype.addEventListener,remove=EventTarget.prototype.removeEventListener,pagehide=new Set(),boundary=new Set();
 EventTarget.prototype.addEventListener=function(type,fn,...rest){if(type==='webglcontextlost'&&fn?.name==='onContextLoss')boundary.add(fn);if(this===window&&type==='pagehide'){pagehide.add(fn);d.pagehideActive=pagehide.size;}return Reflect.apply(add,this,[type,fn,...rest]);};
 EventTarget.prototype.removeEventListener=function(type,fn,...rest){if(type==='webglcontextlost'&&fn?.name==='onContextLoss')boundary.delete(fn);if(this===window&&type==='pagehide'){pagehide.delete(fn);d.pagehideActive=pagehide.size;}return Reflect.apply(remove,this,[type,fn,...rest]);};
 const timeout=setTimeout,clear=clearTimeout;window.setTimeout=function(fn,ms,...args){if(d.phase!=='preparing'||ms!==10)return timeout(fn,ms,...args);let id;id=timeout(function(...a){d.timers.delete(id);return Reflect.apply(fn,this,a);},ms,...args);d.timers.add(id);return id;};window.clearTimeout=function(id){d.timers.delete(id);return clear(id);};
 localStorage.setItem('tbs.graphicsQuality','high');let registry;
 Object.defineProperty(window,'TBS',{get:()=>registry,set(api){registry=api;for(const name of ['buildWorld','buildPresentation','createRuntime']){let fn;Object.defineProperty(api,name,{get:()=>fn,set(original){fn=function(...args){
  const result=Reflect.apply(original,this,args);
  if(name==='buildWorld'){
   d.world=result;const r=result.renderer;d.renderer=r;
   d.components=()=>{
    const gl=r.getContext(),tex=value=>{if(!value?.isTexture)return null;const h=r.properties.get(value).__webglTexture;return{uuid:value.uuid,native:ids.get(h)?.id,valid:!!h&&!gl.isContextLost()&&gl.isTexture(h),renderTarget:!!value.isRenderTargetTexture};};
    const paints=new Set(),shadows=[];
    result.scene.traverse(o=>{if(o.userData.paint?.envMap)paints.add(o.userData.paint.envMap);if(o.isLight&&o.shadow?.map)shadows.push({type:o.type,map:tex(o.shadow.map.texture)});});
    const water=result.scene.userData.waterMaterial?.userData.shader;
    return{environment:tex(result.scene.environment),paint:[...paints].map(tex),quarter:[...new Set((result.scene.userData.quarterLighting?.reflective||[]).map(m=>m.envMap).filter(Boolean))].map(tex),water:{texture:tex(water?.uniforms.waterReflection?.value),strength:water?.uniforms.reflectionStrength?.value,wave:water?.uniforms.waveTime?.value},shadows,fullMainFrames:d.completedMainFrames};
   };
   const canvas=r.domElement;canvas.addEventListener('webglcontextlost',()=>{d.epoch++;event('generation-lost',{epoch:d.epoch});},true);
   d.environmentBacking=()=>{const texture=result.scene.environment,handle=r.properties.get(texture).__webglTexture;return{texture:texture?.uuid,native:ids.get(handle)?.id,valid:!!handle&&!r.getContext().isContextLost()&&r.getContext().isTexture(handle)};};
   d.environmentBefore=d.environmentBacking();
   d.pmrem=[];d.pmremOutputs=new Map();
   r.__pmremRecord=(source,target,branch)=>{
    let row=d.pmremOutputs.get(target);
    if(!row){
     const prop=r.properties.get(target),tex=r.properties.get(target.texture);
     row={source:source.uuid,target:target.uuid,output:target.texture.uuid,width:target.width,height:target.height,branches:{},disposeEvents:0,sourceDispose:0,
      framebuffer:d.objects.find(x=>x.handle===prop.__webglFramebuffer)?.id,texture:d.objects.find(x=>x.handle===tex.__webglTexture)?.id};
     d.pmremOutputs.set(target,row);d.pmrem.push(row);
     target.addEventListener('dispose',()=>{row.disposeEvents++;row.disposedAt=performance.now();});
     source.addEventListener('dispose',()=>row.sourceDispose++);
    }
    row.branches[branch]=(row.branches[branch]||0)+1;
    if(row.disposeEvents)d.events.push({name:'USE-AFTER-PMREM-DISPOSE',target:target.uuid});
    const sources=r.__pmremSources?.();if(sources)for(const [owner,input]of Object.entries(sources))if(input?.texture===source){row.owner=owner;row.inputTarget=input.uuid;}
   };
   r.domElement.addEventListener('webglcontextlost',()=>{d.contextLost=true;event('context-lost-event');});r.domElement.addEventListener('webglcontextrestored',()=>{d.restored=true;event('context-restored-event');});
   const dispose=r.dispose;r.dispose=function(){event('renderer-dispose');d.disposeCalls++;return Reflect.apply(dispose,this,arguments);};
   const render=r.render;r.render=function(scene,camera){const before=d.draws,lost=r.getContext().isContextLost();const v=Reflect.apply(render,this,arguments);if(scene===result.scene){d.mainFrames++;if(!lost&&d.draws>before){d.completedMainFrames++;d.firstFullAt??=performance.now();if(d.state&&d.state.player.speed>0&&Math.hypot(d.state.player.x-d.startPlayer.x,d.state.player.z-d.startPlayer.z)>0.01)d.controlAt??=performance.now();}}return v;};
   if(scenario==='C'){const compile=r.compile;r.compile=function(){const value=Reflect.apply(compile,this,arguments);if(!d.injectedError){d.injectedError=new Error('Controlled lifecycle initialization failure');event('inject-initialization-error');throw d.injectedError;}return value;};}
   const compile=r.compile;r.compile=function(){const value=Reflect.apply(compile,this,arguments);for(const p of r.info.programs){if(p.__addressWrapped)continue;p.__addressWrapped=true;for(const method of ['isReady','getUniforms','getAttributes','destroy']){const fn=p[method];p[method]=function(){const entry={method,t:performance.now(),id:p.id,native:d.describe(p.program),usedTimes:p.usedTimes,pending:d.pending,timers:d.timers.size,phase:d.phase};d.programLifecycle.push(entry);d.active.push({method,id:p.id});try{return Reflect.apply(fn,this,arguments);}finally{d.active.pop();entry.end=performance.now();}};}}return value;};
   const prep=r.compileAsyncPasses;if(prep)r.compileAsyncPasses=async function(passes,options){
    d.close=r.__startupClose;d.pending++;d.phase='preparing';d.beforePrograms=r.info.programs.length;d.signal=options.signal;event('prepare-start');
    try{const v=await Reflect.apply(prep,this,arguments);
     d.preparedEpoch=d.epoch;d.preparedNativeIDs=r.info.programs.map(p=>ids.get(p.program)?.id);
     if(scenario==='L'){
      const ext=r.getContext().getExtension('WEBGL_lose_context');if(!ext)throw Error('WEBGL_lose_context unavailable');
      const lost=new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Lost-event timeout')),5000);r.domElement.addEventListener('webglcontextlost',()=>{clearTimeout(timer);resolve();},{once:true});});
      event('lose-after-real-preparation',{reflected:v.reflected,programs:d.preparedNativeIDs.length});ext.loseContext();await lost;
      event('return-real-prepared-result',{lost:r.getContext().isContextLost(),preparedEpoch:d.preparedEpoch,currentEpoch:d.epoch});
     }
     d.settled='fulfilled';event('prepare-fulfilled');return v;}
    catch(e){d.preparationError=e;d.settled='rejected';d.reason={name:e?.name,message:e?.message,sameInjected:e===d.injectedError,sameAbort:e===options.signal.reason};event('prepare-rejected',d.reason);throw e;}
    finally{d.pending--;d.phase='after-preparation';}
   };
  }
  if(name==='buildPresentation'){d.state=args[0].state;d.startPlayer={...d.state.player};d.ports=result;const dispose=result.graphics.dispose;const tracked=function(){d.graphicsDisposeCalls++;return Reflect.apply(dispose,this,arguments);};result.graphics.dispose=tracked;d.renderer.__startupDispose=tracked;}
  if(name==='createRuntime'){d.runtime=result;d.game=args[0].game;}
  return result;
 };}});}}});
 const request=requestAnimationFrame,cancel=cancelAnimationFrame;
 window.requestAnimationFrame=function(fn){let id;id=request(t=>{d.raf.delete(id);fn(t);});d.raf.add(id);return id;};window.cancelAnimationFrame=function(id){d.raf.delete(id);return cancel(id);};
 const report=console.error;console.error=function(...args){if(args[0]===d.preparationError)d.errorReported=true;if(d.signal?.aborted&&args[0]===d.signal.reason)d.boundaryErrorReported=true;return Reflect.apply(report,this,args);};
 d.snapshot=()=>{
  d.reading=true;
  try{
   const byKind={};for(const row of d.objects){const c=byKind[row.kind]||={created:0,deleteCalls:0,duplicateDeletes:0,unrequested:0,nativeLive:0};c.created++;c.deleteCalls+=row.deletes;c.duplicateDeletes+=Math.max(0,row.deletes-1);c.unrequested+=row.deletes===0;}
   const r=d.renderer,g=r.getContext(),ext=g.getExtension('WEBGL_debug_renderer_info');
   return{scenario,operations:d.operations,programLifecycle:d.programLifecycle,active:d.active,signalAborted:!!d.signal?.aborted,signalReason:d.signal?.reason?.message,boundaryErrorReported:!!d.boundaryErrorReported,boundaryListeners:boundary.size,firstFullAt:d.firstFullAt,controlAt:d.controlAt,epoch:d.epoch,preparedEpoch:d.preparedEpoch,preparedNativeIDs:d.preparedNativeIDs,completedMainFrames:d.completedMainFrames,draws:d.draws,staleUses:d.staleUses,glErrors:d.glErrors,rafActive:d.raf.size,extensionRequests:d.extensionRequests,badProgramID:d.badProgramID,badLinkStatus:d.badLinkStatus,badProgramUses:d.badProgramUses||0,errorReported:!!d.errorReported,environmentBefore:d.environmentBefore,environmentNow:undefined,pmrem:d.pmrem,phase:d.phase,pending:d.pending,settled:d.settled,reason:d.reason,originalErrorReported:!!d.originalErrorReported,mainFrames:d.mainFrames,disposeCalls:d.disposeCalls,graphicsDisposeCalls:d.graphicsDisposeCalls,pagehideActive:d.pagehideActive,pollTimers:d.timers.size,statusCalls:d.statusCalls,postDispose:d.postDispose,contextLost:d.contextLost,restored:d.restored,contextLossSupported:d.contextLossSupported,extensionHidden:d.extensionHidden,triggered:d.triggered,events:d.events,stats:r.__asyncStats,rendererPrograms:r.info.programs.map(p=>({id:p.id,name:p.name,usedTimes:p.usedTimes,live:undefined})),memory:{...r.info.memory},byKind,checks:r.debug.checkShaderErrors,lost:g.isContextLost(),glError:g.getError(),GPU:ext&&!g.isContextLost()?g.getParameter(ext.UNMASKED_RENDERER_WEBGL):null,objects:d.objects.map(x=>({id:x.id,kind:x.kind,phase:x.phase,epoch:x.epoch,deletes:x.deletes,stack:x.stack})),note:'Strong diagnostic handle references verify explicit cleanup; GL validity is not a driver-memory measurement. Context invalidation is separate from delete calls.'};
  }finally{d.reading=false;}
 };
}
