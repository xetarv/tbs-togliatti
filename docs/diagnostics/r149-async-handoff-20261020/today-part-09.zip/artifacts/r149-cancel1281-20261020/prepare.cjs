const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=__dirname,root=path.resolve(dir,'../..'),prior=path.join(root,'artifacts/r149-final-comparison-20261020'),boundary=path.join(root,'artifacts/r149-context-boundary-20261020');
const put=(n,s)=>fs.writeFileSync(path.join(dir,n),s,{flag:'wx'});
const preserved=JSON.parse(fs.readFileSync(path.join(prior,'preserved-before.json')));
for(const row of preserved.files){const bytes=fs.readFileSync(path.join(root,row.path));row.sha256=crypto.createHash('sha256').update(bytes).digest('hex');}
put('preserved-before.json',JSON.stringify(preserved,null,2));
let observer=fs.readFileSync(path.join(boundary,'observe-b.js'),'utf8');
observer=observer.replace(/const test=\{program:'isProgram'[\s\S]*?c\.nativeLive\+\+;/,'');
observer=observer.replace('environmentNow:d.environmentBacking()','environmentNow:undefined').replace('live:!!p.program&&!g.isContextLost()&&g.isProgram(p.program)','live:undefined');
observer=observer.replace(' const createKinds=',` d.operations=[];d.programLifecycle=[];d.active=[];d.abortArmed=false;
 const nativeErrorFns=new Map([WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype].map(p=>[p,p.getError]));
 d.describe=h=>{const row=h&&typeof h==='object'&&ids.get(h);return row?{id:row.id,kind:row.kind,epoch:row.epoch,deletes:row.deletes,shaders:row.shaders}:typeof h==='number'?h:h===null?null:typeof h;};
 d.owners=h=>d.renderer?.info.programs.filter(p=>p.program===h).map(p=>({id:p.id,usedTimes:p.usedTimes,name:p.name}))||[];
 const createKinds=`);
observer=observer.replace("if(name==='attachShader'&&a[1]===d.badShader)","if(name==='attachShader'){const row=ids.get(a[0]);if(row)(row.shaders||=[]).push(ids.get(a[1])?.id);}if(name==='attachShader'&&a[1]===d.badShader)");
observer=observer.replace("event('dispatch-pagehide');dispatchEvent",`d.abortArmed=true;event('cancel-begin',{error:this.getError(),pending:d.pending,timers:d.timers.size,active:d.active.slice()});event('dispatch-pagehide');dispatchEvent`);
const marker=' const add=EventTarget.prototype.addEventListener';
observer=observer.replace(marker,` const suspicious=['createProgram','createShader','attachShader','detachShader','linkProgram','getProgramParameter','getProgramInfoLog','getShaderParameter','getShaderInfoLog','getActiveUniform','getUniformLocation','getActiveAttrib','getAttribLocation','deleteProgram','deleteShader','useProgram'];
 for(const proto of [WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype])for(const name of suspicious){
  const fn=proto[name];if(typeof fn!=='function'||fn.__address1281)continue;
  const nativeGetError=nativeErrorFns.get(proto);
  const wrap=function(...args){
   const armed=d.abortArmed&&!d.reading,lost=this.isContextLost();
   const row={name,t:performance.now(),args:args.map(d.describe),owners:d.owners(args[0]),phase:d.phase,pending:d.pending,timers:d.timers.size,active:d.active.slice(),lost};
   if(armed&&!lost)row.errorBefore=Reflect.apply(nativeGetError,this,[]);
   let value;try{value=Reflect.apply(fn,this,args);return value;}finally{
    if(armed&&!this.isContextLost())row.errorAfter=Reflect.apply(nativeGetError,this,[]);
    if(typeof value==='boolean'||typeof value==='number'||value===null)row.result=value;
    if(armed||name==='deleteProgram'||name==='deleteShader'){row.stack=new Error().stack;d.operations.push(row);}
   }
  };wrap.__address1281=true;proto[name]=wrap;
 }
`+marker);
observer=observer.replace('const prep=r.compileAsyncPasses;if(prep)',`const compile=r.compile;r.compile=function(){const value=Reflect.apply(compile,this,arguments);for(const p of r.info.programs){if(p.__addressWrapped)continue;p.__addressWrapped=true;for(const method of ['isReady','getUniforms','getAttributes','destroy']){const fn=p[method];p[method]=function(){const entry={method,t:performance.now(),id:p.id,native:d.describe(p.program),usedTimes:p.usedTimes,pending:d.pending,timers:d.timers.size,phase:d.phase};d.programLifecycle.push(entry);d.active.push({method,id:p.id});try{return Reflect.apply(fn,this,arguments);}finally{d.active.pop();entry.end=performance.now();}};}}return value;};
   const prep=r.compileAsyncPasses;if(prep)`);
observer=observer.replace('return{scenario,signalAborted','return{scenario,operations:d.operations,programLifecycle:d.programLifecycle,active:d.active,signalAborted');
put('observe.js',observer);
let runner=fs.readFileSync(path.join(prior,'check.cjs'),'utf8');
runner=runner.replace("||failed.snapshot.operationErrors.length||failed.snapshot.events.some(e=>e.name==='cancel-entry-error'&&e.code)","");
const start=runner.indexOf("(process.argv[2]==='cancel'?");const end=runner.indexOf('))await run(label,mode,html)',start);
if(start<0||end<0)throw Error('Runner anchor missing');
runner=runner.slice(0,start)+"[['address-cancel','B','Safe']]"+runner.slice(end+1);
put('address.cjs',runner);
console.log('Prepared one address cancellation run; original variants unchanged.');
