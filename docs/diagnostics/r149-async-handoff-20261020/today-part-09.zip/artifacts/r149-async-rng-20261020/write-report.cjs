const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');const dir=__dirname,root=path.resolve(dir,'../..'),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n))),s=read('summary-2.json'),cause=read('rng-cause.json'),correct=read('correctness.json');
const sec=x=>(x/1000).toFixed(3),g=(kind,mode,key)=>sec(s.groups[kind][mode][key].median);
let text=`# B++: отложенное создание индивидуальных depth-материалов

HEAD/main: 5cbd6f741415bf10d44b2a6088b9bc26e1916d50. Только изолированный эксперимент; production не одобрена.

**Итог:** причина RNG устранена; B++ сохранён как кандидат для отдельного ревью. В двух парах существенной потери warm-скорости нет: B+ 4,384 с, B++ 4,192 с по медианам. Для нового профиля полное время неоднозначно: 8,472 → 8,683 с; парные изменения +0,431 и −0,010 с, включая позднее наблюдение меню в первом B++. Поэтому точная эквивалентность полного нового запуска не доказана. Новых задержек после W и ошибок не выявлено. Production-приёмка не выполнена.

## 1. Причина RNG доказана

Внешняя адресная проверка B и B+ записала все стеки RNG внутри depth material clone. B: **0** таких клонов на первом кадре, B+: **3**, каждый вызывает generateUUID четыре раза. Полная разница **12** вызовов: индексы 175605–175616 в детерминированной проверке. Все три созданы на стадии подготовки, не реального первого shadow draw.

Call chain: prepareDepthMaterials → getDepthMaterial (minified _) → MeshDepthMaterial.clone → new MeshDepthMaterial (zs) → Material (Mi) → MathUtils.generateUUID (bt) → Math.random. Четыре точных call sites bt в observed-P-fixed.js: **6:2798, 6:2827, 6:2856, 6:2885**; каждый встречается трижды. Все 12 полных стеков и UUID исходных/созданных материалов — rng-cause.json. Исходная UUID-функция сверена с оригинальным assets/three.min.js и не менялась.

Исходные материалы — три cityLeafMaterials из src/adapters/world/resources/landscape.ts:44–54: MeshStandardMaterial, общий cityLeafTexture, alphaTest=0.42, DoubleSide. Стандартный getDepthMaterial сохраняет индивидуальный clone для материала с map+alphaTest, чтобы его uniforms не конфликтовали при реальном рендеринге. Консервативный B+ обходит больше shadow casters, чем фактически попадает в первый shadow frustum, поэтому заранее создаёт эти clones.

Три лишних **shader programs** и три **material clones** — не взаимно однозначное соответствие. По cache-key boolean masks один лишний shader — instancing/map/alphaTest/DoubleSide; два других — instancingColor/DoubleSide и instancing/map/vertexUV/FlipSide. У всех трёх зарегистрированных clones один тип cutout-параметров. Общее происхождение — широкий обход кастеров, но равенство количества не доказывает связь «один clone — один program». Для семи реально используемых новых вариантов индивидуальные clones не нужны: реальный первый shadow draw их не создаёт, а B++ сохраняет все program keys и их использование без ранних clones.

## 2. Влияет ли это на игру

Это тот же глобальный Math.random, а не отдельный генератор renderer. Адресный поиск по production TS: прямые Math.random находятся в audio/sound.ts:30 и audio/ambience.ts:9–10; в текущей domain/application симуляции таких обращений нет. Геометрия/трафик/состояние в проверенной последовательности не изменялись, но B+ сдвигал общий поток, используемый последующими звуковыми noise buffers. В детерминированном тесте контрольные семплы B+ отличаются от B. Поэтому нельзя считать все 12 вызовов исключительно безвредной особенностью счётчика диагностики; утверждать изменение физики/распределения транспорта также оснований нет.

Stack observer и фиксированный RNG использованы **только во внешней проверке**, не в candidate или измерениях скорости. После подготовки seed не сбрасывался и не восстанавливался.

## 3. Одно исправление B++

Четыре текстовых замены одного механизма в диагностической копии engine:

- getDepthMaterial получает необязательный частный prepare-only флаг.
- При подготовке selector копирует те же параметры на уже существующий частный depth/distance material, не создавая и не регистрируя индивидуальные clones.
- getProgram получает те же параметры/объекты и работает с тем же штатным program cache.
- Реальные shadow draw не передают флаг: исходное создание индивидуальных clones остаётся отложенным до реальной необходимости.

Программы не удаляются. Чужие игровые materials/objects не меняются ради подготовки. Нет подмены RNG, reset seed, модификации generateUUID, искусственных/повторных UUID или отдельного program cache. Shader source, polling, настройки High, отражения и исправление воды не менялись. Baseline B+ сохранён побитово, engine-patch.json воспроизводится точно (patch-verification.json).

## 4. Корректность и будущая последовательность

Четыре независимых fixed-step оконных запуска: B+1 / B++ / исходный B / B+2. Первый кадр, реальный Start/KeyW, движение и ночь, всего 361 шаг. Дополнительно 12 последовательных checkpoints через каждые 30 шагов: полный GameState, traffic и состояние диагностического RNG; сняты контрольные первые 64 семпла обоих созданных audio buffers. Это отдельная проверка последовательности, а не вывод из сходства картинок.

| Контроль | Результат |
| --- | --- |
| B++ RNG после первого кадра | 175932 calls, seed 640593761 — ровно исходный B |
| B+ RNG после первого кадра | 175944 calls, seed 598774893 |
| B++/B checkpoints, включая RNG | Все 12 совпали |
| B++/B+ checkpoints игры/traffic | Все 12 совпали; RNG в B+ смещён на 12 |
| B++/B контрольные audio samples | Совпали в обоих buffers |
| B++/B+ контрольные audio samples | Различаются, как ожидается после устранения сдвига |
| Подготовлено / использовано из batch | 76 / 60 — без изменения |
| Использовано всего / создано всего / поздних | 73 / 89 / 10 — без изменения |
| Полный набор cache keys B+/B++ | Совпал |
| Checks / LINK_STATUS / logs / GL errors | Включены / успешны / пусты / 0 |

B++ побитово совпал с независимым **B+2** на первом кадре, движении и ночью. Вода и reflection-strength совпали. Контроль **B+1/B+2** воспроизвёл известные 13318 pixels / max channel Δ3 только при движении; B+1/B++ имеет ту же величину, B+1/исходный B отличается на 6 pixels / maxΔ2. Первый/ночь совпали у всех. Старый strict pixel harness поэтому вернул отрицательный gate; он сохранён. Отдельное diagnostic admission основано на прямом совпадении B++/B+2 и независимом контрольном расхождении, а не на молчаливом ослаблении production-критерия. PNG/RGBA/readPixels после finish проверены. Никакой новой существенной разницы B++ не установлено.

Вывод ограничен проверенной сценой и последовательностью; все будущие игровые состояния/варианты customDepthMaterial этим не покрыты.

## 5. Короткая проверка скорости

Использована прежняя оснастка без Math.random/clone observer. Оконный Edge ${s.runs[0].browser}, High, file://, RTX 3050 Laptop через ANGLE/D3D11, CSS 1528×694, DPR1.25, framebuffer1910×867. Первая пара B+→B++, вторая B++→B+. В каждом варианте новый собственный профиль и затем перезапуск того же профиля. Новый профиль не означает холодный системный/драйверный GPU cache.

| Профиль | Пара | До W B+, с | До W B++, с | B++−B+, с |
| --- | ---: | ---: | ---: | ---: |
`;
for(const kind of ['fresh','warm']){
 for(let cycle=1;cycle<=2;cycle++){const p=s.runs.find(r=>r.cycle===cycle&&r.kind===kind&&r.mode==='P').stats,q=s.runs.find(r=>r.cycle===cycle&&r.kind===kind&&r.mode==='Q').stats;text+=`| ${kind==='fresh'?'Новый':'Повторный'} | ${cycle} | ${sec(p.control)} | ${sec(q.control)} | ${sec(q.control-p.control)} |\n`;}
 text+=`| ${kind==='fresh'?'Новый':'Повторный'} | **Медиана** | **${g(kind,'P','control')}** | **${g(kind,'Q','control')}** | **${sec(s.paired[kind].control.median)}** |\n`;
}
text+=`
| Медиана, с | Новый B+ | Новый B++ | Повторный B+ | Повторный B++ |
| --- | ---: | ---: | ---: | ---: |
`;
for(const [label,key]of [['Start → W','startToControl'],['Подготовка всего','prep'],['Отправка программ','submit'],['KHR ready wait','wait'],['Uniform/attribute reflection','reflection'],['Длительность первого render','firstRender'],['Конец первого render','firstRenderEnd'],['Подтверждение GPU-ready','GPU'],['Видимое меню в screencast','menuVisible'],['Обработан ранний wheel','earlyInput']])text+=`| ${label} | `+['fresh','warm'].flatMap(k=>['P','Q'].map(m=>g(k,m,key))).join(' | ')+' |\n';
text+=`
Первая пара оказалась неоднозначной: B++ fresh до W +0,431 с, хотя конец render −0,137 с и fence −0,298 с; меню впервые попало в screencast лишь на 5,025 с против B+ 0,490 с. Реальная доставка wheel/Start оказалась позже. Этот неблагоприятный результат **не исключался**, поэтому проведена разрешённая вторая обратная пара; третьих/полных A/B/C не было. DOM/видимость/ввод не приравнивались. Времена фиксированных визуальных шагов не использовались для performance.

Все runs: те же 76 подготовленных/60 использованных из batch, 10 поздних; ошибок нет. После W за 10 секунд новых linkProgram=0 и зарегистрированных GL calls ≥5мс=0. Максимальный game.step B++: ${Math.max(...s.runs.filter(r=>r.mode==='Q').map(r=>r.stats.maxStep)).toFixed(1)} мс; B+: ${Math.max(...s.runs.filter(r=>r.mode==='P').map(r=>r.stats.maxStep)).toFixed(1)} мс. Многосекундных новых задержек после управления не зарегистрировано.

Измерения инструментированы: полный overhead trace/screencast/wrappers не известен и не вычитался. Host PNG processing влияет на момент ввода. GPU-ready — наблюдение fence через RAF, не точный аппаратный timestamp. N=2 не доказывает точное равенство скоростей; результаты сравниваются только с современным B+, исторические 5,171/4,216 с не являются новой контрольной парой.

## 6. Сохранность и ограничения

Совпали все ${Object.keys(s.preserved).length} выбранных SHA-256 production/локальных shaderChecks/оригинальной Three/B+/исторических файлов. Новые материалы только в этом каталоге. В первом stack-observer была исправлена ошибка метаданных (UUID локально затенял object); ошибочный P-run прерван, не использован. Успешный B сохранён, повторён только P с исправленным наблюдателем; см. observer-correction.json. Это не изменение оптимизационного кандидата.

B+ и историческая диагностика не перезаписаны. HEAD/main прежние. Git: три прежних M (scene.ts, dist scene.js, rendering-contracts.d.ts) и прежний ?? tests/shader-checks.test.cjs; индекс пуст. Production не менялся, поэтому общий build/check не запускался. git diff --check успешен. Commit/push не выполнялись.

Три лишних GPU-варианта и 10 поздних программ остаются. Отмена, очистка, fallback без KHR и полноценная production-приёмка изображения/раннего ввода остаются отдельными незавершёнными проверками. Самостоятельной интеграции нет.
`;
fs.writeFileSync(path.join(dir,'report.md'),text,{flag:'wx',encoding:'utf8'});
const names=['three-r149-async-plus.min.js','three-r149-async-plusplus.min.js','engine-patch.json','graphics-experimental.js','app-experimental.js','probe.js','menu-probe-final.js','program-observer.js','verify-visual.cjs','run-pq.cjs'];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');fs.writeFileSync(path.join(dir,'provenance.json'),JSON.stringify({head:'5cbd6f741415bf10d44b2a6088b9bc26e1916d50',candidateCount:1,measuredRuns:8,visualRuns:4,observerRuns:'B successful; P first observer metadata failure excluded; P corrected successful',hashes:Object.fromEntries(names.map(n=>[n,sha(fs.readFileSync(path.join(dir,n)))])),productionChanged:false},null,2),{flag:'wx'});console.log('Report/provenance generated from completed results.');
