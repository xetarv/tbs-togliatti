const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,save=(n,j)=>fs.writeFileSync(path.join(dir,n),JSON.stringify(j,null,2),{flag:'wx'});
const names={F:'shader-error',D:'no-khr',E:'loss-pending',L:'loss-after-ready'};
async function input(page){
 const enabled=await page.locator('#startBtn').isEnabled();
 const before=await page.evaluate(()=>({player:{...__lc.state.player},frames:__lc.completedMainFrames,draws:__lc.draws}));
 if(enabled){
  await page.evaluate(()=>{document.getElementById('startBtn').addEventListener('click',e=>__lc.clickTrusted=e.isTrusted,{once:true});document.addEventListener('keydown',e=>{if(e.code==='KeyW')__lc.keyTrusted=e.isTrusted;},{once:true});});
  await page.locator('#startBtn').click();await page.keyboard.down('w');
  try{await page.waitForFunction(p=>__lc.state.player.speed>0&&Math.hypot(__lc.state.player.x-p.x,__lc.state.player.z-p.z)>0.1,before.player,{timeout:8000});}
  finally{await page.keyboard.up('w');}
 }else{
  await page.locator('#startBtn').scrollIntoViewIfNeeded();const b=await page.locator('#startBtn').boundingBox();if(b)await page.mouse.click(b.x+b.width/2,b.y+b.height/2);
  await page.keyboard.down('w');await page.waitForTimeout(100);await page.keyboard.up('w');
 }
 const after=await page.evaluate(()=>({player:{...__lc.state.player},frames:__lc.completedMainFrames,draws:__lc.draws,clickTrusted:__lc.clickTrusted,keyTrusted:__lc.keyTrusted,rafActive:__lc.raf.size}));
 return{enabled,before,after};
}
async function run(mode){
 const name=names[mode];console.log('START '+name);
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles',name),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 const errors=[],messages=[];let page;
 try{
  page=context.pages()[0];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(['error','warning'].includes(m.type()))messages.push({type:m.type(),text:m.text()});});
  await page.addInitScript({content:'('+fs.readFileSync(path.join(dir,'observe.js'),'utf8')+')('+JSON.stringify(mode)+');'});
  await page.goto(pathToFileURL(path.join(dir,'index.html')).href,{waitUntil:'load',timeout:180000});
  await page.waitForFunction(()=>__lc?.settled==='rejected'?__lc.disposeCalls>0:__lc?.settled==='fulfilled',null,{timeout:40000});
  await page.waitForTimeout(100);
  const outcome=await page.evaluate(()=>({...__lc.snapshot(),buttonDisabled:document.getElementById('startBtn').disabled,toast:document.getElementById('toast').textContent}));
  let control,restore;
  if(mode==='D'){
   await page.waitForFunction(()=>__lc.completedMainFrames>=2,null,{timeout:40000});control=await input(page);
  }else if(mode==='F')control=await input(page);
  else{
   await page.waitForFunction(()=>__lc.contextLost,null,{timeout:5000});
   restore=await page.evaluate(async()=>{
    const d=__lc,canvas=d.renderer.domElement,g=d.renderer.getContext();
    const before={lost:g.isContextLost(),snapshot:d.snapshot()};
    try{
     await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Native context restore timeout')),5000);canvas.addEventListener('webglcontextrestored',()=>{clearTimeout(timer);resolve();},{once:true});d.loseExtension.restoreContext();});
     return{before,nativeRestored:!g.isContextLost(),snapshot:d.snapshot()};
    }catch(error){return{before,nativeRestored:!g.isContextLost(),error:error.message,snapshot:d.snapshot()};}
   });
   if(restore.nativeRestored&&mode==='L'){
    try{await page.waitForFunction(()=>__lc.completedMainFrames>=2,null,{timeout:40000});control=await input(page);}
    catch(error){control={error:error.message};}
   }else control=await input(page);
  }
  const beforeClose=await page.evaluate(()=>__lc.snapshot());
  const after=await page.evaluate(()=>{__lc.close();return __lc.snapshot();});
  const again=await page.evaluate(()=>{__lc.close();return __lc.snapshot();});
  const j={name,mode,browser:context.browser().version(),outcome,control,restore,beforeClose,after,idempotent:JSON.stringify(after.byKind)===JSON.stringify(again.byKind),errors,messages};
  save(name+'.json',j);
  console.log(JSON.stringify({name,settled:outcome.settled,reason:outcome.reason,badLink:outcome.badLinkStatus,badUses:after.badProgramUses,mainFrames:beforeClose.completedMainFrames,pending:after.pending,pollTimers:after.pollTimers,raf:after.rafActive,nativeRestored:restore?.nativeRestored,envBefore:outcome.environmentBefore,envAfter:beforeClose.environmentNow,epochs:[outcome.preparedEpoch,beforeClose.epoch],staleUses:after.staleUses,control:control&&{enabled:control.enabled,error:control.error,moved:control.after&&Math.hypot(control.after.player.x-control.before.player.x,control.after.player.z-control.before.player.z)},byKind:after.byKind,glError:after.glError,errors:errors.length}));
 }catch(error){let snapshot;try{snapshot=await page.evaluate(()=>__lc?.snapshot());}catch{}save(name+'-failure.json',{error:error.stack,snapshot,errors,messages});throw error;}
 finally{await context.close();}
}
(async()=>{for(const mode of process.argv.slice(2).length?process.argv.slice(2):['F','D','E','L'])await run(mode);})().catch(e=>{console.error(e.stack);process.exitCode=1;});
