const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{pathToFileURL}=require('node:url');
const dir=__dirname,root=path.resolve(dir,'../..'),prior=path.resolve(dir,'../r149-async-final-cleanup-20261020');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),write=(n,s)=>fs.writeFileSync(path.join(dir,n),s,{flag:'wx'});
const preserved=JSON.parse(fs.readFileSync(path.join(prior,'preserved-before.json')));
for(const [f,h]of Object.entries(preserved))if(sha(fs.readFileSync(path.join(root,f)))!==h)throw Error('Preserved file changed '+f);
for(const n of ['three-stage2.js','three-stage2-probe.js','dispose-environment.js','scene.js','graphics.js','app.js','observe-resource.js','report.md','resource-acceptance.json','functional-analysis.json','state-fixture-v2.json','real-start-w.json','stage2-B.json'])preserved[path.relative(root,path.join(prior,n))]=sha(fs.readFileSync(path.join(prior,n)));
write('preserved-before.json',JSON.stringify(preserved,null,2));
for(const n of ['three-stage2.js','dispose-environment.js','scene.js','graphics.js','app.js'])write(n,fs.readFileSync(path.join(prior,n)));
let html=fs.readFileSync(path.join(prior,'index-final.html'),'utf8').split(pathToFileURL(prior).href+'/').join(pathToFileURL(dir).href+'/');write('index.html',html);
let o=fs.readFileSync(path.join(prior,'observe-resource.js'),'utf8');
function once(a,b){if(o.split(a).length!==2)throw Error('Observer anchor '+a);o=o.replace(a,b);}
once("triggered:false};","triggered:false,epoch:0,draws:0,completedMainFrames:0,staleUses:[],glErrors:[],extensionRequests:[],raf:new Set()};");
once("'bindTexture','getExtension','getProgramParameter','useProgram'","'getError','shaderSource','attachShader','bindTexture','getSupportedExtensions','getExtension','getProgramParameter','useProgram'");
once("d.extensionHidden=true;return null;","d.extensionHidden=true;d.extensionRequests.push({phase:d.phase,epoch:d.epoch,result:null});return null;");
once('const value=Reflect.apply(fn,this,a);',`if(name==='getSupportedExtensions'&&scenario==='D')return Reflect.apply(fn,this,a)?.filter(x=>x!=='KHR_parallel_shader_compile');
   if(name==='shaderSource'&&scenario==='F'&&d.phase==='preparing'&&!d.badShader&&this.getShaderParameter(a[0],this.SHADER_TYPE)===this.FRAGMENT_SHADER){
    d.badShader=a[0];d.triggered=true;d.injectedSourceLength=a[1].length;event('inject-real-fragment-compile-error',{shader:ids.get(a[0])?.id});a[1]+='\\n#error TBS_CONTROLLED_SHADER_FAILURE\\n';
   }
   if(name==='attachShader'&&a[1]===d.badShader){d.badProgram=a[0];d.badProgramID=ids.get(a[0])?.id;}
   if(['useProgram','bindTexture'].includes(name)){const row=ids.get(a[name==='useProgram'?0:1]);if(row&&row.epoch!==d.epoch&&!this.isContextLost())d.staleUses.push({name,id:row.id,old:row.epoch,current:d.epoch});}
   if(name==='useProgram'&&a[0]===d.badProgram)d.badProgramUses=(d.badProgramUses||0)+1;
   const value=Reflect.apply(fn,this,a);
   if(name==='getExtension'&&a[0]==='WEBGL_lose_context'&&value)d.loseExtension=value;
   if(name==='getError'&&value)d.glErrors.push({value,phase:d.phase,epoch:d.epoch,lost:this.isContextLost()});
   if(name==='getProgramParameter'&&a[0]===d.badProgram&&a[1]===this.LINK_STATUS)d.badLinkStatus=value;
   if(name.startsWith('draw'))d.draws++;`);
once('deletes:0,handle:value','deletes:0,epoch:d.epoch,handle:value');
once('d.world=result;const r=result.renderer;d.renderer=r;',`d.world=result;const r=result.renderer;d.renderer=r;
   const canvas=r.domElement;canvas.addEventListener('webglcontextlost',()=>{d.epoch++;event('generation-lost',{epoch:d.epoch});},true);
   d.environmentBacking=()=>{const texture=result.scene.environment,handle=r.properties.get(texture).__webglTexture;return{texture:texture?.uuid,native:ids.get(handle)?.id,valid:!!handle&&!r.getContext().isContextLost()&&r.getContext().isTexture(handle)};};
   d.environmentBefore=d.environmentBacking();`);
once('const v=Reflect.apply(render,this,arguments);if(scene===result.scene)d.mainFrames++;return v;',`const before=d.draws,lost=r.getContext().isContextLost();const v=Reflect.apply(render,this,arguments);if(scene===result.scene){d.mainFrames++;if(!lost&&d.draws>before)d.completedMainFrames++;}return v;`);
once("d.pending++;d.phase='preparing';","d.close=r.__startupClose;d.pending++;d.phase='preparing';");
once("const v=await Reflect.apply(prep,this,arguments);d.settled='fulfilled';event('prepare-fulfilled');return v;",`const v=await Reflect.apply(prep,this,arguments);
     d.preparedEpoch=d.epoch;d.preparedNativeIDs=r.info.programs.map(p=>ids.get(p.program)?.id);
     if(scenario==='L'){
      const ext=r.getContext().getExtension('WEBGL_lose_context');if(!ext)throw Error('WEBGL_lose_context unavailable');
      const lost=new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Lost-event timeout')),5000);r.domElement.addEventListener('webglcontextlost',()=>{clearTimeout(timer);resolve();},{once:true});});
      event('lose-after-real-preparation',{reflected:v.reflected,programs:d.preparedNativeIDs.length});ext.loseContext();await lost;
      event('return-real-prepared-result',{lost:r.getContext().isContextLost(),preparedEpoch:d.preparedEpoch,currentEpoch:d.epoch});
     }
     d.settled='fulfilled';event('prepare-fulfilled');return v;`);
once("catch(e){d.settled='rejected';","catch(e){d.preparationError=e;d.settled='rejected';");
once("if(name==='buildPresentation'){d.ports=result;","if(name==='buildPresentation'){d.state=args[0].state;d.ports=result;");
once('d.snapshot=()=>{',`const request=requestAnimationFrame,cancel=cancelAnimationFrame;
 window.requestAnimationFrame=function(fn){let id;id=request(t=>{d.raf.delete(id);fn(t);});d.raf.add(id);return id;};window.cancelAnimationFrame=function(id){d.raf.delete(id);return cancel(id);};
 const report=console.error;console.error=function(...args){if(args[0]===d.preparationError)d.errorReported=true;return Reflect.apply(report,this,args);};
 d.snapshot=()=>{`);
once('scenario,pmrem:d.pmrem,phase:',`scenario,epoch:d.epoch,preparedEpoch:d.preparedEpoch,preparedNativeIDs:d.preparedNativeIDs,completedMainFrames:d.completedMainFrames,draws:d.draws,staleUses:d.staleUses,glErrors:d.glErrors,rafActive:d.raf.size,extensionRequests:d.extensionRequests,badProgramID:d.badProgramID,badLinkStatus:d.badLinkStatus,badProgramUses:d.badProgramUses||0,errorReported:!!d.errorReported,environmentBefore:d.environmentBefore,environmentNow:d.environmentBacking(),pmrem:d.pmrem,phase:`);
once('phase:x.phase,deletes:x.deletes','phase:x.phase,epoch:x.epoch,deletes:x.deletes');
write('observe.js',o);
console.log('Prepared unchanged latest B++ and external fault-injection observers; preserved '+Object.keys(preserved).length+' files.');
