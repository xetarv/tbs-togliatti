# B++: три сценария отказа

**Итог: shader error PASS, отсутствие KHR PASS, полное восстановление после context loss FAIL. Исправление не применялось; работа остановлена на нескольких требованиях восстановления.**

Исходная копия: `r149-async-final-cleanup-20261020/three-stage2.js`, со всеми предыдущими lifecycle/PMREM/fallback исправлениями. В этом каталоге engine, app и cleanup скопированы без изменения. Внешний observer только пересылает native результаты и вводит заданные отказы. Среда: оконный Edge 155.0.4283.62, file://, RTX 3050 Laptop / ANGLE D3D11, High задан через прежний localStorage, shader checks=true.

## 1. Shader/program — PASS

Во время настоящей подготовки в один fragment shader добавлен `#error TBS_CONTROLLED_SHADER_FAILURE`. Native compiler/linker сообщил `Fragment shader is not compiled`, LINK_STATUS=false. Готовность не подменялась: текущий `compileAsyncPasses` обнаружил `diagnostics.runnable=false` и отверг promise с `Shader preparation failed: 3`.

Реальный app catch показал ошибку, отключил Start и завершил окружение. Попытка браузерного мышиного ввода/клавиши W не запустила игру: полных main frames=0, useProgram для неверной программы=0, RAF=0. Исходная ошибка дошла до console.error. Pending/poll timers/pagehide handlers=0. Program **79/79**, shader **158/158**, texture **8/8**, framebuffer **10/10**, renderbuffer **8/8**; двойных delete и GL errors=0. Безопасная стратегия здесь — терминальный отказ, автоматического fallback на испорченный shader нет. `shader-error.json`.

## 2. KHR отсутствует — PASS

До создания renderer observer убрал KHR из getSupportedExtensions и возвращал null из getExtension. Все **89 запросов** получили null, первый — в building, а не после получения engine расширения. COMPLETION_STATUS_KHR queries=**0**; обращения к отсутствующему extension API и зависших timers нет.

`isReady` сразу пропускает KHR-ожидание; штатная lazy uniform/attribute reflection с включёнными shader checks выполняется синхронно. Promise fulfilled; настоящий runtime, доверенные mouse/keyboard события Start/W, движение **0.2483** world units. После завершения: program **89/89**, shader **178/178**, texture **79/79**, framebuffer **20/20**, renderbuffer **15/15**; pending/timers=0, GL errors=0. `no-khr.json`.

## 3A. Context loss при незавершённой подготовке — FAIL восстановления

Native COMPLETION_STATUS_KHR=false действительно наблюдался, затем вызван WEBGL_lose_context. Promise отвергнут с `Preparation timeout/context lost`, ожидание и polling завершились, app выполнил терминальную очистку. Это **PASS безопасного отказа**.

После настоящего native restore игра не восстанавливается: renderer уже disposed, его штатный restore-listener снят, Start остаётся disabled, main frames=0, RAF=0, GPU environment backing отсутствует. Старые результаты ready не были приняты; программа не продолжала рисовать. Общая проверка полноценного восстановления — FAIL. `loss-pending.json`.

Две fallback texture без delete уже инвалидированы потерей контекста (nativeLive=0); требование обычных парных delete к ним не применялось. CONTEXT_LOST_WEBGL=37442 записан как ожидаемый результат fault injection, после restore GL error=0.

## 3B. Context loss после подготовки, до первого main render — FAIL

Observer дождался реального завершения compileAsyncPasses, сохранил его результат поколения 0, вызвал loss и дождался native lost-event; затем вернул **тот же реальный результат**, не переписывая success/failure. Context уже поколения 1 и lost=true, но app принял fulfilled и запустил runtime. Пока контекст потерян: полных main frames=0, RAF active=1.

После штатного native restore renderer пересоздал свои внутренние кэши; реальный render и Start/W возобновились (**26** полных main frames, движение **0.2739**). Это не полное восстановление:

- `__asyncStats` / принятая готовность относятся к старому поколению. Пересечения prepared native program IDs с созданными программами нового контекста нет; async-подготовка для нового контекста не запускалась.
- `scene.environment` остаётся тем же GPU-generated PMREM Texture, но его backing после restore отсутствует (`valid=false`, до потери native ID=3/valid=true). Создание этой карты происходило однажды в `createScene → PMREMGenerator.fromScene`; восстановление внутренних кэшей renderer не повторяет генерацию. Успешный Start/W не доказывает восстановление High-графики.
- Перед завершающей очисткой GL error=0. При очистке после restore возникают native `INVALID_OPERATION: delete: object does not belong to this context` и `deleteVertexArray` того же вида; итог GL error=**1282**. Сравнение beforeClose/after доказывает delete-вызовы для объектов поколения 0 в поколении 1: texture **5**, framebuffer **9**, renderbuffer **8**, buffer **4**, VAO **1**. Среди них target первоначальной environment-карты (стек fromScene), а также другие старые owners. Наблюдатель не выполняет собственных delete.

Прямых stale useProgram/bindTexture не зафиксировано, но stale **delete** уже нарушают требование не обращаться к старым GL-объектам. Pending/polling после теста=0. Подробности: `loss-after-ready.json`, `summary.json`.

## Причины и граница исправления

По коду и данным имеются разные требования: проверка поколения при передаче результата подготовки в runtime, восстановление GPU-generated world environment, устранение старых native owner/dispose callbacks после пересоздания renderer-кэшей. Native WebGLTextures привязывает dispose-listener к RenderTarget с замыканием на свои properties; при restore `WebGLRenderer.Mt()` создаёт новый комплект внутренних owners. Старые callbacks не становятся автоматически владельцами новых handles. Аналогично есть обращения к старым VAO/buffer при последующем завершении.

Одна проверка `isContextLost()` перед Start оставила бы проблемы восстановления и последующей очистки. Замена восстановления полной перезагрузкой/терминальным отказом потребовала бы отдельного согласованного поведения. Несколько отдельных исправлений или перестройка жизненного цикла в этом задании не выполнялись. Не утверждается, что все эти ограничения впервые внесены B++; отдельного stock-r149 restore-контроля в этом ограниченном пакете не было.

Итоговый этап 5 **не запускался**, поскольку context loss проверки не пройдены. Новые визуальные/RNG/performance серии не проводились. Ранее подтверждённые нормальный Start/W, RNG/вода и ресурсная очистка сохранены по файлам, а не выданы за повторно выполненные тесты. Известная строгая визуальная неопределённость движения остаётся открытой.

WEBGL_lose_context моделирует отказ; это не тест реального сбоя GPU. При потере контекста native invalidation отличается от delete-запросов; непарные счётчики старого поколения не объявлены утечкой GPU-памяти.

## Сохранность

`preservation-check.json`: 141 целевой ранее существовавший файл, включая production/оригинальную Three.js, четыре shaderChecks-файла и предыдущие экспериментальные входы/доказательства. `git-final.json` фиксирует неизменный HEAD/main, пустой индекс и прежние четыре локальных изменения. Новые материалы находятся только здесь; исторические результаты не перезаписывались. Build/check, commit/push не выполнялись. Production-интеграция не разрешена.
