const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=__dirname,old=path.resolve(dir,'../r149-async-rng-20261020');
const read=n=>JSON.parse(fs.readFileSync(path.join(dir,n))),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const a=read('visual-1-A1.json'),b=read('visual-1-B.json'),a2=read('visual-1-A2.json'),strict=read('visual-1-comparison.json');
const keys=x=>x.observation.programs.map(p=>p.name+'|'+p.cacheKey).sort();
const stages=Object.fromEntries(['first','moving','night'].map(stage=>[stage,{
 rngEqual:JSON.stringify(a[stage].rng)===JSON.stringify(b[stage].rng),
 stateEqual:a[stage].stateSHA256===b[stage].stateSHA256&&a[stage].trafficSHA256===b[stage].trafficSHA256&&a[stage].worldTransformsSHA256===b[stage].worldTransformsSHA256&&JSON.stringify(a[stage].camera)===JSON.stringify(b[stage].camera),
 waterEqual:JSON.stringify(a[stage].waterState)===JSON.stringify(b[stage].waterState),
 audioEqual:JSON.stringify(a[stage].audio)===JSON.stringify(b[stage].audio),
 programKeysEqual:JSON.stringify(keys(a[stage]))===JSON.stringify(keys(b[stage])),
 glErrors:b[stage].observation.glErrors,
 water:b[stage].waterState,rng:b[stage].rng,
 prepared:b[stage].observation.prepared.submitted,
 used:b[stage].observation.used.length,total:b[stage].observation.created.length
}]));
const raw=n=>fs.readFileSync(path.join(dir,`visual-1-${n}-moving.rgba`));
const ca=raw('A1'),cb=raw('B'),h1=fs.readFileSync(path.join(old,'visual-1-A1-moving.rgba')),h2=fs.readFileSync(path.join(old,'visual-1-A2-moving.rgba'));
if(ca.length!==h1.length||ca.length!==cb.length)throw Error('Image dimensions mismatch');
let signed=0,inverse=0,mask=0;const currentDelta=Buffer.alloc(ca.length),historicDelta=Buffer.alloc(ca.length);
for(let i=0;i<ca.length;i++){const x=cb[i]-ca[i],y=h2[i]-h1[i];signed+=x!==y;inverse+=x!==-y;mask+=(x!==0)!==(y!==0);currentDelta[i]=x&255;historicDelta[i]=(-y)&255;}
const result={strictPixelGate:strict.passed,strictComparison:strict.results,independentNonces:new Set([a.nonce,b.nonce,a2.nonce]).size===3,stages,
 futureCheckpoints:b.night.futureStates.length,futureStateAndRNGEqual:JSON.stringify(a.night.futureStates)===JSON.stringify(b.night.futureStates),
 historicalMovingControl:{directory:path.relative(path.resolve(dir,'../..'),old),referencePair:['visual-1-A1-moving.rgba','visual-1-A2-moving.rgba'],bytes:ca.length,signedDifferenceMismatches:signed,inverseDifferenceMismatches:inverse,coordinateChannelMaskMismatches:mask,candidateEqualsHistoricalA1:cb.equals(h1),currentDeltaSHA256:sha(currentDelta),inverseHistoricalDeltaSHA256:sha(historicDelta),note:'Strict gate remains false; no pixel thresholds or tolerances were introduced. Full signed-difference equality up to A/A ordering is provenance evidence of the already observed variation, not a new bitwise-identity claim.'}};
fs.writeFileSync(path.join(dir,'functional-analysis.json'),JSON.stringify(result,null,2),{flag:'wx'});
for(const row of Object.values(stages))if(!row.rngEqual||!row.stateEqual||!row.waterEqual||!row.audioEqual||!row.programKeysEqual||row.glErrors.length)throw Error('Functional mismatch');
if(!result.futureStateAndRNGEqual||!result.independentNonces)throw Error('Future state/RNG mismatch');
console.log(JSON.stringify({stages,futureCheckpoints:result.futureCheckpoints,futureStateAndRNGEqual:result.futureStateAndRNGEqual,strictPixelGate:result.strictPixelGate,historical:result.historicalMovingControl}));
