const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,save=(n,j)=>fs.writeFileSync(path.join(dir,n),JSON.stringify(j,null,2),{flag:'wx'});
const [stage='1',...modes]=process.argv.slice(2);
async function run(mode){
 const name=`stage${stage}-${mode}`;console.log('START '+name);
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles',name),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
  const page=context.pages()[0],errors=[],messages=[];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(['error','warning'].includes(m.type()))messages.push({type:m.type(),text:m.text()});});
  await page.addInitScript({content:'('+fs.readFileSync(path.join(dir,'observe-resource.js'),'utf8')+')('+JSON.stringify(mode)+');'});
  const html=mode==='T'||mode==='S'?'index-stock.html':`index-stage${stage}.html`;
  await page.goto(pathToFileURL(path.join(dir,html)).href,{waitUntil:'load',timeout:180000});
  if(mode==='T')await page.waitForFunction(()=>window.__lc?.disposeCalls>0,null,{timeout:120000});
  else await page.waitForFunction(()=>window.__lc?.settled==='rejected'?window.__lc.disposeCalls>0:window.__lc?.mainFrames>=2,null,{timeout:150000});
  await page.waitForTimeout(50);const before=await page.evaluate(()=>window.__lc.snapshot());
  let after=before;
  if(['A','D','S'].includes(mode))after=await page.evaluate(()=>{const d=window.__lc,close=d.renderer.__startupClose;d.close=close;close();return d.snapshot();});
  await page.waitForTimeout(100);const settled=await page.evaluate(()=>window.__lc.snapshot());
  let idempotent=true;if(['A','D','S'].includes(mode)){const again=await page.evaluate(()=>{window.__lc.close();return window.__lc.snapshot();});idempotent=JSON.stringify(again.byKind)===JSON.stringify(settled.byKind)&&again.disposeCalls===settled.disposeCalls;}
  save(name+'.json',{mode,stage,browser:context.browser().version(),before,after,settled,idempotent,errors,messages});
  console.log(JSON.stringify({name,settled:settled.settled,reason:settled.reason,programs:settled.rendererPrograms.length,byKind:settled.byKind,pending:settled.pending,timers:settled.pollTimers,handler:settled.pagehideActive,graphics:settled.graphicsDisposeCalls,postDispose:settled.postDispose.length,gl:settled.glError,idempotent}));
 }catch(e){let snapshot;try{snapshot=await context.pages()[0].evaluate(()=>window.__lc?.snapshot());}catch{}save(name+'-failure.json',{error:e.stack,snapshot});throw e;}
 finally{await context.close();}
}
(async()=>{for(const mode of modes.length?modes:['B','T'])await run(mode);})().catch(e=>{console.error(e.stack);process.exitCode=1;});
