// External lifecycle observer. Forward native arguments/results; no shader/RNG changes.
scenario=>{
 const d=window.__lc={scenario,phase:'building',events:[],pending:0,settled:null,mainFrames:0,disposeCalls:0,graphicsDisposeCalls:0,pagehideActive:0,timers:new Set(),statusCalls:0,postDispose:[],objects:[],contextLost:false,restored:false,triggered:false};
 const ids=new WeakMap(),contexts=new Set();let next=0;
 const event=(name,data={})=>d.events.push({name,t:performance.now(),...data});
 const createKinds={createProgram:'program',createShader:'shader',createTexture:'texture',createBuffer:'buffer',createFramebuffer:'framebuffer',createRenderbuffer:'renderbuffer',createVertexArray:'vertexArray',fenceSync:'sync'};
 const deleteKinds={deleteProgram:'program',deleteShader:'shader',deleteTexture:'texture',deleteBuffer:'buffer',deleteFramebuffer:'framebuffer',deleteRenderbuffer:'renderbuffer',deleteVertexArray:'vertexArray',deleteSync:'sync'};
 const nativeError=console.error;console.error=function(...a){if(a[0]===d.injectedError)d.originalErrorReported=true;return Reflect.apply(nativeError,this,a);};
 for(const proto of [WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype])for(const name of [...Object.keys(createKinds),...Object.keys(deleteKinds),'getExtension','getProgramParameter','useProgram','drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced']){
  const fn=proto[name];if(!fn||fn.__lifecycle)continue;
  const wrapped=function(...a){
   contexts.add(this);
   if(name==='getExtension'&&a[0]==='KHR_parallel_shader_compile'&&scenario==='D'){d.extensionHidden=true;return null;}
   if(d.disposeCalls&&!d.reading&&['getProgramParameter','useProgram','drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced'].includes(name))d.postDispose.push({name,t:performance.now(),phase:d.phase});
   const value=Reflect.apply(fn,this,a);
   if(createKinds[name]&&value){const row={id:++next,kind:createKinds[name],phase:d.phase,created:performance.now(),deletes:0,handle:value,gl:this,stack:["framebuffer","texture"].includes(createKinds[name])?new Error().stack:undefined};ids.set(value,row);d.objects.push(row);}
   if(deleteKinds[name]&&a[0]){const row=ids.get(a[0]);if(row){row.deletes++;row.deleted=performance.now();}}
   if(name==='getProgramParameter'&&a[1]===0x91b1){
    d.statusCalls++;
    if(d.phase==='preparing'&&value===false&&!d.triggered&&['B','E'].includes(scenario)){
     d.triggered=true;event('native-program-not-ready',{program:ids.get(a[0])?.id});
     queueMicrotask(()=>{
      if(scenario==='B'){event('dispatch-pagehide');dispatchEvent(new PageTransitionEvent('pagehide'));}
      else{const ext=this.getExtension('WEBGL_lose_context');d.contextLossSupported=!!ext;if(ext){event('lose-context');ext.loseContext();}else event('context-loss-unavailable');}
     });
    }
   }
   return value;
  };wrapped.__lifecycle=true;proto[name]=wrapped;
 }
 const add=EventTarget.prototype.addEventListener,remove=EventTarget.prototype.removeEventListener,pagehide=new Set();
 EventTarget.prototype.addEventListener=function(type,fn,...rest){if(this===window&&type==='pagehide'){pagehide.add(fn);d.pagehideActive=pagehide.size;}return Reflect.apply(add,this,[type,fn,...rest]);};
 EventTarget.prototype.removeEventListener=function(type,fn,...rest){if(this===window&&type==='pagehide'){pagehide.delete(fn);d.pagehideActive=pagehide.size;}return Reflect.apply(remove,this,[type,fn,...rest]);};
 const timeout=setTimeout,clear=clearTimeout;window.setTimeout=function(fn,ms,...args){if(d.phase!=='preparing'||ms!==10)return timeout(fn,ms,...args);let id;id=timeout(function(...a){d.timers.delete(id);return Reflect.apply(fn,this,a);},ms,...args);d.timers.add(id);return id;};window.clearTimeout=function(id){d.timers.delete(id);return clear(id);};
 localStorage.setItem('tbs.graphicsQuality','high');let registry;
 Object.defineProperty(window,'TBS',{get:()=>registry,set(api){registry=api;for(const name of ['buildWorld','buildPresentation','createRuntime']){let fn;Object.defineProperty(api,name,{get:()=>fn,set(original){fn=function(...args){
  const result=Reflect.apply(original,this,args);
  if(name==='buildWorld'){
   d.world=result;const r=result.renderer;d.renderer=r;
   const gl=r.getContext();d.textureOwners=new Map();
   gl.__textureEvidence=(texture,handle)=>{const row=d.objects.find(x=>x.handle===handle);if(row){let owners=d.textureOwners.get(row.id);if(!owners)d.textureOwners.set(row.id,owners=new Set());owners.add(texture);}};
   d.pmrem=[];d.pmremOutputs=new Map();
   r.__pmremRecord=(source,target,branch)=>{
    let row=d.pmremOutputs.get(target);
    if(!row){
     const prop=r.properties.get(target),tex=r.properties.get(target.texture);
     row={source:source.uuid,target:target.uuid,output:target.texture.uuid,width:target.width,height:target.height,branches:{},disposeEvents:0,sourceDispose:0,
      framebuffer:d.objects.find(x=>x.handle===prop.__webglFramebuffer)?.id,texture:d.objects.find(x=>x.handle===tex.__webglTexture)?.id};
     d.pmremOutputs.set(target,row);d.pmrem.push(row);
     target.addEventListener('dispose',()=>{row.disposeEvents++;row.disposedAt=performance.now();});
     source.addEventListener('dispose',()=>row.sourceDispose++);
    }
    row.branches[branch]=(row.branches[branch]||0)+1;
    if(row.disposeEvents)d.events.push({name:'USE-AFTER-PMREM-DISPOSE',target:target.uuid});
    const sources=r.__pmremSources?.();if(sources)for(const [owner,input]of Object.entries(sources))if(input?.texture===source){row.owner=owner;row.inputTarget=input.uuid;}
   };
   r.domElement.addEventListener('webglcontextlost',()=>{d.contextLost=true;event('context-lost-event');});r.domElement.addEventListener('webglcontextrestored',()=>{d.restored=true;event('context-restored-event');});
   const dispose=r.dispose;r.dispose=function(){event('renderer-dispose');d.disposeCalls++;return Reflect.apply(dispose,this,arguments);};
   const render=r.render;r.render=function(scene,camera){const v=Reflect.apply(render,this,arguments);if(scene===result.scene)d.mainFrames++;return v;};
   if(scenario==='C'){const compile=r.compile;r.compile=function(){const value=Reflect.apply(compile,this,arguments);if(!d.injectedError){d.injectedError=new Error('Controlled lifecycle initialization failure');event('inject-initialization-error');throw d.injectedError;}return value;};}
   const prep=r.compileAsyncPasses;if(prep)r.compileAsyncPasses=async function(passes,options){
    d.pending++;d.phase='preparing';d.beforePrograms=r.info.programs.length;d.signal=options.signal;event('prepare-start');
    try{const v=await Reflect.apply(prep,this,arguments);d.settled='fulfilled';event('prepare-fulfilled');return v;}
    catch(e){d.settled='rejected';d.reason={name:e?.name,message:e?.message,sameInjected:e===d.injectedError,sameAbort:e===options.signal.reason};event('prepare-rejected',d.reason);throw e;}
    finally{d.pending--;d.phase='after-preparation';}
   };
  }
  if(name==='buildPresentation'){d.ports=result;const dispose=result.graphics.dispose;const tracked=function(){d.graphicsDisposeCalls++;return Reflect.apply(dispose,this,arguments);};result.graphics.dispose=tracked;d.renderer.__startupDispose=tracked;}
  if(name==='createRuntime'){d.runtime=result;d.game=args[0].game;}
  return result;
 };}});}}});
 d.snapshot=()=>{
  d.reading=true;
  try{
   const byKind={};for(const row of d.objects){const c=byKind[row.kind]||={created:0,deleteCalls:0,duplicateDeletes:0,unrequested:0,nativeLive:0};c.created++;c.deleteCalls+=row.deletes;c.duplicateDeletes+=Math.max(0,row.deletes-1);c.unrequested+=row.deletes===0;const test={program:'isProgram',shader:'isShader',texture:'isTexture',buffer:'isBuffer',framebuffer:'isFramebuffer',renderbuffer:'isRenderbuffer',vertexArray:'isVertexArray',sync:'isSync'}[row.kind];if(!row.gl.isContextLost()&&test&&row.gl[test](row.handle))c.nativeLive++;}
   const r=d.renderer,g=r.getContext(),ext=g.getExtension('WEBGL_debug_renderer_info');
   return{scenario,pmrem:d.pmrem,phase:d.phase,pending:d.pending,settled:d.settled,reason:d.reason,originalErrorReported:!!d.originalErrorReported,mainFrames:d.mainFrames,disposeCalls:d.disposeCalls,graphicsDisposeCalls:d.graphicsDisposeCalls,pagehideActive:d.pagehideActive,pollTimers:d.timers.size,statusCalls:d.statusCalls,postDispose:d.postDispose,contextLost:d.contextLost,restored:d.restored,contextLossSupported:d.contextLossSupported,extensionHidden:d.extensionHidden,triggered:d.triggered,events:d.events,stats:r.__asyncStats,rendererPrograms:r.info.programs.map(p=>({id:p.id,name:p.name,usedTimes:p.usedTimes,live:!!p.program&&!g.isContextLost()&&g.isProgram(p.program)})),memory:{...r.info.memory},byKind,checks:r.debug.checkShaderErrors,lost:g.isContextLost(),glError:g.getError(),GPU:ext&&!g.isContextLost()?g.getParameter(ext.UNMASKED_RENDERER_WEBGL):null,objects:d.objects.map(x=>({id:x.id,kind:x.kind,phase:x.phase,deletes:x.deletes,stack:x.stack})),note:'Strong diagnostic handle references verify explicit cleanup; GL validity is not a driver-memory measurement. Context invalidation is separate from delete calls.'};
  }finally{d.reading=false;}
 };
}
