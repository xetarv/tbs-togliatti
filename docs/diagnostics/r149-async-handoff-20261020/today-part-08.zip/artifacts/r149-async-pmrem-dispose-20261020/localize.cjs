const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,write=(n,s)=>fs.writeFileSync(path.join(dir,n),s,{flag:'wx'});
let engine=fs.readFileSync(path.join(dir,'three-fixed-probe.js'),'utf8');
const anchor='e.__webglTexture=s[o].texture}return n}function Q(e,r,a)';
if(engine.split(anchor).length!==2)throw Error('Texture attribution anchor');
engine=engine.replace(anchor,'e.__webglTexture=s[o].texture}t.__textureEvidence?.(i,e.__webglTexture);return n}function Q(e,r,a)');
write('three-texture-owner-probe.js',engine);
write('index-texture-owner.html',fs.readFileSync(path.join(dir,'index-fixed.html'),'utf8').replace('three-fixed-probe.js','three-texture-owner-probe.js'));
let observer=fs.readFileSync(path.join(dir,'observe.js'),'utf8');
observer=observer.replace('d.world=result;const r=result.renderer;d.renderer=r;',`d.world=result;const r=result.renderer;d.renderer=r;
   const gl=r.getContext();d.textureOwners=new Map();
   gl.__textureEvidence=(texture,handle)=>{const row=d.objects.find(x=>x.handle===handle);if(row){let owners=d.textureOwners.get(row.id);if(!owners)d.textureOwners.set(row.id,owners=new Set());owners.add(texture);}};`);
write('texture-owner-observer.js',observer);
(async()=>{
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles','texture-owner'),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
  const page=context.pages()[0],errors=[];page.on('pageerror',e=>errors.push(e.stack));
  await page.addInitScript({content:'('+observer+')("A");'});
  await page.goto(pathToFileURL(path.join(dir,'index-texture-owner.html')).href,{waitUntil:'load',timeout:180000});
  await page.waitForFunction(()=>window.__lc?.mainFrames>=2,null,{timeout:150000});
  const j=await page.evaluate(()=>{
   const d=window.__lc,r=d.renderer,associations=new Map();
   const add=(tex,owner)=>{if(tex?.isTexture){const rows=associations.get(tex)||[];rows.push(owner);associations.set(tex,rows);}};
   for(const pass of r.__startupPasses())pass.scene.traverse(o=>{
    for(const m of o.material?(Array.isArray(o.material)?o.material:[o.material]):[]){
     for(const [key,value]of Object.entries(m))add(value,{pass:pass.name,object:o.name,type:m.type,material:m.uuid,property:key});
     for(const [key,u]of Object.entries(r.properties.get(m).uniforms||{})){
      if(Array.isArray(u.value))u.value.forEach((value,index)=>add(value,{pass:pass.name,type:m.type,material:m.uuid,uniform:key,index}));
      else add(u.value,{pass:pass.name,type:m.type,material:m.uuid,uniform:key});
     }
    }
   });
   const before=d.snapshot();r.__startupClose();const after=d.snapshot();
   const remaining=d.objects.filter(x=>x.kind==='texture'&&!x.deletes).map(row=>({native:row.id,stack:row.stack,
    owners:[...(d.textureOwners.get(row.id)||[])].map(t=>({uuid:t.uuid,source:t.source.uuid,type:t.constructor.name,image:t.image?{type:t.image.constructor.name,width:t.image.width,height:t.image.height}:null,renderTarget:!!t.isRenderTargetTexture,hasDisposeListeners:!!t._listeners?.dispose?.length,associations:associations.get(t)||[]}))}));
   delete r.getContext().__textureEvidence;
   return{before:before.byKind,after:after.byKind,remaining};
  });
  write('texture-owners.json',JSON.stringify({...j,errors},null,2));
  console.log(JSON.stringify({remaining:j.remaining.map(x=>({native:x.native,owners:x.owners})),errors}));
 }finally{await context.close();}
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
