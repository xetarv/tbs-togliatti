const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,save=(n,j)=>fs.writeFileSync(path.join(dir,n),JSON.stringify(j,null,2),{flag:'wx'});
const [variant='fixed',cyclesArg='1',name=variant]=process.argv.slice(2),cycles=Number(cyclesArg);
function gate(j){
 const s=j.after;
 if(s.glError||s.pending||s.pollTimers||s.postDispose.length||s.pmrem.some(p=>p.disposeEvents!==1)||s.events.some(e=>e.name==='USE-AFTER-PMREM-DISPOSE'))throw Error('PMREM gate failed');
 for(const k of ['program','shader','framebuffer','renderbuffer','buffer'])if(s.byKind[k]?.unrequested||s.byKind[k]?.duplicateDeletes)throw Error('Cleanup gate '+k);
 if(!j.idempotent)throw Error('Cleanup was not idempotent');
}
(async()=>{
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles',name),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 const rows=[],errors=[],messages=[];
 try{
  const page=context.pages()[0];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(['error','warning'].includes(m.type()))messages.push({type:m.type(),text:m.text()});});
  await page.addInitScript({content:'('+fs.readFileSync(path.join(dir,'observe.js'),'utf8')+')('+JSON.stringify(variant==='stock'?'S':'A')+');'});
  await page.goto(pathToFileURL(path.join(dir,'index-'+variant+'.html')).href,{waitUntil:'load',timeout:180000});
  for(let cycle=1;cycle<=cycles;cycle++){
   if(cycle>1)await page.evaluate(async()=>{
    const d=window.__lc,oldGL=d.renderer.getContext(),canvas=d.renderer.domElement;
    d.disposeCalls=0;d.mainFrames=0;d.phase='building';d.settled=null;d.postDispose=[];
    const api=window.TBS,dom=api.createDom(document),state=api.domain.createState(),presentation=api.createPresentationState(state);
    const world=api.buildWorld({T:THREE,canvas,config:api.domain.config}),{runtime}=api.buildGame({state,presentation,world,dom});
    d.sameContext=world.renderer.getContext()===oldGL;if(!d.sameContext)throw Error('GL context changed');
    installStartupEnvironmentCleanup(world,runtime);
    await world.renderer.compileAsyncPasses(world.renderer.__startupPasses(),{signal:new AbortController().signal});runtime.start();
   });
   // Native runtime frames refresh Fastback reflections more than once, proving
   // reuse of the same output target while it remains alive.
   await page.waitForFunction(()=>window.__lc?.mainFrames>=2,null,{timeout:150000});
   await page.waitForTimeout(950);
   const sourceOwners=await page.evaluate(()=>Object.entries(window.__lc.renderer.__pmremSources()).map(([name,rt])=>({name,target:rt?.uuid,texture:rt?.texture.uuid})));
   const before=await page.evaluate(()=>window.__lc.snapshot());
   const after=await page.evaluate(()=>{const d=window.__lc;d.close=d.renderer.__startupClose;d.close();return d.snapshot();});
   const again=await page.evaluate(()=>{window.__lc.close();return window.__lc.snapshot();});
   const row={cycle,sameContext:cycle===1||await page.evaluate(()=>window.__lc.sameContext),sourceOwners,before,after,idempotent:JSON.stringify(after.byKind)===JSON.stringify(again.byKind)};
   rows.push(row);save(name+'-'+cycle+'.json',row);
   console.log(JSON.stringify({name,cycle,sameContext:row.sameContext,pmrem:after.pmrem,byKind:after.byKind,gl:after.glError}));
   if(variant==='fixed')gate(row);
  }
  if(errors.length)throw Error('Page errors '+errors.join('\n'));
  save(name+'-summary.json',{variant,browser:context.browser().version(),rows,errors,messages,note:'Lifecycle evidence only. Headful Edge/ANGLE D3D11, real High rendering, same GL for repeated cycles. Strong observer references; native deletion requests are not driver-memory measurements.'});
 }catch(e){save(name+'-failure.json',{error:e.stack,rows,errors,messages});throw e;}
 finally{await context.close();}
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
