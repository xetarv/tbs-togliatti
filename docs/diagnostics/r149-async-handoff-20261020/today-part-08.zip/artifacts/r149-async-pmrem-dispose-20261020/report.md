# B++: освобождение PMREM CubeUV targets

## Результат и граница остановки

Накопление двух выходных PMREM framebuffer устранено одной локальной правкой экспериментального `WebGLCubeUVMaps`. Три реальных High-цикла на одном native GL-контексте дали framebuffer **20/20 → 40/40 → 60/60** (создано/запрошено удаление).

Общий критерий ресурсов **не пройден**: остаются восемь native texture без запроса удаления на окружение. Выполнена только их атрибуция, без второй правки. Поэтому этап 4 (Start/W, изображения первого кадра/движения/ночи, RNG и повторная отмена) в этом задании не запускался. Production не одобрена.

## Причина и владельцы

Подтверждено официальными исходниками r149 в `official/`, локальным `PMREMGenerator.js` из предыдущей диагностики и реальными forwarding-пробами:

1. `WebGLCubeUVMaps` хранит **input Texture → output RenderTarget** в WeakMap. Ветка `isRenderTargetTexture && needsPMREMUpdate` повторно использует существующий output, но не добавляет source-texture dispose listener. Обычная ветка такой listener добавляет.
2. Native `WebGLRenderTarget.dispose()` отправляет событие самого target, **не** событие его color texture. Поэтому завершение входного cube-target в graphics не запускает texture-dispose callback CubeUV-кэша.
3. `WebGLCubeUVMaps.dispose()` заменяет WeakMap, не вызывая dispose выходных targets. `PMREMGenerator.dispose()` освобождает свои материалы, геометрию и ping-pong target, но не возвращённые output targets.
4. `WebGLTextures.onRenderTargetDispose → deallocateRenderTarget` удаляет native framebuffer/texture, используя renderer.properties. Без target.dispose эта цепочка не запускается. Сохранён предыдущий lifecycle-fix: CubeUV/PMREM очищаются **до** сброса properties.

Два входа доказаны сравнением **идентичности объектов** с локальными владельцами graphics: `quarterTarget.texture` (отражения квартала) и `cubeTarget.texture` (Fastback). UUID входа/выхода, native ID framebuffer/texture и ветки get сохранены в `before-1.json`, `stock-1.json`, `normal-1.json`, `repeat-1..3.json`. Оба выхода — CubeUV 384×512. У Fastback за короткий цикл было два обновления одного и того же output; cache hits не создавали новый target. В следующем окружении создаётся новая пара входов/выходов.

Graphics владеет входными cube-targets; **renderer CubeUV cache владеет преобразованными output targets**. После остановки runtime, отсоединения отражений/восстановления envMap и удаления материалов они больше не нужны; их завершает cache.dispose, пока properties доступны.

Короткий stock-r149 контроль без async-подготовки также оставил эти два output без dispose. У stock осталось три framebuffer всего (ещё один относится к прежнему порядку очистки). Этот дефект нельзя приписывать появлению B++.

## Единственное исправление

`three-fixed.js` получен из неизменённого `three-stage2.js`. Полный точный before/after одного helper сохранён в `engine-patch.json`.

- Локальный WeakMap заменён перечислимым Map: кэш явно удерживает свои входы/выходы до source.dispose или завершения renderer.
- Dispose-listener добавляется и в dynamic/render-target ветке. Native EventDispatcher не дублирует один и тот же listener при повторном обновлении.
- При cache.dispose удаляется запись и source-listener, затем вызывается штатный output RenderTarget.dispose; после outputs освобождается PMREMGenerator.
- Живые outputs не освобождаются при get/update; нативные GL delete/refcount не подменялись. Повторное завершение не дало дополнительных delete.

`three-*-probe.js` отличаются только диагностическими callback после штатных cache/get/upload операций; самостоятельного cleanup в них нет. `graphics.js` добавляет только диагностический getter реальных входных owners. `scene.js`, `app.js`, `dispose-environment.js` скопированы без изменения обоих предыдущих lifecycle-fix. Оригинальные B+/B++ и production не менялись.

## Результаты счётчиков

Оконный Microsoft Edge, file://, High, shader checks=true, ANGLE D3D11 / RTX 3050 Laptop. Это lifecycle-измерение с удержанием native handles наблюдателем, не измерение памяти драйвера или скорости запуска.

| Запуск / цикл | Program C/D | Shader C/D | Framebuffer C/D | Texture C/D | Renderbuffer C/D |
|---|---:|---:|---:|---:|---:|
| B++ до исправления | 89/89 | 178/178 | 20/18 | 79/69 | 15/15 |
| Один исправленный цикл | 89/89 | 178/178 | 20/20 | 79/71 | 15/15 |
| Общий GL, цикл 1 | 89/89 | 178/178 | 20/20 | 79/71 | 15/15 |
| Общий GL, цикл 2 | 178/178 | 356/356 | 40/40 | 158/142 | 30/30 |
| Общий GL, цикл 3 | 267/267 | 534/534 | 60/60 | 237/213 | 45/45 |

Каждый исправленный output получил ровно один dispose; связанных native framebuffer/texture без delete не осталось. Двойных delete, обращений renderer к освобождённому output и WebGL errors не обнаружено. Pending promises, polling timers, pagehide handler и зарегистрированные программы после завершения — 0. Все 9990 buffer и 3342 VAO за три цикла получили delete. Один уже delete-requested текущий program и два attached shader остаются native-valid до смены binding; их число не растёт.

## Оставшийся рост: локализован, не исправлялся

`texture-owners.json` сопоставляет native allocation с настоящим Texture и материалами/шейдерными uniforms:

- **6 CanvasTexture 512×512** — `map` материалов building proxies в cube/water reflection passes. Кодовая цепочка: createFacadeResources создаёт `facadeMaterials[6]` → display передаёт их как `facades` → graphics выдаёт их proxyMaterials. Это ресурсы мира, заимствованные графикой. Graphics правильно удаляет свои proxy-materials без уничтожения заимствованных карт; текущий экспериментальный world-cleanup собирает текстуры только с основной сцены и пропускает эти шесть исходных facade maps. Их UUID/источники и связи с материалами сохранены; источник локализован, а не отнесён к PMREM.
- **2 внутренних WebGLState fallback texture** создаются при конструировании renderer (одна 2D и одна cube, стек `Fs → F`). Они не имеют прикладного Texture-owner. Такой остаток ранее наблюдался и при отмене/stock. Это внутренние ресурсы renderer на живом контексте, однако каждый новый renderer создаёт свою пару: здесь они **не исключены** из растущего счётчика как будто это один неизменный общий ресурс.

Итого после трёх окружений: 18 facade-native textures + 6 внутренних fallback textures = 24. При сильных диагностических ссылках они остаются native-valid, без запросов delete; вывод о необратимой утечке после закрытия контекста не делался.

Следующее действие требует отдельного задания: уточнить завершение world-owned facade textures и внутренних WebGLState ресурсов. В этой работе второй cleanup-fix не применялся.

## Сохранность и непроведённые проверки

`preservation-check.json` содержит повторную проверку 93 целевых ранее существовавших файлов (production, четыре shaderChecks-файла, оригинальный движок и исторические экспериментальные входы/результаты). Все совпали с `preserved-before.json`; исторические файлы не перезаписывались. Git HEAD остался `5cbd6f741415bf10d44b2a6088b9bc26e1916d50`, staged-пусто, прежние четыре изменения сохранены.

Пиксельная эквивалентность, RNG, Start/W и отмена после новой правки **не заявляются проверенными**: этап 4 запрещён до прохождения общего ресурсного критерия. Сохранность исходного исправления воды и прежних lifecycle-fix проверена по файлам/точечному diff. Полные build/check, производительные A/B, commit/push не выполнялись. Накладные расходы Map/listener на запуск не оценивались; скорость по инструментальным временам не заявляется.
