const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{pathToFileURL}=require('node:url');
const dir=__dirname,old=path.resolve(dir,'../r149-async-lifecycle-fix-20261020');
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const write=(n,s)=>{const f=path.join(dir,n);if(fs.existsSync(f)){if(!fs.readFileSync(f).equals(Buffer.from(s)))throw Error('Different existing artifact '+n);return;}fs.writeFileSync(f,s,{flag:'wx'});};
function once(s,a,b){if(s.split(a).length!==2)throw Error('Unique anchor: '+a);return s.replace(a,b);}
let engine=fs.readFileSync(path.join(old,'three-stage2.js'),'utf8');
const start=engine.indexOf('function qn(t){'),end=engine.indexOf('function Xn(t){',start);
if(start<0||end<0)throw Error('CubeUV boundaries');
const before=engine.slice(start,end);
// An enumerable cache owns the returned PMREM targets until source disposal or
// renderer teardown. Remove its source listeners before releasing the targets.
let after=once(before,'let e=new WeakMap,i=null','let e=new Map,i=null');
after=once(after,'function n(t){','function tbsDispose(t){');
after=once(after,'i.removeEventListener("dispose",n)','i.removeEventListener("dispose",tbsDispose)');
after=once(after,'l.addEventListener("dispose",n)','l.addEventListener("dispose",tbsDispose)');
after=once(after,'e.set(l,n),n.texture','e.set(l,n),l.addEventListener("dispose",tbsDispose),n.texture');
after=once(after,'dispose:function(){e=new WeakMap,null!==i&&(i.dispose(),i=null)}',
 'dispose:function(){for(const source of Array.from(e.keys()))tbsDispose({target:source});null!==i&&(i.dispose(),i=null)}');
write('engine-patch.json',JSON.stringify({base:sha(engine),before,after,reason:'CubeUV output targets are renderer-cache owned. Dispose via their native owners, including dynamic render-target inputs; detach source listeners and remove entries first. Existing renderer ordering keeps properties alive.'},null,2));
const fixed=engine.slice(0,start)+after+engine.slice(end);write('three-fixed.js',fixed);
function observeCubeUV(s){
 s=once(s,'e.set(l,n),n.texture','e.set(l,n),t.__pmremRecord?.(l,n,"update"),n.texture');
 s=once(s,'if(e.has(l))return e.get(l).texture','if(e.has(l))return t.__pmremRecord?.(l,e.get(l),"cached"),e.get(l).texture');
 return once(s,'e.set(l,r),l.addEventListener("dispose",n),r.texture','e.set(l,r),t.__pmremRecord?.(l,r,"initial"),l.addEventListener("dispose",n),r.texture');
}
write('three-before-probe.js',observeCubeUV(engine));
write('three-stock-probe.js',observeCubeUV(fs.readFileSync(path.resolve(dir,'../../assets/three.min.js'),'utf8')));
// Instrument the exact same cache in the fixed copy. These hooks only collect evidence.
let instrumented=once(fixed,'e.set(l,n),l.addEventListener("dispose",tbsDispose),n.texture','e.set(l,n),l.addEventListener("dispose",tbsDispose),t.__pmremRecord?.(l,n,"update"),n.texture');
instrumented=once(instrumented,'if(e.has(l))return e.get(l).texture','if(e.has(l))return t.__pmremRecord?.(l,e.get(l),"cached"),e.get(l).texture');
instrumented=once(instrumented,'e.set(l,r),l.addEventListener("dispose",tbsDispose),r.texture','e.set(l,r),t.__pmremRecord?.(l,r,"initial"),l.addEventListener("dispose",tbsDispose),r.texture');
write('three-fixed-probe.js',instrumented);
for(const name of ['app.js','app-stock-control.js','scene.js','dispose-environment.js'])write(name,fs.readFileSync(path.join(old,name)));
let graphics=fs.readFileSync(path.join(old,'graphics.js'),'utf8');
graphics=once(graphics,'renderer.__startupDispose=dispose;','renderer.__pmremSources=()=>({fastback:cubeTarget,quarter:quarterTarget});\n    renderer.__startupDispose=dispose;');
write('graphics.js',graphics);
for(const [name,eng,stock]of [['before','three-before-probe.js',false],['fixed','three-fixed-probe.js',false],['stock','three-stock-probe.js',true]]){
 let html=fs.readFileSync(path.join(old,stock?'index-stock.html':'index-stage2.html'),'utf8');
 html=html.split(pathToFileURL(old).href+'/').join(pathToFileURL(dir).href+'/');
 html=once(html,stock?pathToFileURL(path.resolve(dir,'../../assets/three.min.js')).href:pathToFileURL(path.join(dir,'three-stage2.js')).href,pathToFileURL(path.join(dir,eng)).href);
 write('index-'+name+'.html',html);
}
let observer=fs.readFileSync(path.join(old,'observe.js'),'utf8');
observer=once(observer,'handle:value,gl:this','handle:value,gl:this,stack:["framebuffer","texture"].includes(createKinds[name])?new Error().stack:undefined');
observer=once(observer,'phase:x.phase,deletes:x.deletes','phase:x.phase,deletes:x.deletes,stack:x.stack');
observer=once(observer,'d.world=result;const r=result.renderer;d.renderer=r;',`d.world=result;const r=result.renderer;d.renderer=r;
   d.pmrem=[];d.pmremOutputs=new Map();
   r.__pmremRecord=(source,target,branch)=>{
    let row=d.pmremOutputs.get(target);
    if(!row){
     const prop=r.properties.get(target),tex=r.properties.get(target.texture);
     row={source:source.uuid,target:target.uuid,output:target.texture.uuid,width:target.width,height:target.height,branches:{},disposeEvents:0,sourceDispose:0,
      framebuffer:d.objects.find(x=>x.handle===prop.__webglFramebuffer)?.id,texture:d.objects.find(x=>x.handle===tex.__webglTexture)?.id};
     d.pmremOutputs.set(target,row);d.pmrem.push(row);
     target.addEventListener('dispose',()=>{row.disposeEvents++;row.disposedAt=performance.now();});
     source.addEventListener('dispose',()=>row.sourceDispose++);
    }
    row.branches[branch]=(row.branches[branch]||0)+1;
    if(row.disposeEvents)d.events.push({name:'USE-AFTER-PMREM-DISPOSE',target:target.uuid});
    const sources=r.__pmremSources?.();if(sources)for(const [owner,input]of Object.entries(sources))if(input?.texture===source){row.owner=owner;row.inputTarget=input.uuid;}
   };`);
observer=once(observer,'scenario,phase:d.phase,pending:d.pending','scenario,pmrem:d.pmrem,phase:d.phase,pending:d.pending');
write('observe.js',observer);
console.log('Prepared one localized CubeUV fix and separate forwarding diagnostic hooks.');
