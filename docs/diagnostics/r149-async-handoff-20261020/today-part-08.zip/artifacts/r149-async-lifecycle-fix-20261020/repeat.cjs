const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,save=(n,j)=>fs.writeFileSync(path.join(dir,n),JSON.stringify(j,null,2),{flag:'wx'});
(async()=>{
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles','repeat'),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
  const page=context.pages()[0],errors=[],messages=[];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(['error','warning'].includes(m.type()))messages.push({type:m.type(),text:m.text()});});
  let observer=fs.readFileSync(path.join(dir,'observe.js'),'utf8');
  observer=observer.replace('handle:value,gl:this','handle:value,gl:this,stack:createKinds[name]===\'framebuffer\'?new Error().stack:undefined');
  observer=observer.replace('phase:x.phase,deletes:x.deletes','phase:x.phase,deletes:x.deletes,stack:x.stack');
  fs.writeFileSync(path.join(dir,'repeat-observer.js'),observer,{flag:'wx'});
  await page.addInitScript({content:'('+observer+')("A");'});
  await page.goto(pathToFileURL(path.join(dir,'index-stage2.html')).href,{waitUntil:'load',timeout:180000});
  const rows=[];
  for(let cycle=1;cycle<=3;cycle++){
   if(cycle>1)await page.evaluate(async()=>{
    const d=window.__lc,oldGL=d.renderer.getContext(),canvas=d.renderer.domElement;
    d.disposeCalls=0;d.mainFrames=0;d.phase='building';d.settled=null;d.postDispose=[];
    const api=window.TBS,dom=api.createDom(document),state=api.domain.createState(),presentation=api.createPresentationState(state);
    const world=api.buildWorld({T:THREE,canvas,config:api.domain.config}),{runtime}=api.buildGame({state,presentation,world,dom});
    d.sameContext=world.renderer.getContext()===oldGL;
    if(!d.sameContext)throw Error('GL context changed');
    installStartupEnvironmentCleanup(world,runtime);
    await world.renderer.compileAsyncPasses(world.renderer.__startupPasses(),{signal:new AbortController().signal});runtime.start();
   });
   await page.waitForFunction(()=>window.__lc?.mainFrames>=2,null,{timeout:150000});
   const before=await page.evaluate(()=>window.__lc.snapshot());
   const after=await page.evaluate(()=>{const d=window.__lc;d.renderer.__startupClose();return d.snapshot();});
   rows.push({cycle,sameContext:cycle===1?true:await page.evaluate(()=>window.__lc.sameContext),before,after});
   save('repeat-'+cycle+'.json',rows.at(-1));console.log(JSON.stringify({cycle,programs:after.rendererPrograms.length,byKind:after.byKind,pending:after.pending,timers:after.pollTimers,postDispose:after.postDispose.length,gl:after.glError}));
  }
  save('repeat-summary.json',{browser:context.browser().version(),rows,errors,messages,note:'Same canvas/native GL context, sequential actual world/game construction and compileAsyncPasses, native runtime frames. All environments explicitly closed. Instrumented lifecycle, not performance. No context loss or new GL cleanup.'});
 }catch(e){let snapshot;try{snapshot=await context.pages()[0].evaluate(()=>window.__lc?.snapshot());}catch{}save('repeat-failure.json',{error:e.stack,snapshot});throw e;}
 finally{await context.close();}
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
