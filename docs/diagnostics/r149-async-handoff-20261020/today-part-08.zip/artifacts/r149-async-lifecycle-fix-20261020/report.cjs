const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=__dirname,root=path.resolve(dir,'../..'),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n))),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const cancel=read('stage1-B.json'),stockTerminal=read('stage1-T.json'),normal=read('stage2-A.json'),stock=read('stage2-S.json'),cancel2=read('stage2-B.json'),repeat=read('repeat-summary.json');
const preserved={};for(const[p,h]of Object.entries(read('preserved-before.json'))){preserved[p]=sha(fs.readFileSync(path.join(root,p)))===h;if(!preserved[p])throw Error('Changed '+p);}
const rows=repeat.rows.map(r=>({cycle:r.cycle,sameContext:r.sameContext,registeredPrograms:r.after.rendererPrograms.length,programs:r.after.byKind.program,shaders:r.after.byKind.shader,framebuffers:r.after.byKind.framebuffer,textures:r.after.byKind.texture,buffers:r.after.byKind.buffer,renderbuffers:r.after.byKind.renderbuffer,checks:r.after.checks,GL:r.after.glError,pending:r.after.pending,pollTimers:r.after.pollTimers,postDispose:r.after.postDispose.length,submitted:r.before.stats.submitted}));
if(rows.some(r=>!r.sameContext||r.registeredPrograms||r.programs.unrequested||r.shaders.unrequested||r.programs.duplicateDeletes||r.shaders.duplicateDeletes||r.GL||r.pending||r.pollTimers||r.postDispose||r.submitted!==76))throw Error('Program/cancel regression');
const frames=repeat.rows.at(-1).after.objects.filter(o=>o.kind==='framebuffer'&&!o.deletes);
if(!frames.every(f=>f.stack?.includes('fromCubemap')&&f.stack?.includes('_textureToCubeUV')))throw Error('Unexpected framebuffer ownership');
const summary={decision:'Two original program/shader cleanup defects fixed in experimental copies; stopped on a third confirmed resource-lifecycle issue. No production approval.',stage1:{passed:true,cancelPrograms:cancel.settled.byKind.program,cancelShaders:cancel.settled.byKind.shader,stockTerminal:stockTerminal.settled.byKind,remainingPrograms:cancel.settled.rendererPrograms.length,sameAbortReason:cancel.settled.reason.sameAbort},stage2:{programOwnerFixPassed:true,remainingPrograms:normal.settled.rendererPrograms.length,programs:normal.settled.byKind.program,shaders:normal.settled.byKind.shader,idempotent:normal.idempotent,stockRemaining:stock.settled.rendererPrograms.reduce((o,p)=>(o[p.name]=(o[p.name]||0)+1,o),{}),cancelStillPasses:cancel2.settled.rendererPrograms.length===0},repeatedCycles:rows,newBlocker:{owner:'WebGLCubeUVMaps PMREM generated output render targets',retainedFramebuffers:rows.map(r=>r.framebuffers.unrequested),retainedTextures:rows.map(r=>r.textures.unrequested),framebufferEvidence:frames,interpretation:'Cache dispose discards WeakMap; PMREMGenerator.dispose frees scratch targets/materials, not output targets stored in CubeUV cache. Dynamic render-target branch does not attach source texture dispose listener. Direct native framebuffer creation stacks prove this category; remaining textures are not all attributed to PMREM.'},notExecuted:['controlled preparation error','no-KHR fallback','context loss','final first/moving/night/RNG/Start-W gate','performance A/B'],preserved};
fs.writeFileSync(path.join(dir,'summary.json'),JSON.stringify(summary,null,2),{flag:'wx'});
const rootEngine=fs.readFileSync(path.join(root,'assets/three.min.js'),'utf8'),engine=fs.readFileSync(path.join(dir,'three-stage2.js'),'utf8');
function uuid(s){const i=s.indexOf('function bt(){');return s.slice(i,s.indexOf('function St(',i));}
if(uuid(rootEngine)!==uuid(engine))throw Error('UUID changed');
const cacheStart=engine.indexOf('if(l.isRenderTargetTexture&&!0===l.needsPMREMUpdate)');fs.writeFileSync(path.join(dir,'cubeuv-owner-excerpt.txt'),engine.slice(cacheStart,engine.indexOf('function Xn(',cacheStart)),{flag:'wx'});
let text=`# B++: два исправления приняты по программам; остановка на новом остатке PMREM targets

HEAD/main: 5cbd6f741415bf10d44b2a6088b9bc26e1916d50. Только экспериментальные копии. Production не одобрена.

## Итог

**Два исходных дефекта освобождения shader/program исправлены последовательно.** После трёх циклов 267/267 programs и 534/534 shaders получили штатные запросы удаления, без повторных удалений и без правки usedTimes. Однако найден новый самостоятельный остаток native framebuffer: **2 → 4 → 6** на одном и том же живом GL-контексте. Владелец локализован: выходные CubeUV render targets кеша WebGLCubeUVMaps/PMREMGenerator. По условию задания третья правка не выполнялась, дальнейшие проверки остановлены.

## 1. Исправление пути отмены — отдельная приёмка

Прежний app catch останавливал runtime и вызывал renderer.dispose, пропуская graphics и материалы/геометрию завершённого окружения. Programs уже были зарегистрированы в renderer cache, pending-shaders принадлежали их WebGLProgram. Ручное gl.delete из prep нарушило бы владение.

В новом терминальном cleanup для **данного собственного экспериментального world**:

1. Останавливается runtime; active preparation уже rejected настоящим AbortController.
2. Через владельца graphics.dispose освобождаются его RT, post/proxy материалы и геометрия; borrowed world geometry/materials не освобождаются reflection-клонами.
3. Дедуплицируются собственные world materials/geometries/textures; InstancedMesh.dispose освобождает его собственные instance buffers, LightShadow.dispose — shadow targets.
4. Scene factory выдаёт ранее скрытый environment render target своему terminal owner, который вызывает его dispose. Render-target textures не уничтожаются как обычные текстуры.
5. У WebGLShadowMap добавлен узкий idempotent dispose для его **private материалов/геометрии/clone cache**, через Material.dispose → releaseProgram → destroy. Renderer-private программы не удаляются контроллером вручную.
6. Renderer.dispose вызывается последним. Ошибка cleanup сообщается отдельно; исходный preparation error снова выбрасывается без замены. Проверена идентичность abort reason; совпадение обычной ошибки с отменой ещё не проверено.

Ownership scope ограничен отдельным world, созданным этими фабриками: makeTexture/TextureLoader/material caches создаются внутри построения, глобальные embedded assets — изображения, а не чужие shared GPU owners. Этот helper нельзя автоматически переносить на будущий общий multi-world/shared-assets lifecycle. На успешном пути cleanup не вызывается; живой renderer сначала продолжил штатные реальные кадры.

Файлы: dispose-environment.js, app.js, graphics.js (только выдача существующего disposer), scene.js (выдача существующего environment RT), three-stage1.js (private ShadowMap owner disposer). Это один путь терминального освобождения окружения, не общий менеджер GL объектов.

| После настоящей отмены до готовности | Результат |
| --- | ---: |
| Create/deleteProgram | 79 / 79 |
| Create/deleteShader | 158 / 158 |
| Registered programs | 0 |
| Create/delete framebuffer | 10 / 10 |
| Create/delete renderbuffer | 8 / 8 |
| Create/delete buffer | 41 / 41 |
| Pending promises / poll timers / cancel handlers | 0 / 0 / 0 |
| Duplicate deletes / post-dispose program/draw calls / GL errors | 0 / 0 / 0 |

Отмена вызвана существующим pagehide handler → AbortController.abort после **реального false COMPLETION_STATUS_KHR**, не прекращением оснастки. Сохранён тот же объект signal.reason. graphics.dispose вызван один раз.

Контроль — оригинальный bundled r149 **A**, тот же построенный world/game, завершение до первого игрового кадра (у A нет асинхронной подготовки). Его programs 3/3, shaders 6/6; FBO/RBO/buffers освобождены полностью. И у A, и у исправленной отмены остаются две служебные renderer-state текстуры; native-valid current program и два attached shaders уже имеют delete request. Это обычная отсроченная GL-деаллокация, а не отсутствие вызова владельца. ForceContextLoss не использовался. stage1-acceptance.json зафиксирован до второго исправления.

## 2. Остаток 10 depth + 2 PMREM — второе исправление

10 depth удерживались private WebGLShadowMap материалами, не пользовательскими scene materials. Их штатный owner dispose введён в первом исправлении, поскольку он нужен и отмене pending batch.

2 PMREM program maps терялись при раннем properties.dispose: последующий cubeuvmaps.dispose → PMREMGenerator.dispose → Material.dispose уже не видел прежних renderer property maps. Проверено в сохранённом официальном r149 WebGLRenderer/WebGLPrograms и соответствующих minified путях. WebGLPrograms.dispose сам очищает custom shader cache, не все native programs; никакие refcounts вручную не правились.

Второе исправление — порядок terminal renderer disposal: private ShadowMap и cube maps/PMREM owners завершаются **до** очистки material properties. Private ShadowMap.dispose idempotent. Точная единственная замена — stage2-engine-patch.json. Пользовательские продолжающие жить материалы не принудительно уничтожаются внутри renderer.dispose.

Настоящий High/render через file:// сначала выполнил два main кадра; программы до teardown оставались native-valid. Затем terminal cleanup: **89/89 programs, 178/178 shaders**, registered programs=0, все buffers/VAO/RBO освобождены, checks=true, GL error=0. Повторный вызов того же cleanup не изменил счётчики. Отмена после второй правки повторно дала programs 79/79 и shaders158/158.

Нормальный контроль A на том же типе завершения оставил 16 program entries (14 depth, 2 PMREM). Это подтверждает штатное удержание r149 private owners, а не уникальный баг native delete в B++. Исправление освобождает собственные завершённые private owners и не сбрасывает usedTimes ради нулевого счётчика. Current GL binding с уже запрошенным удалением не считался пропущенным release.

## 3. Три повторных цикла и новый дефект

Оконный Edge ${repeat.browser}, RTX 3050 Laptop / ANGLE D3D11, High, file://. Каждый цикл создавал настоящий world/game/renderer на **том же canvas и native GL context**, выполнял текущую compileAsyncPasses, штатный runtime и два main кадра, затем terminal cleanup. Не новая страница/контекст на каждый цикл. Состав подготовки 76/76/76; polling, shaders, RNG/UUID и вода не менялись. Это instrumented lifecycle, не performance benchmark.

| Цикл | programs create/delete | shaders create/delete | Registered | framebuffer create/delete | FBO без delete | Textures без delete |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
`;
for(const r of rows)text+=`| ${r.cycle} | ${r.programs.created}/${r.programs.deleteCalls} | ${r.shaders.created}/${r.shaders.deleteCalls} | ${r.registeredPrograms} | ${r.framebuffers.created}/${r.framebuffers.deleteCalls} | ${r.framebuffers.unrequested} | ${r.textures.unrequested} |\n`;
text+=`
Буферы 9990/9990, renderbuffers45/45, VAO3342/3342 после третьего цикла. Двойных удалений нет. Pending/timers=0; program/draw обращений после terminal dispose=0. GL errors=0, checks=true. Остаток program/shader native validity не растёт: одна текущая программа и два shaders с delete request после каждого цикла.

**Новый блокер:** стеки всех шести неосвобождённых framebuffer ведут в renderer.setRenderTarget → PMREMGenerator._textureToCubeUV → _fromTexture → fromCubemap → WebGLCubeUVMaps.get. См. repeat-1/2/3.json, summary.json и cubeuv-owner-excerpt.txt.

Динамический CubeUV cache сохраняет выходные targets в WeakMap. Его dispose сбрасывает WeakMap и уничтожает PMREMGenerator scratch targets/materials, но не выходные cached targets. В dynamic render-target branch также не устанавливается source-texture dispose listener, имеющийся в другой ветке. Это отдельное владение **render targets**, не вновь оставшиеся shaders/programs. Дополнительные 10/20/30 native textures не все приписываются этим targets: две на renderer относятся к служебному stock state; остальные категории полностью не локализовывались после условия остановки. Для блокировки достаточно доказанного стабильного +2 framebuffer на цикл, с конкретными стеками и отсутствием живого renderer-владельца.

Strong диагностические references позволяют проверить explicit delete и native validity и могут мешать автоматическому GC. Рост кеша драйвера/системной GPU-памяти не использовался как доказательство. Утечка после окончательного уничтожения страницы/контекста не утверждается. После сохранения данных браузер штатно закрыт; это не засчитывалось как исправление in-page lifecycle.

## 4. Функциональность и незакрытые требования

Выполнены нормальное построение сцены и реальные High/main/reflection/post кадры, shader checks и GL checks. Терминальные исправления не меняют состав программ или normal preparation. Исходная UUID-функция побитово совпадает с original Three; прежний water/RNG код сохранён. Это проверка сохранности кода, **не новый полный RNG/визуальный gate**.

После нового дефекта повторные Start/W, первый/moving/night, детерминированная RNG sequence и error/no-KHR проверки не запускались. Последние разрешались только после успешных повторных циклов. Context loss, окончательная скорость против штатного A и production-визуальная/функциональная приёмка также остаются непроверенными. Performance A/B не проводился: исправления касаются terminal cleanup, critical async wait/compile path не менялся.

Ошибок страницы нет. Шесть console warnings в трёх циклах — прежнее PMREM sigma0.05/max20 предупреждение (два на world); графические параметры ради его устранения не менялись.

**Третьего исправления нет. Production-интеграция остаётся запрещённой.**

## 5. Сохранность

Совпали ${Object.keys(preserved).length} выбранных исторических/production SHA-256. B+, исходный B++, original bundled r149, четыре shaderChecks-файла и прежняя диагностика сохранены. Все новые файлы только здесь. HEAD/main прежние; индекс пуст; Git status: три прежних M scene.ts/dist scene.js/rendering-contracts.d.ts и прежний ?? tests/shader-checks.test.cjs. Build/check, commit/push не выполнялись. git diff --check проверен отдельно.
`;
fs.writeFileSync(path.join(dir,'report.md'),text,{flag:'wx',encoding:'utf8'});
const files=['three-stage1.js','three-stage2.js','stage1-engine-patch.json','stage2-engine-patch.json','dispose-environment.js','app.js','graphics.js','scene.js','observe.js','repeat.cjs'];
fs.writeFileSync(path.join(dir,'provenance.json'),JSON.stringify({head:'5cbd6f741415bf10d44b2a6088b9bc26e1916d50',fixes:2,thirdFix:false,productionChanged:false,hashes:Object.fromEntries(files.map(n=>[n,sha(fs.readFileSync(path.join(dir,n)))])),uuidUnchanged:true},null,2),{flag:'wx'});
console.log(JSON.stringify({programsFixed:true,repeats:rows.map(r=>({cycle:r.cycle,programs:r.programs.created+'/'+r.programs.deleteCalls,shaders:r.shaders.created+'/'+r.shaders.deleteCalls,FBO:r.framebuffers.unrequested})),preserved:Object.keys(preserved).length,stop:'New CubeUV target ownership defect; no third fix'}));
