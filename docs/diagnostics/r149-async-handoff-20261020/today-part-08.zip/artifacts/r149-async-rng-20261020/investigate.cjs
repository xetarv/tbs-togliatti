const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,root=path.resolve(dir,'../..'),prior=path.join(root,'artifacts/r149-async-late-programs-20261020'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const baseline=JSON.parse(fs.readFileSync(path.join(prior,'preserved-before.json')));for(const file of ['three-r149-async-plus.min.js','engine-patch.json','report.md','run-bp.cjs','verify-visual.cjs'])baseline[path.relative(root,path.join(prior,file))]=sha(fs.readFileSync(path.join(prior,file)));
fs.writeFileSync(path.join(dir,'preserved-before.json'),JSON.stringify(baseline,null,2),{flag:'wx'});
async function run(mode){
 let engine=fs.readFileSync(path.join(prior,mode==='B'?'three-r149-async.min.js':'three-r149-async-plus.min.js'),'utf8');
 const before='r=h.clone(),n[e]=r',after='r=window.__observeDepthClone(h,e,i,()=>h.clone()),n[e]=r';
 if(engine.split(before).length!==2)throw Error('Clone instrumentation anchor');engine=engine.replace(before,after);
 const engineFile=path.join(dir,'observed-'+mode+'.js');fs.writeFileSync(engineFile,engine,{flag:'wx'});
 let html=fs.readFileSync(path.join(prior,'index-'+mode+'.html'),'utf8').replace(pathToFileURL(path.join(prior,mode==='B'?'three-r149-async.min.js':'three-r149-async-plus.min.js')).href,pathToFileURL(engineFile).href);
 const htmlFile=path.join(dir,'observed-'+mode+'.html');fs.writeFileSync(htmlFile,html,{flag:'wx'});
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles','observe-'+mode),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 try{
 const page=context.pages()[0];await page.addInitScript(()=>{
  window.__evidence={seed:72421,calls:0,clones:[],phase:'construction',preparation:null};const d=window.__evidence;let active,registry;
  // Deterministic test observer only. Never installed in the candidate or timed runs.
  Math.random=()=>{const stack=active?new Error().stack:null;d.seed=(Math.imul(d.seed,1664525)+1013904223)>>>0;d.calls++;if(active)active.calls.push({index:d.calls,stack});return d.seed/4294967296;};
  window.__observeDepthClone=(base,object,material,clone)=>{
   const row={phase:d.phase,object:{type:object.type,name:object.name,position:object.position.toArray(),geometry:object.geometry.type},source:{uuid:material.uuid,type:material.type,name:material.name,alphaTest:material.alphaTest,map:material.map?.uuid,alphaMap:material.alphaMap?.uuid,side:material.side},base:{uuid:base.uuid,type:base.type},calls:[]};active=row;
   try{const result=clone();row.resultUUID=result.uuid;return result;}finally{active=null;d.clones.push(row);}
  };
  localStorage.setItem('tbs.graphicsQuality','high');
  Object.defineProperty(window,'TBS',{get:()=>registry,set(api){registry=api;for(const name of ['buildWorld','createRuntime']){let fn;Object.defineProperty(api,name,{get:()=>fn,set(original){fn=function(...args){const result=Reflect.apply(original,this,args);if(name==='buildWorld'){window.__world=result;const r=result.renderer,p=r.compileAsyncPasses;r.compileAsyncPasses=async function(...a){d.phase='preparation';try{return await Reflect.apply(p,this,a);}finally{d.preparation={seed:d.seed,calls:d.calls};d.phase='first-render';}};}if(name==='createRuntime'){window.__game=args[0].game;return{...result,start(){window.__game.initialize();window.__game.step(1/60);d.phase='after-first';window.__done=true;}};}return result;};}});}}});
 });
 const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(pathToFileURL(htmlFile).href,{waitUntil:'load',timeout:180000});await page.waitForFunction(()=>window.__done,null,{timeout:180000});
 const data=await page.evaluate(()=>({evidence:window.__evidence,programs:window.__world.renderer.info.programs.map(p=>({key:p.cacheKey,name:p.name})),debug:window.__world.renderer.debug.checkShaderErrors,glError:window.__world.renderer.getContext().getError()}));
 fs.writeFileSync(path.join(dir,'observed-'+mode+'.json'),JSON.stringify({mode,errors,...data},null,2),{flag:'wx'});
 if(errors.length||data.glError||!data.debug)throw Error('Invalid observer run');console.log(JSON.stringify({mode,calls:data.evidence.calls,clones:data.evidence.clones.length,preparation:data.evidence.preparation,errors}));
 }finally{await context.close();}
}
(async()=>{await run('B');await run('P');const a=JSON.parse(fs.readFileSync(path.join(dir,'observed-B.json'))),b=JSON.parse(fs.readFileSync(path.join(dir,'observed-P.json')));const keys=new Set(a.evidence.clones.map(c=>c.source.uuid));const extra=b.evidence.clones.filter(c=>!keys.has(c.source.uuid));const result={allExtraCalls:extra.flatMap(c=>c.calls),extraClones:extra,callDelta:b.evidence.calls-a.evidence.calls,baselineClones:a.evidence.clones.length,candidateClones:b.evidence.clones.length,allCloneCallCounts:b.evidence.clones.map(c=>c.calls.length)};fs.writeFileSync(path.join(dir,'rng-cause.json'),JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify({delta:result.callDelta,extra:extra.length,calls:result.allExtraCalls.length}));})().catch(e=>{console.error(e.stack);process.exitCode=1;});
