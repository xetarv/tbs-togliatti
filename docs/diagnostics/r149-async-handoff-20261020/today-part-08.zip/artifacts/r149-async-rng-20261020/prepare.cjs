const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{pathToFileURL}=require('node:url');
const dir=__dirname,root=path.resolve(dir,'../..'),prior=path.join(root,'artifacts/r149-async-late-programs-20261020'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
let engine=fs.readFileSync(path.join(prior,'three-r149-async-plus.min.js'),'utf8');const before=engine,patches=[];
function replace(a,b){if(engine.split(a).length!==2)throw Error('Nonunique anchor '+a.slice(0,70));engine=engine.replace(a,b);patches.push({before:a,after:b});}
// Private renderer material is sufficient for parameter/cache acquisition.
// Keep unique material clones lazy for actual stock shadow draws.
replace('function _(e,i,n,r,s,a){let h=null;','function _(e,i,n,r,s,a,tbsPrepareOnly=false){let h=null;');
replace('if(h=!0===n.isPointLight?l:o,t.localClippingEnabled','if(h=!0===n.isPointLight?l:o,!tbsPrepareOnly&&(t.localClippingEnabled');
replace('i.map&&i.alphaTest>0){const t=h.uuid','i.map&&i.alphaTest>0)){const t=h.uuid');
replace('_(object,material,light,shadow.camera.near,shadow.camera.far,this.type),object);','_(object,material,light,shadow.camera.near,shadow.camera.far,this.type,true),object);');
fs.writeFileSync(path.join(dir,'three-r149-async-plusplus.min.js'),engine,{flag:'wx'});
fs.writeFileSync(path.join(dir,'engine-patch.json'),JSON.stringify({baselineSHA256:sha(before),candidateSHA256:sha(engine),patches,reason:'Defer unique depth material clones until stock real shadow drawing; preparation uses existing private depth/distance material, same selector parameter copy and native program cache. No RNG/UUID change, reset or override.'},null,2),{flag:'wx'});
for(const name of ['three-r149-async.min.js','three-r149-async-plus.min.js','graphics-experimental.js','app-experimental.js','probe.js','menu-probe-final.js','program-observer.js','png.cjs'])fs.copyFileSync(path.join(prior,name),path.join(dir,name),fs.constants.COPYFILE_EXCL);
for(const mode of ['B','P','Q']){
 let html=fs.readFileSync(path.join(root,'index.html'),'utf8').replace('<head>','<head>\n<base href="'+pathToFileURL(root+path.sep).href+'">');
 const names={B:'three-r149-async.min.js',P:'three-r149-async-plus.min.js',Q:'three-r149-async-plusplus.min.js'};
 for(const [old,name]of [['assets/three.min.js',names[mode]],['dist/adapters/rendering/graphics.js','graphics-experimental.js'],['dist/app.js','app-experimental.js']])html=html.replace('src="'+old+'"','src="'+pathToFileURL(path.join(dir,name)).href+'"');
 fs.writeFileSync(path.join(dir,'index-'+mode+'.html'),html,{flag:'wx'});
}
let visual=fs.readFileSync(path.join(prior,'verify-visual.cjs'),'utf8');
visual=visual.replace("[['A1','B'],['B','P'],['C','P'],['A2','B']]","[['A1','P'],['B','Q'],['C','B'],['A2','P']]");
visual=visual.replace("window.__captureNonce=nonce;","window.__captureNonce=nonce;window.__futureStates=[];window.__audioBuffers=[];const create=AudioContext.prototype.createBuffer;AudioContext.prototype.createBuffer=function(...args){const result=Reflect.apply(create,this,args);window.__audioBuffers.push(result);return result;};");
visual=visual.replace('try{for(let i=0;i<steps;i++)window.__game.step(1/60);}',`try{for(let i=0;i<steps;i++){window.__game.step(1/60);if((totalSteps-steps+i+1)%30===0)window.__futureStates.push({step:totalSteps-steps+i+1,rng:{...window.__rng},state:JSON.parse(JSON.stringify(window.__state)),traffic:JSON.parse(JSON.stringify(window.__traffic))});}}`);
visual=visual.replace('return{waterState,observation,nonce:',"const audio=window.__audioBuffers.map(b=>({length:b.length,sampleRate:b.sampleRate,head:Array.from(b.getChannelData(0).slice(0,64))}));return{futureStates:window.__futureStates,audio,waterState,observation,nonce:");
fs.writeFileSync(path.join(dir,'verify-visual.cjs'),visual,{flag:'wx'});
let runner=fs.readFileSync(path.join(prior,'run-bp.cjs'),'utf8');
runner=runner.replace("const orders=[['B','P'],['P','B'],['B','P']]","const orders=[['P','Q'],['Q','P']]");
runner=runner.replaceAll("'late'","'rng'").replace('cycle1 B/B+; cycle2 B+/B; optional cycle3 B/B+','cycle1 B+/B++; optional cycle2 B++/B+');
fs.writeFileSync(path.join(dir,'run-pq.cjs'),runner,{flag:'wx'});
console.log(JSON.stringify({patches:patches.length,sha:sha(engine)}));
