const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),zlib=require('node:zlib');
const {pathToFileURL}=require('node:url'),{execFileSync}=require('node:child_process'),{chromium}=require('playwright-core');
const {decode,button}=require('./png.cjs');const dir=__dirname,root=path.resolve(dir,'../..'),save=(n,j)=>fs.writeFileSync(path.join(dir,n),JSON.stringify(j,null,2));
const edge='C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe';
const args=['--use-angle=d3d11','--enable-webgl','--enable-precise-memory-info','--window-position=40,40','--window-size=1100,900'];
const gpu=()=>execFileSync('C:/Windows/system32/nvidia-smi.exe',['--query-gpu=name,driver_version,memory.total,pstate,temperature.gpu','--format=csv,noheader'],{encoding:'utf8'}).trim();
save('conditions-abc.json',{base:'5cbd6f741415bf10d44b2a6088b9bc26e1916d50',cpu:os.cpus()[0].model,ramGiB:os.totalmem()/2**30,edge,headless:false,args,viewport:'native maximized window',dpr:'native, measured per run',quality:'high',url:pathToFileURL(path.join(root,'index.html')).href,order:'cycle1 B+/B++; optional cycle2 B++/B+; own new profile then same profile restart per variant',note:'New independent profile per pair; browser restart retains only its own profile. No cache clearing or shader/batch flag. Real headed Edge; screencast is compositor output, not physical panel scanout. Native timer probe and trace enabled equally in B and B+. New profile does not imply cold system/GPU cache.'});
async function run(pair,warm,mode,prefix="ab"){
 const name=`${prefix}-${pair}-${mode}-${warm?'warm':'fresh'}`;if(fs.existsSync(path.join(dir,name+'.json')))throw Error('Refusing to overwrite '+name);console.log('START '+name);
 const before={epoch:Date.now(),gpu:gpu(),freeRAM:os.freemem()/2**30};
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles',prefix+'-'+pair+'-'+mode),{executablePath:edge,headless:false,viewport:null,args,ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 const page=context.pages()[0]||await context.newPage(),cdp=await context.newCDPSession(page),browser=await context.browser().newBrowserCDPSession();
 const signals=[],frames=[],actions=[],errors=[],warnings=[];let menuFrame,buttonFrame,visualResponse,menuRect,registered=false,attempts=0,successful=false,keySent=false,frameCount=0,kept=0,streaming=true,lastHash;
 let rejectFailure;const failure=new Promise((_,reject)=>{rejectFailure=reject;});failure.catch(()=>{});
 page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());if(m.type()==='warning'&&warnings.length<12)warnings.push(m.text());});
 const sendClick=()=>{
  if(!menuRect||successful||attempts>=2)return;
  const n=++attempts,x=(menuRect.x0+menuRect.x1)/2,y=(menuRect.y0+menuRect.y1)/2,epoch=Date.now();actions.push({kind:'mouse-attempt',n,epoch,x,y});
  const events=[{type:'mouseMoved',x,y},{type:'mousePressed',button:'left',clickCount:1,x,y},{type:'mouseReleased',button:'left',clickCount:1,x,y}];
  Promise.all(events.map(e=>cdp.send('Input.dispatchMouseEvent',{...e,timestamp:Date.now()/1000}))).then(async()=>{actions.push({kind:'mouse-ack',n,epoch:Date.now()});if(!successful&&registered&&attempts<2){const r=await page.locator('#startBtn').boundingBox();if(r){menuRect={x0:r.x,x1:r.x+r.width,y0:r.y,y1:r.y+r.height};sendClick();}}}).catch(rejectFailure);
 };
 await cdp.send('Runtime.enable');await cdp.send('Runtime.addBinding',{name:'__menuSignal'});
 cdp.on('Runtime.bindingCalled',e=>{
  if(e.name!=='__menuSignal')return;const s=JSON.parse(e.payload);s.receivedEpoch=Date.now();signals.push(s);
  if(s.kind==='registered'){registered=true;if(menuFrame&&attempts===1&&!successful&&signals.some(v=>v.kind==='click-result'&&!v.success))sendClick();}
  if(s.kind==='click-result'){
   if(s.success){successful=true;if(!keySent){keySent=true;actions.push({kind:'W-request',epoch:Date.now()});cdp.send('Input.dispatchKeyEvent',{type:'keyDown',key:'w',code:'KeyW',windowsVirtualKeyCode:87,timestamp:Date.now()/1000}).catch(rejectFailure);}}
   else if(registered&&attempts<2)sendClick();
  }
 });
 cdp.on('Page.screencastFrame',e=>{
  cdp.send('Page.screencastFrameAck',{sessionId:e.sessionId}).catch(()=>{});if(!streaming)return;
  try{
   const bytes=Buffer.from(e.data,'base64'),hash=crypto.createHash('sha256').update(bytes).digest('hex');
   const row={index:++frameCount,metadata:e.metadata,receivedEpoch:Date.now(),sha256:hash};frames.push(row);
   const imageStart=Date.now(),image=decode(bytes),rect=button(image);row.hostPngDecodeAndButtonMs=Date.now()-imageStart;row.opticalButton=rect;const cssRect=rect?{x0:rect.x0*e.metadata.deviceWidth/image.w,x1:rect.x1*e.metadata.deviceWidth/image.w,y0:rect.y0*e.metadata.deviceHeight/image.h,y1:rect.y1*e.metadata.deviceHeight/image.h}:null;row.imageSize={w:image.w,h:image.h};if(cssRect&&!successful)menuRect=cssRect;
   let orange=0;for(let y=Math.floor(image.h*.06);y<image.h*.4;y+=2)for(let x=Math.floor(image.w*.25);x<image.w*.75;x+=2){const i=(y*image.w+x)*image.bpp;if(image.pixels[i]>225&&image.pixels[i+1]<170&&image.pixels[i+2]<130)orange++;}row.opticalMenu=orange>500;const firstMenu=!menuFrame&&row.opticalMenu,firstButton=menuFrame&&!buttonFrame&&rect&&row.index>menuFrame.index,success=signals.find(s=>s.kind==='click-result'&&s.success);
   const response=menuFrame&&!visualResponse&&!rect&&success&&e.metadata.timestamp*1000>=success.timeOrigin+success.s;
   if((hash!==lastHash&&kept<6)||firstMenu||response){row.file=`${name}-frame-${row.index}.png`;fs.writeFileSync(path.join(dir,row.file),bytes);kept++;}lastHash=hash;
   if(firstMenu){menuFrame=row;console.log('MENU FRAME '+name+' '+row.index);actions.push({kind:'wheel-request',epoch:Date.now()});cdp.send('Input.dispatchMouseEvent',{type:'mouseWheel',x:e.metadata.deviceWidth/2,y:e.metadata.deviceHeight*.7,deltaX:0,deltaY:420,timestamp:Date.now()/1000}).catch(rejectFailure);}if(firstButton){buttonFrame=row;menuRect=cssRect;sendClick();}
   if(response)visualResponse=row;
  }catch(err){errors.push('Screencast: '+err.stack);rejectFailure(err);}
 });
 try{
  const system=await browser.send('SystemInfo.getInfo');let commandLine;
  try{commandLine=await browser.send('Browser.getBrowserCommandLine');}catch(e){commandLine={unavailable:e.message,configuredArguments:args};}
  const {targetInfo}=await cdp.send('Target.getTargetInfo');
  let bounds=await browser.send('Browser.getWindowForTarget',{targetId:targetInfo.targetId});await browser.send('Browser.setWindowBounds',{windowId:bounds.windowId,bounds:{windowState:'maximized'}});bounds=await browser.send('Browser.getWindowForTarget',{targetId:targetInfo.targetId});
  await page.addInitScript({path:path.join(dir,'probe.js')});await page.addInitScript({path:path.join(dir,'menu-probe-final.js')});await page.addInitScript({path:path.join(dir,'program-observer.js')});
  await page.bringToFront();await cdp.send('Page.enable');
  await browser.send('Tracing.start',{categories:'toplevel,devtools.timeline,blink.user_timing,loading',transferMode:'ReturnAsStream'});
  await cdp.send('Page.startScreencast',{format:'png',maxWidth:1600,maxHeight:1000,everyNthFrame:1});
  const navigation={requestEpoch:Date.now()};
  await page.goto(pathToFileURL(path.join(dir,'index-'+mode+'.html')).href,{waitUntil:'domcontentloaded',timeout:180000});navigation.domContentLoadedObservedEpoch=Date.now();
  await Promise.race([page.waitForFunction(()=>window.__bootDiag?.controlReady!=null,null,{timeout:90000}),failure]);
  await page.waitForTimeout(300);streaming=false;await cdp.send('Page.stopScreencast');
  await page.waitForTimeout(1700);await cdp.send('Input.dispatchKeyEvent',{type:'keyUp',key:'w',code:'KeyW',windowsVirtualKeyCode:87,timestamp:Date.now()/1000});await page.waitForTimeout(8000);
  const data=await page.evaluate(()=>{
   const d=window.__bootDiag,r=d.world.renderer,g=r.getContext(),ext=g.getExtension('WEBGL_debug_renderer_info'),b=document.getElementById('startBtn').getBoundingClientRect();
   return{programObservation:window.__programDiag.snapshot(r),timeOrigin:performance.timeOrigin,menu:window.__menuDiag,rows:d.rows,gl:d.gl,longtasks:d.longtasks,anchor:d.anchor,modifiedRenderer:d.modifiedRenderer,preparationCalls:d.preparationCalls,spanBookkeepingMs:d.spanBookkeepingMs,spanBookkeepingAtControlMs:d.spanBookkeepingAtControlMs,firstRender:d.firstRender,firstWater:d.firstWater,firstGPU:d.firstGPU,controlReady:d.controlReady,startEvent:d.startEvent,keyRequested:d.keyRequested,end:performance.now(),mode:d.state.mode,player:{x:d.state.player.x,z:d.state.player.z,speed:d.state.player.speed},debug:r.debug.checkShaderErrors,nav:performance.getEntriesByType('navigation').map(p=>p.toJSON()),paint:performance.getEntriesByType('paint').map(p=>p.toJSON()),scripts:performance.getEntriesByType('resource').filter(p=>p.initiatorType==='script').map(p=>p.toJSON()),geometryAfterHidden:{x:b.x,y:b.y,width:b.width,height:b.height},webgl:{renderer:g.getParameter(ext.UNMASKED_RENDERER_WEBGL),revision:THREE.REVISION,version:g.getParameter(g.VERSION),width:g.drawingBufferWidth,height:g.drawingBufferHeight,quality:d.ports.graphics.quality},window:{innerWidth,innerHeight,outerWidth,outerHeight,dpr:devicePixelRatio,screen:{width:screen.width,height:screen.height,availWidth:screen.availWidth,availHeight:screen.availHeight},visibility:document.visibilityState,focus:document.hasFocus()},glError:g.getError()};
  });
  const completed=new Promise(resolve=>browser.once('Tracing.tracingComplete',resolve));await browser.send('Tracing.end');const {stream}=await completed;
  let trace='';for(;;){const chunk=await browser.send('IO.read',{handle:stream});trace+=chunk.data;if(chunk.eof)break;}await browser.send('IO.close',{handle:stream});fs.writeFileSync(path.join(dir,name+'.trace.json.gz'),zlib.gzipSync(trace));
  const origin=data.timeOrigin;for(const f of frames)f.pageMs=f.metadata.timestamp==null?null:f.metadata.timestamp*1000-origin;
  save(name+'.json',{name,pair,warm,mode,before,after:{gpu:gpu()},browser:context.browser().version(),system,commandLine,bounds,navigation,signals,frames,actions,menuFrameIndex:menuFrame?.index,buttonFrameIndex:buttonFrame?.index,visualResponseIndex:visualResponse?.index,errors,warnings,...data});
  console.log(JSON.stringify({name,menu:menuFrame?.pageMs,registered:data.menu.registeredAt,first:data.firstRender.e,gpu:data.firstGPU,click:data.menu.successes.find(s=>s.success)?.s,visibleResponse:visualResponse?.pageMs,control:data.controlReady,frames:frames.length,errors:errors.length,debug:data.debug,focus:data.window.focus,programs:data.programObservation.created.length,prepared:data.programObservation.prepared?.submitted,used:data.programObservation.used.length}));
  if(data.preparationCalls!==1||data.modifiedRenderer!==true)throw Error('Incorrect control variant '+mode);
  if(!menuFrame||!successful||errors.length||data.glError||!data.debug||data.webgl.quality!=='high'||!data.webgl.renderer.includes('RTX 3050')||data.window.visibility!=='visible')throw Error('Run validation failed '+name);
 }catch(e){save(name+'-failure-'+Date.now()+'.json',{error:e.stack,signals,frames,actions,errors});throw e;}
 finally{streaming=false;await context.close();}
}
(async()=>{const cycle=Number(process.argv[2]||1);const orders=[['P','Q'],['Q','P']];for(let pair=cycle;pair<=cycle;pair++)for(const mode of orders[pair-1]){if(process.argv[3]!=='warm-only')await run(pair,false,mode,'rng');await run(pair,true,mode,'rng');}})().catch(e=>{console.error(e.stack);process.exitCode=1;});
