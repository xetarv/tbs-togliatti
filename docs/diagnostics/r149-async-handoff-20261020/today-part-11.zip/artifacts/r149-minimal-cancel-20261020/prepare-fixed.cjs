const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');const dir=__dirname,root=path.resolve(dir,'../..'),prior=path.join(root,'artifacts/r149-final-comparison-20261020'),boundary=path.join(root,'artifacts/r149-context-boundary-20261020'),timing=path.join(root,'artifacts/r149-diagnostic-timing-20261020');
const put=(n,b)=>fs.writeFileSync(path.join(dir,n),b,{flag:'wx'}),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const source=fs.readFileSync(path.join(boundary,'three-stage2.js'),'utf8');
const before='this.destroy=function(){if(T===undefined){a.deleteShader(S);a.deleteShader(w);}n.releaseStatesOfProgram(this),a.deleteProgram(x),this.program=void 0}';
const after=`this.destroy=function(){
 // A pending native link must retire while its program handle is still alive.
 // This is a completion fence, not a timeout, refcount edit, or error suppression.
 if(T===undefined&&!a.isContextLost()){
  const linked=a.getProgramParameter(x,35714);
  if(linked===false&&t.debug.checkShaderErrors)tbsFirstUse();
 }
 if(T===undefined){a.deleteShader(S);a.deleteShader(w);}
 n.releaseStatesOfProgram(this),a.deleteProgram(x),this.program=void 0}`;
if(source.split(before).length!==2)throw Error('Expected one exact WebGLProgram.destroy');
const fixed=source.replace(before,after);put('three-retire-safe.js',fixed);put('retirement-patch.json',{source:path.join(boundary,'three-stage2.js'),beforeSHA256:sha(source),afterSHA256:sha(fixed),before,after,scope:'Only unreflected live-context program destruction; query LINK_STATUS before any native delete, retain original diagnostics if linking failed.'}&&JSON.stringify({source:path.join(boundary,'three-stage2.js'),beforeSHA256:sha(source),afterSHA256:sha(fixed),before,after},null,2));
let html=fs.readFileSync(path.join(boundary,'index-safe.html'),'utf8');const oldURL='file:///'+path.join(boundary,'three-stage2.js').replaceAll('\\','/'),newURL='file:///'+path.join(dir,'three-retire-safe.js').replaceAll('\\','/');if(!html.includes(oldURL))throw Error('Engine script not found');html=html.replace(oldURL,newURL);put('index-fixed.html',html);
const fixedURL=path.join(dir,'index-fixed.html');
put('observe.js',fs.readFileSync(path.join(timing,'observe-cancel.js')));
let check=fs.readFileSync(path.join(prior,'check.cjs'),'utf8');
const variants=JSON.parse(fs.readFileSync(path.join(prior,'preserved-before.json'))).variants;const fixedVariants={...variants,Safe:fixedURL};
check=check.replace(JSON.stringify(variants),JSON.stringify(fixedVariants));
check=check.replace("||failed.snapshot.glError||failed.snapshot.operationErrors.length||failed.snapshot.events.some(e=>e.name==='cancel-entry-error'&&e.code)","||failed.snapshot.glError||failed.snapshot.glErrors.length");
const start=check.indexOf("(process.argv[2]==='cancel'?"),end=check.indexOf('))await run(label,mode,html)',start);if(start<0||end<0)throw Error('Check anchors');
check=check.slice(0,start)+"(process.argv[2]==='cancel'?[['fixed-cancel-1','B','Safe'],['fixed-cancel-2','B','Safe'],['fixed-cancel-3','B','Safe']]:[['fixed-normal','N','Safe'],['fixed-loss-pending','E','Safe'],['fixed-loss-ready','L','Safe']])"+check.slice(end+1);
check=check.replace("if(errors.length)throw Error", "if(messages.some(m=>m.text.includes('GL_INVALID')))throw Error('Native WebGL warning');if(errors.length)throw Error");
put('check-fixed.cjs',check);
for(const n of ['png.cjs','program-observer.js'])put(n,fs.readFileSync(path.join(prior,n)));
let visual=fs.readFileSync(path.join(prior,'verify-visual.cjs'),'utf8');visual=visual.replace(JSON.stringify(variants),JSON.stringify({...variants,B:variants.Safe,Safe:fixedURL}));put('verify-visual.cjs',visual);
console.log('One experimental retirement fence prepared. Original engine and all original variants unchanged.');
