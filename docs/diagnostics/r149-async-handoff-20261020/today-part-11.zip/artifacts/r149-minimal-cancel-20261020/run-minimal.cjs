const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');const dir=__dirname,source=process.argv[2]||'simple';
const modes=process.argv[3]==='narrow'?['pending-no-status','pending-link-fence']:['completed','pending-safe','pending-immediate','pending-diagnostics','pending-program-first','negative-after-delete'];
(async()=>{
 for(const mode of modes){
  const label=source+'-'+mode;if(fs.existsSync(path.join(dir,label+'.json')))throw Error('Refusing overwrite '+label);
  const context=await chromium.launchPersistentContext(path.join(dir,'profiles',label),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
  try{
   const page=context.pages()[0],messages=[],errors=[],cdp=await context.newCDPSession(page);await page.bringToFront();await cdp.send('Log.enable');const nativeLogs=[];cdp.on('Log.entryAdded',e=>nativeLogs.push(e.entry));page.on('console',m=>{if(['warning','error'].includes(m.type()))messages.push({type:m.type(),text:m.text()});});page.on('pageerror',e=>errors.push(e.stack));
   await page.goto(pathToFileURL(path.join(dir,'minimal.html')).href,{waitUntil:'load'});
   const specs=source==='simple'?null:JSON.parse(fs.readFileSync(path.join(dir,'representative.json'))).programs;
   const result=await page.evaluate(({mode,specs})=>runMinimal(mode,specs),{mode,specs});
   const j={label,browser:context.browser().version(),result,messages,errors,nativeLogs};fs.writeFileSync(path.join(dir,label+'.json'),JSON.stringify(j,null,2),{flag:'wx'});
   console.log(JSON.stringify({label,gate:result.gate,initial:result.initial,immediate:result.immediate,final:result.final,warnings:nativeLogs.filter(x=>x.text.includes('GL_INVALID')).length,errors:errors.length,renderer:result.context.renderer}));
   if(errors.length||!result.context.renderer.includes('RTX 3050'))throw Error('Invalid test context');
  }finally{await context.close();}
 }
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
