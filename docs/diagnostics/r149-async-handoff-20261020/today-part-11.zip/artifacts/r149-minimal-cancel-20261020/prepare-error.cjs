const fs=require('node:fs'),path=require('node:path'),dir=__dirname,root=path.resolve(dir,'../..');
let s=fs.readFileSync(path.join(root,'artifacts/r149-async-failures-20261020/run.cjs'),'utf8');
s=s.replace("path.join(dir,'index.html')","path.join(dir,'index-fixed.html')");
s=s.replace('await page.waitForTimeout(100);','await page.waitForTimeout(500);');
s=s.replace("const j={name,mode,browser:","if(mode==='F'&&(outcome.settled!=='rejected'||outcome.badLinkStatus!==false||after.badProgramUses||beforeClose.completedMainFrames||after.pending||after.pollTimers||after.rafActive||after.glError||after.staleUses.length||Object.values(after.byKind).some(x=>x.duplicateDeletes||x.unrequested)||control.enabled||!messages.some(m=>m.text.includes('Shader Error'))||!messages.some(m=>m.text.includes('Shader preparation failed'))))throw Error('Shader error path regression');const j={name,mode,browser:");
s=s.replace("['F','D','E','L']","['F']");
fs.writeFileSync(path.join(dir,'check-error.cjs'),s,{flag:'wx'});
console.log('Existing shader-error test adapted to the new copy only.');
