// Standalone diagnostic only. No Three.js, game, global WebGL hooks, or incorrect calls outside the explicit negative control.
window.runMinimal=async function(mode,specs){
 const attributes={alpha:true,antialias:true,depth:true,stencil:true,powerPreference:'high-performance',premultipliedAlpha:true,preserveDrawingBuffer:false};
 const gl=document.querySelector('canvas').getContext('webgl2',attributes);if(!gl)throw Error('WebGL2 unavailable');
 const ext=gl.getExtension('KHR_parallel_shader_compile');if(!ext)throw Error('KHR_parallel_shader_compile unavailable');
 const debug=gl.getExtension('WEBGL_debug_renderer_info'),events=[],objects=new WeakMap(),rows=[];let next=0,aborted=false,pending=0,timer=null;
 const emit=(name,data={})=>events.push({name,t:performance.now(),...data});
 const call=(name,...args)=>{const before=args.map(x=>objects.has(x)?{...objects.get(x)}:typeof x==='string'?{stringLength:x.length}:x);const value=Reflect.apply(gl[name],gl,args);emit(name,{args:before,result:typeof value==='boolean'||typeof value==='number'||value===null?value:undefined});return value;};
 const make=(kind,...args)=>{const h=call('create'+kind,...args);objects.set(h,{id:++next,kind,deletes:0});return h;};
 const remove=(kind,h)=>{call('delete'+kind,h);objects.get(h).deletes++;};
 const error=phase=>{const code=gl.getError();emit('error-boundary',{phase,code,lost:gl.isContextLost()});return code;};
 const vs='#version 300 es\nin vec3 position;void main(){gl_Position=vec4(position,1.0);}',fragment='#version 300 es\nprecision highp float;out vec4 color;void main(){color=vec4(0.15,0.75,0.35,1.0);}';
 specs ||= [{id:'simple',vertexSource:vs,fragmentSource:fragment,attachmentOrder:[35633,35632],bindings:[{index:0,name:'position'}]}];
 error('entry');
 for(const spec of specs){
  const program=make('Program'),vertex=make('Shader',gl.VERTEX_SHADER);call('shaderSource',vertex,spec.vertexSource);call('compileShader',vertex);
  const frag=make('Shader',gl.FRAGMENT_SHADER);call('shaderSource',frag,spec.fragmentSource);call('compileShader',frag);
  for(const type of spec.attachmentOrder||[35633,35632])call('attachShader',program,type===35633?vertex:frag);
  for(const b of spec.bindings||[])call('bindAttribLocation',program,b.index??b.args?.[0],b.name??b.args?.[1]);
  if(spec.transformFeedback?.length)throw Error('Unsupported transform-feedback corpus member');
  call('linkProgram',program);rows.push({program,vertex,frag,source:spec.id});
 }
 const initial=mode==='pending-no-status'?[]:rows.map(r=>call('getProgramParameter',r.program,ext.COMPLETION_STATUS_KHR));emit('initial-completion',{statuses:initial});
 const diagnostics=()=>rows.map(r=>({source:r.source,linked:call('getProgramParameter',r.program,gl.LINK_STATUS),programLog:call('getProgramInfoLog',r.program),vertexLog:call('getShaderInfoLog',r.vertex),fragmentLog:call('getShaderInfoLog',r.frag)}));
 let checks,gate=mode==='pending-no-status'?null:initial.some(x=>!x),settled='fulfilled';
 if(mode==='completed'||mode==='negative-after-delete'){
  pending=1;while(rows.some(r=>!call('getProgramParameter',r.program,ext.COMPLETION_STATUS_KHR))){await new Promise(resolve=>{timer=setTimeout(()=>{timer=null;resolve();},10);});}pending=0;checks=diagnostics();error('completed-before-destroy');
 }else if(gate||mode==='pending-no-status'){
  aborted=true;emit('abort',{pendingLink:true});
  if(mode==='pending-safe'){
   pending=1;await new Promise(resolve=>{timer=setTimeout(()=>{timer=null;resolve();},10);});pending=0;settled='rejected';emit('preparation-rejected',{aborted});
  }else if(mode==='pending-diagnostics'){checks=diagnostics();error('pending-diagnostics-before-destroy');}
  else if(mode==='pending-link-fence'){checks=rows.map(r=>({source:r.source,linked:call('getProgramParameter',r.program,gl.LINK_STATUS)}));}
 }else{emit('pending-scenario-not-exercised',{reason:'All links already ready'});checks=diagnostics();}
 emit('destroy-begin',{mode,aborted,pending,timerActive:timer!==null});
 for(const r of rows){
  if(mode==='pending-program-first'){remove('Program',r.program);remove('Shader',r.vertex);remove('Shader',r.frag);}
  else{remove('Shader',r.vertex);remove('Shader',r.frag);remove('Program',r.program);}
 }
 const immediate=error('after-destroy');
 if(mode==='negative-after-delete'){emit('intentional-negative-control');call('getProgramParameter',rows[0].program,gl.LINK_STATUS);}
 // Observation window only; never delay or change the cleanup order.
 await new Promise(resolve=>setTimeout(resolve,500));const final=error('observation-end');
 const result={mode,programCount:rows.length,gate,initial,aborted,settled,pending,timerActive:timer!==null,checks,immediate,final,events,objects:rows.map(r=>({source:r.source,program:objects.get(r.program),vertex:objects.get(r.vertex),fragment:objects.get(r.frag)})),context:{version:gl.getParameter(gl.VERSION),attributes:gl.getContextAttributes(),renderer:gl.getParameter(debug.UNMASKED_RENDERER_WEBGL),KHR:true,lost:gl.isContextLost()}};
 document.getElementById('status').textContent=JSON.stringify({mode,gate,immediate,final},null,2);return result;
};
