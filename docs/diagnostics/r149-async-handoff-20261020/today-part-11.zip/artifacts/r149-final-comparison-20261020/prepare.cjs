const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=__dirname,root=path.resolve(dir,'../..'),boundary=path.join(root,'artifacts/r149-context-boundary-20261020'),old=path.join(root,'artifacts/r149-async-final-cleanup-20261020');
const put=(n,s)=>fs.writeFileSync(path.join(dir,n),s,{flag:'wx'}),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const paths=['assets/three.min.js','index.html','dist/adapters/rendering/scene.js','src/adapters/rendering/scene.ts','types/rendering-contracts.d.ts','tests/shader-checks.test.cjs'];
for(const [folder,names]of [[boundary,['index-before.html','index-safe.html','three-stage2.js','scene.js','graphics.js','dispose-environment.js','app-before.js','app-safe.js','observe-b.js']],[old,['verify-visual.cjs','program-observer.js','png.cjs']]])for(const n of names)paths.push(path.relative(root,path.join(folder,n)));
const variants={A:path.join(root,'index.html'),B:path.join(boundary,'index-before.html'),Safe:path.join(boundary,'index-safe.html')};
put('preserved-before.json',JSON.stringify({created:new Date().toISOString(),variants,files:paths.map(p=>({path:p,sha256:sha(fs.readFileSync(path.join(root,p)))}))},null,2));
for(const n of ['png.cjs','program-observer.js'])put(n,fs.readFileSync(path.join(old,n)));
let visual=fs.readFileSync(path.join(old,'verify-visual.cjs'),'utf8');
visual=visual.replace("pathToFileURL(path.join(dir,'index-'+mode+'.html')).href","pathToFileURL("+JSON.stringify(variants)+"[mode]).href");
visual=visual.replace("[['A1','baseline'],['B','final'],['A2','baseline']]","[['A1','B'],['B','Safe'],['A2','B']]");
put('verify-visual.cjs',visual);
let observer=fs.readFileSync(path.join(boundary,'observe-b.js'),'utf8');
// Explicit creation/deletion accounting: never call isTexture/isShader/etc on deleted handles.
observer=observer.replace(/const test=\{program:'isProgram'[\s\S]*?c\.nativeLive\+\+;/,'');
observer=observer.replace('environmentNow:d.environmentBacking()','environmentNow:undefined');
observer=observer.replace('live:!!p.program&&!g.isContextLost()&&g.isProgram(p.program)','live:undefined');
observer=observer.replace("const createKinds=",`const nativeErrors=new Map();for(const proto of [WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype])nativeErrors.set(proto,proto.getError);
 d.operationErrors=[];d.cancelArmed=false;
 const createKinds=`);
// Per-operation error checks only after the cancellation trigger, on a live context.
observer=observer.replace("event('dispatch-pagehide');dispatchEvent",`d.cancelArmed=true;event('cancel-entry-error',{code:this.getError(),lost:this.isContextLost()});event('dispatch-pagehide');dispatchEvent`);
const marker=' const add=EventTarget.prototype.addEventListener';
observer=observer.replace(marker,` for(const proto of [WebGLRenderingContext.prototype,WebGL2RenderingContext.prototype]){
  const nativeGetError=nativeErrors.get(proto);
  for(const name of Object.getOwnPropertyNames(proto)){
   const descriptor=Object.getOwnPropertyDescriptor(proto,name),fn=descriptor?.value;
   if(typeof fn!=='function'||['constructor','getError','isContextLost'].includes(name))continue;
   proto[name]=function(...args){const result=Reflect.apply(fn,this,args);if(d.cancelArmed&&!d.reading&&!this.isContextLost()){const code=Reflect.apply(nativeGetError,this,[]);if(code)d.operationErrors.push({name,code,t:performance.now(),phase:d.phase,disposeCalls:d.disposeCalls,args:args.map(a=>{const row=a&&typeof a==='object'&&ids.get(a);return row?{id:row.id,kind:row.kind,deletes:row.deletes,epoch:row.epoch}:typeof a==='number'?a:typeof a;})});}return result;};
  }
 }
`+marker);
observer=observer.replace('return{scenario,signalAborted','return{scenario,operationErrors:d.operationErrors,cancelArmed:d.cancelArmed,signalAborted');
put('observe.js',observer);
let runner=fs.readFileSync(path.join(boundary,'cancel-probe.cjs'),'utf8');
runner=runner.replace("'observe-cancel-probe.js'","'observe.js'");
runner=runner.replace("pathToFileURL(path.join(dir,html)).href","pathToFileURL("+JSON.stringify(variants)+"[html]).href");
runner=runner.replace("if(!balanced(failed.snapshot)||!failed.snapshot.reason?.sameAbort)","if(!balanced(failed.snapshot)||!failed.snapshot.reason?.sameAbort||failed.snapshot.glError||failed.snapshot.operationErrors.length||failed.snapshot.events.some(e=>e.name==='cancel-entry-error'&&e.code))");
runner=runner.replace("for(const [label,mode,html]of [['cancel-probe-before','B','index-before.html'],['cancel-probe-safe','B','index-safe.html']])","for(const [label,mode,html]of (process.argv[2]==='cancel'?[['cancel-safe-1','B','Safe'],['cancel-safe-2','B','Safe']]:[['normal-safe','N','Safe']]))");
put('check.cjs',runner);
console.log('Prepared separate diagnostics; immutable A/B++/Safe paths recorded.');
