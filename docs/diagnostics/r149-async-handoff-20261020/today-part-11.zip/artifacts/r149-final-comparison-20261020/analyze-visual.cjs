const fs=require('node:fs'),path=require('node:path');const dir=__dirname,root=path.resolve(dir,'../..');
const read=p=>JSON.parse(fs.readFileSync(p)),rows=['A1','B','A2'].map(n=>read(path.join(dir,`visual-1-${n}.json`)));
const raw=(folder,n,stage)=>fs.readFileSync(path.join(folder,`visual-1-${n}-${stage}.rgba`));
const old=path.join(root,'artifacts/r149-async-rng-20261020'),cleanup=path.join(root,'artifacts/r149-async-final-cleanup-20261020');
const diff=(a,b)=>{if(a.length!==b.length)throw Error('Dimensions differ');let pixels=0,max=0;for(let i=0;i<a.length;i+=4){let changed=false;for(let c=0;c<4;c++){const d=Math.abs(a[i+c]-b[i+c]);changed ||=d!==0;max=Math.max(max,d);}pixels+=changed;}return{pixels,max};};
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b),keys=x=>x.observation.programs.map(p=>p.cacheKey).sort();
let noNewDifferences=true;const result={normalSafe:read(path.join(dir,'normal-safe.json')).result.after,stages:{},productionApproved:false};
for(const stage of ['first','moving','night']){
 const x=rows.map(r=>r[stage]),a=raw(dir,'A1',stage),b=raw(dir,'B',stage),a2=raw(dir,'A2',stage);
 const comparisons={beforeSafe:diff(a,b),beforeRepeat:diff(a,a2)};
 let historicalDeltaMatches=null;
 if(stage==='moving'){
  const h1=raw(old,'A1',stage),h2=raw(old,'A2',stage);let direct=0,inverse=0;
  for(let i=0;i<a.length;i++){const current=b[i]-a[i],historical=h2[i]-h1[i];direct+=current!==historical;inverse+=current!==-historical;}
  historicalDeltaMatches={directMismatches:direct,inverseMismatches:inverse};
  if(comparisons.beforeSafe.pixels&&Math.min(direct,inverse)!==0)noNewDifferences=false;
 }else if(comparisons.beforeSafe.pixels)noNewDifferences=false;
 if(comparisons.beforeRepeat.pixels)noNewDifferences=false;
 const state=x.every(r=>r.cpuSHA256===x[0].cpuSHA256&&same(r.rng,x[0].rng)&&same(r.waterState,x[0].waterState)&&same(r.audio,x[0].audio)&&same(keys(r),keys(x[0]))&&same(r.futureStates,x[0].futureStates));
 const previous=read(path.join(cleanup,'visual-1-B.json'))[stage];
 const previousRaw=raw(cleanup,'B',stage),previousCandidate=diff(previousRaw,b);
 let previousDeltaKnown=previousCandidate.pixels===0;
 if(stage==='moving'&&previousCandidate.pixels){
  const h1=raw(old,'A1',stage),h2=raw(old,'A2',stage);let direct=0,inverse=0;
  for(let i=0;i<b.length;i++){const current=b[i]-previousRaw[i],historical=h2[i]-h1[i];direct+=current!==historical;inverse+=current!==-historical;}
  previousCandidate.historicalSignedDelta={directMismatches:direct,inverseMismatches:inverse};
  previousDeltaKnown=Math.min(direct,inverse)===0;
 }
 const matchesPreviousState=x[1].cpuSHA256===previous.cpuSHA256&&same(x[1].rng,previous.rng)&&same(x[1].waterState,previous.waterState)&&same(x[1].audio,previous.audio)&&same(keys(x[1]),keys(previous));
 const conditions=x.every(r=>['width','height','window','gpu','quality','renderSettings','contextAttributes'].every(k=>same(r[k],x[0][k])));
 noNewDifferences&&=state&&conditions&&matchesPreviousState&&previousDeltaKnown;
 result.stages[stage]={comparisons,historicalDeltaMatches,stateRNGWaterAudioProgramsEqual:state,conditionsEqual:conditions,matchesPreviousState,previousCandidate,rng:x[1].rng,water:x[1].waterState};
}
result.noNewDifferences=noNewDifferences;result.note='A/A moving-image uncertainty remains open; no pixel tolerance introduced. Counts prove explicit delete requests, not driver-memory reclamation. nativeLive=0 in derived observer is an unmeasured placeholder, not a native validity assertion.';
fs.writeFileSync(path.join(dir,'visual-summary-final.json'),JSON.stringify(result,null,2),{flag:'wx'});
console.log(JSON.stringify({noNewDifferences,stages:result.stages}));if(!noNewDifferences)process.exitCode=2;
