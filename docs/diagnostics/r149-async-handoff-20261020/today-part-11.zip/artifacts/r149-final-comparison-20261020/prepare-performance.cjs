const fs=require('node:fs'),path=require('node:path');
const dir=__dirname,root=path.resolve(dir,'../..'),old=path.join(root,'artifacts/r149-async-rng-20261020');
const put=(n,s)=>fs.writeFileSync(path.join(dir,n),s,{flag:'wx'});
for(const n of ['probe.js','menu-probe-final.js'])put(n,fs.readFileSync(path.join(old,n)));
// Identical existing observation for every variant. No lifecycle/error injection in performance runs.
let source=fs.readFileSync(path.join(old,'run-pq.cjs'),'utf8');
source=source.replace("save('conditions-abc.json'", "if(!fs.existsSync(path.join(dir,'conditions-abc.json')))save('conditions-abc.json'");
source=source.replace("order:'cycle1 B+/B++; optional cycle2 B++/B+; own new profile then same profile restart per variant'","order:'cycle1 A/B/Safe, cycle2 Safe/B/A; fresh then same-profile browser restart per variant; optional cycle3 B/A/Safe'");
source=source.replace("enabled equally in B and B+", "enabled equally in A, B++ and Safe");
source=source.replace("const navigation={requestEpoch:Date.now()};", "const navigation={requestEpoch:Date.now()};const urls=JSON.parse(fs.readFileSync(path.join(dir,'preserved-before.json'))).variants;");
source=source.replace("pathToFileURL(path.join(dir,'index-'+mode+'.html')).href", "pathToFileURL(urls[mode]).href");
source=source.replace("data.preparationCalls!==1||data.modifiedRenderer!==true", "data.preparationCalls!==(mode==='A'?0:1)||data.modifiedRenderer!==(mode!=='A')");
source=source.replace("(hash!==lastHash&&kept<6)","(hash!==lastHash&&kept<0)");
source=source.replace("const orders=[['P','Q'],['Q','P']]", "const orders=[['A','B','Safe'],['Safe','B','A'],['B','A','Safe']]");
source=source.replaceAll("mode,'rng'", "mode,'final'");
put('run-performance.cjs',source);
console.log('Performance runner prepared, not started; correctness/cancellation gates still apply.');
