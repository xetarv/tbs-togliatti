const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url'),{chromium}=require('playwright-core');
const dir=__dirname,variants=JSON.parse(fs.readFileSync(path.join(dir,'preserved-before.json'))).variants;
(async()=>{
 const context=await chromium.launchPersistentContext(path.join(dir,'profiles/preflight-safe-2'),{executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:false,viewport:null,args:['--use-angle=d3d11','--enable-webgl'],ignoreDefaultArgs:['--enable-unsafe-swiftshader']});
 let page;const errors=[],messages=[];
 try{
  page=context.pages()[0];page.on('pageerror',e=>errors.push(e.stack));page.on('console',m=>{if(['warning','error'].includes(m.type()))messages.push({type:m.type(),text:m.text()});});
  const cdp=await context.newCDPSession(page),browser=await context.browser().newBrowserCDPSession(),{targetInfo}=await cdp.send('Target.getTargetInfo'),win=await browser.send('Browser.getWindowForTarget',{targetId:targetInfo.targetId});await browser.send('Browser.setWindowBounds',{windowId:win.windowId,bounds:{windowState:'maximized'}});await page.bringToFront();
  await page.addInitScript(()=>{
   localStorage.setItem('tbs.graphicsQuality','high');let api;
   Object.defineProperty(window,'TBS',{get:()=>api,set(value){api=value;for(const n of ['buildWorld','buildPresentation']){let fn;Object.defineProperty(api,n,{get:()=>fn,set(original){fn=function(...args){const r=Reflect.apply(original,this,args);if(n==='buildWorld'){window.__world=r;const render=r.renderer.render;r.renderer.render=function(scene,camera){const value=Reflect.apply(render,this,arguments);if(scene===r.scene)window.__mainFrames=(window.__mainFrames||0)+1;return value;};}else{window.__state=args[0].state;window.__ports=r;}return r;};}});}}});
   document.addEventListener('click',e=>{if(e.target.closest?.('#startBtn'))window.__trustedClick=e.isTrusted;},true);document.addEventListener('keydown',e=>{if(e.code==='KeyW')window.__trustedW=e.isTrusted;},true);
  });
  await page.goto(pathToFileURL(variants.Safe).href,{waitUntil:'load',timeout:180000});await page.waitForFunction(()=>window.__mainFrames>=2,null,{timeout:90000,polling:100});
  await page.locator('#startBtn').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(dir,'preflight-menu.png')});
  const initial=await page.evaluate(()=>({...__state.player}));await page.locator('#startBtn').click();await page.keyboard.down('w');
  try{await page.waitForFunction(p=>__state.mode==='playing'&&__state.player.speed>0&&Math.hypot(__state.player.x-p.x,__state.player.z-p.z)>0.1,initial,{timeout:15000,polling:50});}finally{await page.keyboard.up('w');}
  const data=await page.evaluate(()=>{const r=__world.renderer,g=r.getContext(),ext=g.getExtension('WEBGL_debug_renderer_info');return{quality:__ports.graphics.quality,checks:r.debug.checkShaderErrors,GL:g.getError(),lost:g.isContextLost(),gpu:g.getParameter(ext.UNMASKED_RENDERER_WEBGL),window:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},canvas:{width:g.drawingBufferWidth,height:g.drawingBufferHeight},trusted:[__trustedClick,__trustedW],player:{...__state.player},mainFrames:__mainFrames,programs:r.info.programs.length};});
  const passed=!errors.length&&!messages.some(m=>m.type==='error'||m.text.includes('GL_INVALID'))&&!data.GL&&!data.lost&&data.checks&&data.quality==='high'&&data.trusted.every(Boolean)&&data.gpu.includes('RTX 3050');
  fs.writeFileSync(path.join(dir,'preflight-safe.json'),JSON.stringify({passed,url:variants.Safe,browser:context.browser().version(),initial,data,errors,messages,note:'No diagnostic GL wrappers. Real mouse/keyboard; screenshot confirms menu display. Not a performance run.'},null,2),{flag:'wx'});console.log(JSON.stringify({passed,...data}));if(!passed)throw Error('Safe preflight failed');
 }finally{await context.close();}
})().catch(e=>{console.error(e.stack);process.exitCode=1;});
