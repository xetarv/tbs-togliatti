const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),zlib=require('node:zlib');
const old=path.resolve(__dirname,'../../tbs-togliatti/artifacts/texture-final-acceptance-20261022/visual');
const read=(dir,label)=>JSON.parse(fs.readFileSync(path.join(dir,`visual-1-${label}.json`),'utf8'));
const historical={A1:read(old,'A1'),A2:read(old,'A2')},current={A1:read(__dirname,'A1'),B:read(__dirname,'B'),A2:read(__dirname,'A2')};
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const keys=['width','height','window','gpu','quality','renderSettings','contextAttributes','debug','totalSteps','stateSHA256','trafficSHA256','worldTransformsSHA256','camera','rng','waterState','audio','futureStates','daylight','cpuSHA256'];
const rows=[];
for(const stage of ['moving','camera']){
 const frames={};for(const label of ['A1','A2'])frames[label]=fs.readFileSync(path.join(old,`visual-1-${label}-${stage}.rgba`));
 for(const label of ['A1','B','A2']){
  const raw=fs.readFileSync(path.join(__dirname,`visual-1-${label}-${stage}.rgba`));
  if(sha(raw)!==current[label][stage].pixelSHA256)throw Error('Current raw hash mismatch');
  const matches=[];
  for(const h of ['A1','A2']){
   if(sha(frames[h])!==historical[h][stage].pixelSHA256)throw Error('Historical raw hash mismatch');
   const mismatches=keys.filter(k=>JSON.stringify(current[label][stage][k])!==JSON.stringify(historical[h][stage][k]));
   const currentState=zlib.gunzipSync(fs.readFileSync(path.join(__dirname,`visual-1-${label}-${stage}-state.json.gz`)));
   const oldState=zlib.gunzipSync(fs.readFileSync(path.join(old,`visual-1-${h}-${stage}-state.json.gz`)));
   matches.push({nativeControl:h,rawEqual:raw.equals(frames[h]),stateEqual:currentState.equals(oldState),mismatches});
  }
  rows.push({stage,label,pixelSHA256:sha(raw),matches,passed:matches.some(m=>m.rawEqual&&m.stateEqual&&!m.mismatches.length)});
 }
 // Current B minus current A1 must be exactly the signed historical A1 minus A2 (or inverse).
 const a=fs.readFileSync(path.join(__dirname,`visual-1-A1-${stage}.rgba`)),b=fs.readFileSync(path.join(__dirname,`visual-1-B-${stage}.rgba`));
 const delta=(x,y)=>{const d=Buffer.alloc(x.length*2);for(let i=0;i<x.length;i++)d.writeInt16LE(x[i]-y[i],i*2);return d;};
 const observed=delta(b,a),forward=delta(frames.A1,frames.A2),reverse=delta(frames.A2,frames.A1);
 rows.push({stage,label:'signed-mask',passed:observed.equals(forward)||observed.equals(reverse),currentSHA256:sha(observed),historicalForward:sha(forward),historicalReverse:sha(reverse)});
}
const inputs=JSON.parse(fs.readFileSync(path.join(old,'../inputs.json'),'utf8'));
const result={passed:rows.every(r=>r.passed),historicalDirectory:old,historicalBase:inputs.base,historicalVendor:inputs.vendors,rows,note:'No tolerance. Exact full independent native A frames, all controlled state/conditions and full signed deltas. Current cycle/comparison remains unchanged, including its camera strict failure.'};
fs.writeFileSync(path.join(__dirname,'historical-control-proof.json'),JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify({passed:result.passed,rows:rows.map(r=>({stage:r.stage,label:r.label,passed:r.passed,matches:r.matches?.map(m=>({native:m.nativeControl,raw:m.rawEqual,state:m.stateEqual,mismatches:m.mismatches}))}))}));if(!result.passed)process.exitCode=2;
