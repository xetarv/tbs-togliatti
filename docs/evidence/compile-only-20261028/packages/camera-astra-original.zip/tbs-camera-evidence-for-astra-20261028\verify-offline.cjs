// Read-only verification. No browser, image encoding, masks or filesystem writes.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),zlib=require('node:zlib'),assert=require('node:assert/strict');
const root=__dirname,read=f=>JSON.parse(fs.readFileSync(path.join(root,f),'utf8'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),fh=f=>sha(fs.readFileSync(path.join(root,f)));
const expectedManifest=fs.readFileSync(path.join(root,'manifest.sha256.txt'),'utf8').trim().split(/\s/)[0];
assert.equal(fh('manifest.json'),expectedManifest);
const manifest=read('manifest.json');for(const f of manifest.files){assert.equal(fh(f.file),f.sha256,f.file);assert.equal(fs.statSync(path.join(root,f.file)).size,f.bytes);}
const provenance=read('provenance.json');for(const f of provenance.copiedFiles)assert.equal(fh(f.file),f.sha256,'Copied original '+f.file);
const decode=require('./current/visual/png.cjs').decode,frames={};
for(const x of read('image-index.json').frames){
 const m=read(x.metadata).camera,raw=fs.readFileSync(path.join(root,x.rgba)),image=decode(fs.readFileSync(path.join(root,x.png)));
 assert.equal(sha(raw),m.pixelSHA256);assert.equal(fh(x.png),m.pngSHA256);assert.equal(raw.length,m.width*m.height*4);assert.equal(image.w,m.width);assert.equal(image.h,m.height);assert.equal(image.bpp,4);
 for(let y=0;y<m.height;y++)for(let i=0;i<m.width*4;i++)assert.equal(raw[(m.height-1-y)*m.width*4+i],image.pixels[y*m.width*4+i],'PNG/raw');
 assert.equal(sha(zlib.gunzipSync(fs.readFileSync(path.join(root,x.cpu)))),m.cpuSHA256);frames[x.key]=raw;
}
for(const row of read('offline-verification.json').pairs){const a=frames[row.left],b=frames[row.right],d=Buffer.alloc(a.length*2);let pixels=0,channels=0,max=0;
 for(let p=0;p<a.length/4;p++){let changed=false;for(let c=0;c<4;c++){const i=p*4+c,v=a[i]-b[i];d.writeInt16LE(v,i*2);if(v){changed=true;channels++;max=Math.max(max,Math.abs(v));}}pixels+=changed;}
 assert.equal(pixels,row.changedPixels);assert.equal(channels,row.changedChannels);assert.equal(max,row.maxDelta);assert.equal(sha(d),row.signedDeltaSHA256);
}
console.log(JSON.stringify({integrity:'OK',files:manifest.files.length,frames:Object.keys(frames).length,cameraComparisons:read('offline-verification.json').pairs.length,visualVerdict:'NOT ASSIGNED'},null,2));
