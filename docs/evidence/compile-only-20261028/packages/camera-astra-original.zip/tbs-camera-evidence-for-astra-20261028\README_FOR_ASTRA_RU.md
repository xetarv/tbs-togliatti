# Camera-пакет для независимого ревью Astra

Подготовлен 28 октября 2026 **из сохранённых байтов**, без запуска игры/Edge,
новых визуальных экспериментов, перекодирования изображений и изменения критериев.
Окончательный визуальный PASS/FAIL этим пакетом не выносится.

Вопрос ревью: как интерпретировать различие camera B от текущих штатных A
**23 088 пикселей, максимум 4/255**, учитывая реальные исторические контроли
и различия условий. Ни дефект, ни допустимость этой разницы не установлены.

## 1. Версии — не смешивать разные A/B

- **Текущие A1/A2/A3:** штатная база `166ac7440c7e1e5e530eb6614a36acdf5295f639`.
- **Текущая B:** интегрированный compile-only,
  `2347940021c074acfd1f5a249c7b3a46ec6895c8`,
  ветка `feature/safe-compile-only-startup-20261026`.
- **Исторические A1/A2:** штатные A-контроли текстурной приёмки 22 октября,
  база `549a6beb8d7e98aa15c8b02bac9678b8d3c459da` с записанным историческим overlay,
  перечисленным в [historical-inputs.json](origins/historical-inputs.json).
  Это **не текущая A на 166ac744** и не экспериментальные Safe A1/A2 от 20–21 октября.

Текущие снимки получены 26 октября до checkpoint-коммита B: тогда это была база
166ac744 с незакоммиченным overlay. SHA256 всех десяти файлов overlay из
[исходной integrity-записи](origins/current-integrity.json) совпали с текущей чистой
23479400; [provenance.json](provenance.json) хранит эту проверку и
[publication receipt](origins/publication-receipt.json) связывает checkpoint с коммитом.
Не утверждается, что commit 23479400 уже существовал в момент захвата.

## 2. Шесть первичных camera-кадров

| Контроль | PNG без перекодирования | Исходные WebGL RGBA | Полные metadata | CPU-состояние |
| --- | --- | --- | --- | --- |
| Текущая A1 | [PNG](current/visual/visual-1-A1-camera.png) | [RGBA](current/visual/visual-1-A1-camera.rgba) | [JSON](current/visual/visual-1-A1.json) | [JSON.gz](current/visual/visual-1-A1-camera-state.json.gz) |
| Текущая A2 | [PNG](current/visual/visual-1-A2-camera.png) | [RGBA](current/visual/visual-1-A2-camera.rgba) | [JSON](current/visual/visual-1-A2.json) | [JSON.gz](current/visual/visual-1-A2-camera-state.json.gz) |
| Текущая A3 | [PNG](current/visual/visual-1-A3-camera.png) | [RGBA](current/visual/visual-1-A3-camera.rgba) | [JSON](current/visual/visual-1-A3.json) | [JSON.gz](current/visual/visual-1-A3-camera-state.json.gz) |
| Текущая B | [PNG](current/visual/visual-1-B-camera.png) | [RGBA](current/visual/visual-1-B-camera.rgba) | [JSON](current/visual/visual-1-B.json) | [JSON.gz](current/visual/visual-1-B-camera-state.json.gz) |
| Историческая A1 | [PNG](historical/visual/visual-1-A1-camera.png) | [RGBA](historical/visual/visual-1-A1-camera.rgba) | [JSON](historical/visual/visual-1-A1.json) | [JSON.gz](historical/visual/visual-1-A1-camera-state.json.gz) |
| Историческая A2 | [PNG](historical/visual/visual-1-A2-camera.png) | [RGBA](historical/visual/visual-1-A2-camera.rgba) | [JSON](historical/visual/visual-1-A2.json) | [JSON.gz](historical/visual/visual-1-A2-camera-state.json.gz) |

Отображаемые названия A1/A2 повторяются только внутри явно разных каталогов.
Каждый capture имеет собственный nonce, сохранённый в JSON и [image-index.json](image-index.json).
Raw: RGBA unsigned bytes, **строки снизу вверх**, 1910×867×4 = 6 623 880 байт.
PNG — сверху вниз. Офлайн-проверка подтвердила соответствие PNG и raw всех шести
кадров, а также SHA256 PNG/raw/распакованного CPU-снимка из исходных metadata.

## 3. Сравнения и дельты

| Полные camera-кадры | Отличающиеся пиксели | Максимальная поканальная разница |
| --- | ---: | ---: |
| Текущая A1 против A2 | 0 | 0 |
| Текущая A1 против A3; A2 против A3 | 0 | 0 |
| Текущая B против каждой A1/A2/A3 | 23 088 | 4 |
| Историческая A1 против исторической A2 | 23 088 | 4 |
| Текущая B против исторической A1 | 0 | 0 |
| Текущая A1 против исторической A2 | 0 | 0 |

Это проверка **полных исходных RGBA**, не совпадение одного числа пикселей:

- Текущие A1/A2/A3 и историческая A2 имеют SHA256 raw
  `48ddcf14c4cc34fc2befacbb6a7f41b6fb6956a422d114a3310ee004f3d430a0`.
- Текущая B и историческая A1 имеют SHA256 raw
  `b8d4b251a84bd044f1b52c9a9ca923b0cae6c234ca137c7c98e005ca4b71a7c2`.
- SHA256 полной знаковой поканальной разности **B−A1** совпадает с
  **историческая A1−A2**. Знак и порядок операндов не отбрасывались.

Основные оригинальные документы:

- [Текущее comparison.json](current/visual/comparison.json): полный результат
  первого цикла A1→B→A2, включая A/A; `acceptable=false` сохранено без изменений.
- [historical-control-proof.json](current/visual/historical-control-proof.json):
  прежнее сопоставление с историческими A, включая знаковые хеши;
  `passed=false` сохранено без изменений из-за различий metadata.
- [Историческое comparison.json](historical/visual/comparison.json): полный
  результат серии 22 октября. **Буква B внутри него означает текстурный кандидат
  того дня, а не нынешний compile-only.** Для этой задачи скопированы только его
  штатные A camera-изображения.
- [offline-verification.json](offline-verification.json): новый анализ только
  сохранённых байтов, в том числе A3; сверка с прежними числами и знаковыми SHA256.
  Новые маски/дельта-файлы и допуски не создавались.

В `current/visual/masks/` и `historical/visual/masks/` побитово скопированы существующие
PNG и `.bin.gz` **беззнаковых** масок. Их связь с кадрами указана в comparison.json.
Camera-маска: `mask-eb798bef2a40b5fb`; остальные исходные маски включены, чтобы
полные comparison.json не ссылались на отсутствующие mask-файлы.
Сами изображения других стадий в этот camera-пакет не включены.

## 4. Подтверждённые условия и различия

| Параметр | Текущие A1/A2/A3/B | Исторические A1/A2 |
| --- | --- | --- |
| Дата по исходному отчёту | 26.10.2026 | 22.10.2026 |
| Edge | 156.0.4314.42 | **155.0.4283.62** |
| GPU/backend | RTX 3050 Laptop, ANGLE/D3D11 | Совпадает по metadata |
| Framebuffer / CSS / DPR | 1910×867 / 1528×694 / 1,25 | Совпадает |
| Качество / shader checks | High / true | Совпадает |
| Начальный seed по capture-коду | 72421 | 72421 |
| Camera-стадия | 91 фиксированный шаг, dt=1/60 | Совпадает |
| RNG на camera | seed 3999592045, calls 989512 | **seed 2214937133, calls 992008** |
| audio и futureStates | Совпадают внутри текущей серии | **Отличаются от текущих** |
| Сохранённый CPU snapshot | Совпадает во всех шести кадрах | Совпадает с текущими |

Внутри текущей серии совпали все сравниваемые условия и состояния, включая RNG,
audio, futureStates, воду и камеру. Между сериями сохранённые camera/world/traffic
CPU-снимки и параметры воды совпали, но это не полное описание всех native GL
состояний, геометрических буферов или uniforms.

**Различия RNG/audio не названы причиной пиксельной разницы.** Влияние на изображение
не доказано. Также не доказано, что причина — браузер, renderer или драйвер.
Историческое побитовое совпадение не объявляется автоматическим допуском для B.

Метод захвата сохранён в `current/visual/visual-cycle.cjs`, `a3-only.cjs` и
`historical/visual/visual-cycle.cjs`: фиксированные шаги настоящего game.step,
поворот камеры через реальные CDP-события, чтение default framebuffer после render,
дополнительный readPixels после finish, PNG из canvas и побайтовая сверка с raw.
Код включён **для чтения метода**, не для новых прогонов.

## 5. Происхождение каждого файла

Полные исходные локальные пути, назначения, исходные SHA256, отметка сверки
с прежним манифестом и audit-mtime перечислены для каждого скопированного файла
в [provenance.json](provenance.json), массив `copiedFiles`.
Два главных исходных каталога:

```text
C:\Users\s.nikushkin\Documents\tbs-compile-only-acceptance-20261026\visual
C:\Users\s.nikushkin\Documents\tbs-togliatti\artifacts\texture-final-acceptance-20261022\visual
```

[INTEGRATION_STATUS_RU.md](INTEGRATION_STATUS_RU.md) скопирован без редактирования.
Его слова о незавершённых A/B/lifecycle относятся к **26 октября**; эти этапы
позднее проверялись отдельно и не меняют предмет данного camera-ревью.
В `origins/` находятся исходные inputs, integrity, манифесты, capture-provenance,
Git snapshot, исторический отчёт и receipt публикации. Их старые абсолютные пути
сохранены как доказательство происхождения, а не как необходимые локальные зависимости.
`origins/current-manifest.json` — манифест исходного checkpoint, не этого пакета.

## 6. Что отсутствует или не доказано

1. **Отдельных полных знаковых delta-бинарников нет.** Прежние скрипты вычисляли
   Int16LE(left−right) для всех RGBA-каналов и сохраняли только SHA256.
   Полные исходные RGBA включены, поэтому расчёт воспроизводим без догадок;
   новые delta-файлы здесь не создавались.
2. В capture JSON нет точного абсолютного wall-clock времени camera-readPixels
   или timeOrigin. Дата подтверждается отчётами; nonce, totalSteps и относительные
   navigation entries сохранены. File mtime не выдаётся за время захвата.
3. Не записаны per-capture версия драйвера, история GPU clocks, системного и
   shader cache. Одинаковая строка GPU/backend не заменяет эти данные.
4. Audio metadata содержит длины, частоты и первые 64 samples, а не полные PCM.
5. Не установлена причина пиксельного расхождения. Пакет не доказывает отсутствие
   всех возможных различий native render state.

Это явные ограничения, а не восстановленные предположениями значения.

## 7. Что можно независимо проверить

Астра может открыть шесть исходных PNG, проверить полные raw/hash и состояния,
отдельно сравнить текущую A/A/A с B и историческую A/A, проверить направление
знаковых дельт и увидеть реальные ограничения сопоставимости. Исходные отчёты
не подменены новым положительным заключением.

После распаковки достаточно Node.js, без npm/браузера/игры:

```text
node verify-offline.cjs
```

Скрипт только читает пакет, проверяет manifest SHA256, неизменность скопированных
байтов, PNG/RGBA/CPU и сохранённые результаты. На диск не пишет, новых масок
не создаёт и визуальный PASS/FAIL не назначает. Полные исходные compare/capture
скрипты запускать для этой проверки не требуется.

Main, feature, Safe, четыре shaderChecks-правки и исторические материалы не менялись.
Git-снимки и результаты сохранности находятся в `preservation-before.json` и
`preservation-after.json`. Commit/push/merge/PR отсутствуют.
