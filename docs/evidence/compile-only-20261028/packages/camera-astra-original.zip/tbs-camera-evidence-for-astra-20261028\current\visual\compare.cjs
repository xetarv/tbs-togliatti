// Offline comparison of this one captured A1 -> Safe -> A2 cycle only.
const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),crypto=require('node:crypto');
const dir=__dirname,sha=b=>crypto.createHash('sha256').update(b).digest('hex'),read=n=>JSON.parse(fs.readFileSync(path.join(dir,n+'.json')));
const save=(n,v)=>fs.writeFileSync(path.join(dir,n+'.json'),JSON.stringify(v,null,2),{flag:'wx'});
const all=Object.fromEntries(['A1','B','A2'].map(n=>[n,read('visual-1-'+n)]));
const conditionKeys=['width','height','window','gpu','quality','renderSettings','contextAttributes','debug','totalSteps'];
const stateKeys=['stateSHA256','trafficSHA256','worldTransformsSHA256','camera','rng','waterState','audio','futureStates','daylight','cpuSHA256'];
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const crcTable=Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
function crc32(b){let c=0xffffffff;for(const v of b)c=crcTable[(c^v)&255]^(c>>>8);return(c^0xffffffff)>>>0;}
function chunk(name,data){const type=Buffer.from(name),out=Buffer.alloc(data.length+12);out.writeUInt32BE(data.length,0);type.copy(out,4);data.copy(out,8);out.writeUInt32BE(crc32(Buffer.concat([type,data])),data.length+8);return out;}
function maskPNG(mask,width,height){const raw=Buffer.alloc((width+1)*height);for(let y=0;y<height;y++)mask.copy(raw,y*(width+1)+1,(height-1-y)*width,(height-y)*width);const hdr=Buffer.alloc(13);hdr.writeUInt32BE(width,0);hdr.writeUInt32BE(height,4);hdr[8]=8;hdr[9]=0;return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',hdr),chunk('IDAT',zlib.deflateSync(raw)),chunk('IEND',Buffer.alloc(0))]);}
fs.mkdirSync(path.join(dir,'masks'));const masks=new Map(),results={};let passed=true;
for(const stage of ['first','moving','camera','night']){
 results[stage]={};
 for(const [left,right]of [['A1','A2'],['B','A1'],['B','A2']]){
  const a=all[left][stage],b=all[right][stage],rawA=fs.readFileSync(path.join(dir,`visual-1-${left}-${stage}.rgba`)),rawB=fs.readFileSync(path.join(dir,`visual-1-${right}-${stage}.rgba`));
  if(rawA.length!==rawB.length||rawA.length!==a.width*a.height*4)throw Error('RGBA shape mismatch');
  if(sha(rawA)!==a.pixelSHA256||sha(rawB)!==b.pixelSHA256)throw Error('Captured RGBA hash mismatch');
  const mask=Buffer.alloc(a.width*a.height);let changedPixels=0,changedChannels=0,maxDelta=0;
  for(let p=0;p<mask.length;p++){let changed=false;for(let c=0;c<4;c++){const delta=Math.abs(rawA[p*4+c]-rawB[p*4+c]);changed ||=delta!==0;changedChannels+=delta!==0;maxDelta=Math.max(maxDelta,delta);}if(changed){changedPixels++;mask[p]=255;}}
  const maskSHA256=sha(mask);if(!masks.has(maskSHA256)){
   const stem='masks/'+(changedPixels?'mask-'+maskSHA256.slice(0,16):'zero-difference-'+a.width+'x'+a.height);
   fs.writeFileSync(path.join(dir,stem+'.png'),maskPNG(mask,a.width,a.height),{flag:'wx'});
   fs.writeFileSync(path.join(dir,stem+'.bin.gz'),zlib.gzipSync(mask),{flag:'wx'});
   masks.set(maskSHA256,{png:stem+'.png',binary:stem+'.bin.gz',binaryLayout:'one uint8 per pixel, 0=equal/255=different, original WebGL bottom-up row order; PNG is top-down',width:a.width,height:a.height,sha256:maskSHA256});
  }
  const conditionDifferences=conditionKeys.filter(k=>!equal(a[k],b[k])),stateDifferences=stateKeys.filter(k=>!equal(a[k],b[k]));
  const cpuA=zlib.gunzipSync(fs.readFileSync(path.join(dir,`visual-1-${left}-${stage}-state.json.gz`))),cpuB=zlib.gunzipSync(fs.readFileSync(path.join(dir,`visual-1-${right}-${stage}-state.json.gz`)));
  const exactCPU=cpuA.equals(cpuB);if(sha(cpuA)!==a.cpuSHA256||sha(cpuB)!==b.cpuSHA256)throw Error('CPU snapshot hash mismatch');
  const result={left,right,changedPixels,changedChannels,maxDelta,conditionsEqual:conditionDifferences.length===0,stateEqual:stateDifferences.length===0,conditionDifferences,stateDifferences,exactCPUSnapshot:exactCPU,mask:masks.get(maskSHA256)};
  results[stage][left+'-'+right]=result;
  if(changedPixels||conditionDifferences.length||stateDifferences.length||!exactCPU)passed=false;
 }
}

const nonces=Object.values(all).map(r=>r.nonce);const independentNonces=new Set(nonces).size===3;if(!independentNonces)throw Error('Reused capture nonce');
for(const [label,r] of Object.entries(all))for(const [stage,steps]of [['first',1],['moving',61],['camera',91],['night',391]]){const a=r[stage];if(a.totalSteps!==steps||a.preparationCalls!==1||a.modifiedRenderer!==true||r.errors.length||a.beforeError||a.readError||a.endError||a.pngChangedBytes||a.finishChangedBytes||!a.defaultFramebuffer||!a.debug||a.quality!=='high'||!a.gpu.includes('RTX 3050')||a.programs.some(p=>!p.linked||p.log))throw Error('Invalid capture '+label+' '+stage);}
const cameraMoved=JSON.stringify(all.A1.camera.camera)!==JSON.stringify(all.A1.moving.camera);if(!cameraMoved)throw Error('Camera did not move');
let acceptable=true;for(const [stage,pairs]of Object.entries(results)){
 const aa=pairs['A1-A2'],b1=pairs['B-A1'],b2=pairs['B-A2'];
 const controlMatch=b1.changedPixels===0||b2.changedPixels===0;
 const states=Object.values(pairs).every(r=>r.conditionsEqual&&r.stateEqual&&r.exactCPUSnapshot);
 if(!controlMatch||!states)acceptable=false;
 for(const [left,right]of [['A1','A2'],['B','A1'],['B','A2']]){const a=fs.readFileSync(path.join(dir,'visual-1-'+left+'-'+stage+'.rgba')),b=fs.readFileSync(path.join(dir,'visual-1-'+right+'-'+stage+'.rgba')),delta=Buffer.alloc(a.length*2);for(let i=0;i<a.length;i++)delta.writeInt16LE(a[i]-b[i],i*2);pairs[left+'-'+right].signedDeltaSHA256=sha(delta);}
 if(aa.changedPixels&&controlMatch){const match=b1.changedPixels===0?b2.mask.sha256===aa.mask.sha256:b1.mask.sha256===aa.mask.sha256;if(!match)acceptable=false;}
}
const summary={strictlyZero:passed,acceptable,independentNonces,cameraMoved,results,distinctMasks:masks.size,note:'Only this single A1/B/A2 cycle; exact matching to a native A control is required. No pixel tolerance.'};save('comparison',summary);console.log(JSON.stringify({strictlyZero:passed,acceptable,results:Object.fromEntries(Object.entries(results).map(([s,r])=>[s,Object.fromEntries(Object.entries(r).map(([p,v])=>[p,{pixels:v.changedPixels,max:v.maxDelta,states:v.stateEqual,CPU:v.exactCPUSnapshot}]))]))}));if(!acceptable)process.exitCode=2;
